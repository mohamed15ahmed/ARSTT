import fs from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {spawnSync} from 'node:child_process';

export async function verifyBuild(root = process.cwd()) {
  let checked = 0;
  async function nonempty(relative) {
    const file = path.join(root, relative);
    const content = await fs.readFile(file, 'utf8');
    if (!content.trim()) throw new Error(`Build artifact is empty: ${relative}`);
    checked++;
    return content;
  }
  async function backend(directory) {
    for (const entry of await fs.readdir(path.join(root,directory), {withFileTypes:true})) {
      const source = path.join(directory,entry.name);
      if (entry.isDirectory()) { await backend(source); continue; }
      if (!entry.name.endsWith('.ts') || entry.name.endsWith('.d.ts')) continue;
      const output = path.join('dist',source.replace(/\.ts$/,'.js'));
      const content = await nonempty(output);
      if (source === path.join('server','main.ts') && !/\.listen\s*\(/.test(content)) {
        throw new Error('Built server entrypoint does not start the HTTP listener.');
      }
      const syntax = spawnSync(process.execPath,['--check',path.join(root,output)],{encoding:'utf8'});
      if (syntax.error || syntax.status !== 0) throw new Error(`Invalid JavaScript build artifact: ${output}`);
    }
  }
  await backend('server');
  const html = await nonempty('dist/public/index.html');
  const assets = [...html.matchAll(/(?:src|href)=["'](\/assets\/[^"']+)["']/g)].map(match=>match[1]);
  if (!assets.some(asset=>asset.endsWith('.js'))) throw new Error('Built HTML has no application JavaScript asset.');
  for (const asset of assets) {
    if (asset.includes('..')) throw new Error('Unexpected build asset path.');
    await nonempty(path.join('dist/public',asset.slice(1)));
  }
  return {checked};
}
if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  try { console.log('Build artifacts verified:', (await verifyBuild()).checked); }
  catch (error) { console.error(error.message); process.exitCode=1; }
}

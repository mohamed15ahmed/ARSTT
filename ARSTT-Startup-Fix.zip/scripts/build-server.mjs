import fs from 'node:fs/promises';
import path from 'node:path';
import {transform} from 'esbuild';

// Keep TypeScript checking in `npm run build`, but write backend output through
// Node instead of relying on the native TypeScript compiler's file emitter.
async function compile(directory) {
  for (const entry of await fs.readdir(directory, {withFileTypes:true})) {
    const source = path.join(directory, entry.name);
    if (entry.isDirectory()) { await compile(source); continue; }
    if (!entry.name.endsWith('.ts') || entry.name.endsWith('.d.ts')) continue;
    const {code} = await transform(await fs.readFile(source, 'utf8'), {
      loader:'ts', format:'esm', target:'es2023', sourcefile:source,
    });
    if (!code.trim()) throw new Error(`Backend compilation produced empty output: ${source}`);
    const destination = path.join('dist', source.replace(/\.ts$/, '.js'));
    await fs.mkdir(path.dirname(destination), {recursive:true});
    const temporary = destination + '.tmp';
    await fs.writeFile(temporary, code, 'utf8');
    await fs.rename(temporary, destination);
  }
}
await compile('server');

@echo off
cd /d "%~dp0"
if not exist compose.yaml (
  echo Copy the repair files into the project folder containing compose.yaml first.
  pause
  exit /b 1
)
echo Close any temporary foreground ARSTT run with Ctrl+C before continuing.
docker info >nul 2>&1
if errorlevel 1 (
  echo Start Docker Desktop and wait for the Linux engine.
  pause
  exit /b 1
)
docker image inspect arstt-app:latest >nul 2>&1
if errorlevel 1 (
  echo The existing arstt-app image was not found. No data was changed.
  pause
  exit /b 1
)
docker compose stop app
if errorlevel 1 exit /b 1
docker build --network=none --pull=false --build-arg ARSTT_BASE_IMAGE=arstt-app:latest -f Dockerfile.repair -t arstt-app:latest .
if errorlevel 1 (
  echo Repair build failed. Preserve the output above. Existing scan data was not deleted.
  pause
  exit /b 1
)
docker compose up -d --no-deps --no-build --force-recreate --wait --wait-timeout 120 app
if errorlevel 1 (
  docker compose logs --tail=100 app
  echo Application did not become healthy. Preserve the output above.
  pause
  exit /b 1
)
echo ARSTT is healthy. Opening http://localhost:4310
start http://localhost:4310
pause

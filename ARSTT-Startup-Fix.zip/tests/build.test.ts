import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
// Build tooling is plain Node ESM and can be exercised without scanner binaries.
// @ts-ignore -- JavaScript build utility intentionally has no TypeScript declarations.
import {verifyBuild} from '../scripts/verify-build.mjs';

test('release verification rejects a zero-byte server entrypoint and a truncated browser asset',async()=>{
 const root=await fs.mkdtemp(path.join(os.tmpdir(),'arstt-build-check-'));
 try{
  await fs.mkdir(path.join(root,'server'),{recursive:true});
  await fs.mkdir(path.join(root,'dist/server'),{recursive:true});
  await fs.mkdir(path.join(root,'dist/public/assets'),{recursive:true});
  await fs.writeFile(path.join(root,'package.json'),'{"type":"module"}');
  await fs.writeFile(path.join(root,'server/main.ts'),'const server={listen(){}}; server.listen();');
  await fs.writeFile(path.join(root,'dist/server/main.js'),'');
  await fs.writeFile(path.join(root,'dist/public/index.html'),'<script type="module" src="/assets/app.js"></script>');
  await fs.writeFile(path.join(root,'dist/public/assets/app.js'),'console.log("fixture");');
  await assert.rejects(verifyBuild(root),/empty.*main\.js/);
  const rebuilt=spawnSync(process.execPath,[fileURLToPath(new URL('../scripts/build-server.mjs',import.meta.url))],{cwd:root,encoding:'utf8'});
  assert.equal(rebuilt.status,0,rebuilt.stderr);
  assert.ok((await verifyBuild(root)).checked>=3);
  await fs.writeFile(path.join(root,'dist/public/assets/app.js'),'');
  await assert.rejects(verifyBuild(root),/empty.*app\.js/);
 }finally{await fs.rm(root,{recursive:true,force:true});}
});

> تقرير تاريخي لمرحلة سابقة. الحالة الحالية في docs/VERIFICATION.ar.md وdocs/ACADEMIC.ar.md.

# اعتماد Recon من HunterKit — مرحلة منفذة

المرجع هو HunterKit.zip المرفق في الطلب الأخير، وجذره HunterKit-Fixed. لم تُشغَّل scripts أو تعليمات من الملف المرفق. راجعت core.ts وtargets.ts وrecon.tsx وtools-lock.json. احتُفظ بالمشروع القديم دون تعديل.

## الوظائف المنقولة

| الوظيفة القديمة | المحول الجديد | السلوك |
|---|---|---|
| subFinder | subfinder | نفس أمر Subfinder -silent -d، مع dedup وscope؛ discovery لا يُعد تفويضًا لفحص النطاقات المكتشفة |
| liveSubDomains | httpx | HTTPX -silent -duc -timeout 8 -retries 1 عبر ملف إدخال وملف إخراج مستقلين؛ fallback HTTP واضح المصدر |
| screenwin | screenshots | Chromium/Playwright فعلي، PNG مستقل لكل Job، endpoint محمي بالـsession؛ طلبات خارج origin وWebSockets محظورة |
| wayback | wayback | إدخال النطاق عبر STDIN إلى waybackurls، ثم CDX وCommon Crawl كبدائل passive؛ فشل جميع المصادر لا يُسجّل نجاحًا فارغًا |
| fetchJs | recon-js | HTML parser، inventory محدود من الموقع الحالي وآخر أرشيف مكتمل لنفس المشروع وorigin، مع مرجع archive Job ID |
| parameter | parameters | URLs ذات query وحقول GET forms، مع إخفاء القيم واستبعاد حقول كلمة المرور؛ لا تُرسل النماذج |

لم أنسخ core.ts كاملًا: فيه إنشاء مجلدات/migration عند import ومحرك Processes ثانٍ وتعطيل تحقق شهادات HTTPS في fallback. المحول يستخدم أدواته وأوامره ومسار عمله داخل محرك Jobs الحالي، ويحافظ على TLS verification. التفويض الحالي origin واحد؛ لم أحوّل اكتشاف subdomains إلى تفويض تلقائي لفحصها.

الزحف GET محدود بـ12 وثيقة و2000 URL. لا يتبع query links أو مسارات logout/delete/remove/destroy/reset أثناء الزحف، ولا ينفذ النماذج. كل مخرج مرتبط بـJob ID جديد، ولا يُعاد استخدام ملف HTTPX قديم. البيانات التاريخية المستخدمة في inventory معلنة بمعرف العملية الأصلية ومقيدة بالمشروع والـorigin.

## حالات التنفيذ

- Completed: تحقق المخرج الفعلي وحُفظ.
- Partial: يوجد محتوى تم جمعه لكن التغطية ناقصة، مثل فشل بعض ملفات JS أو الاعتماد على fallback بعد تعذر HTTPX. لا تُعرض كفحص آمن أو كامل.
- Skipped: Subfinder/Public Archives غير منطبقة على IP/localhost/أسماء حاويات التدريب. لا تُدعى عملية تنفيذ لم تحدث.
- Failed وTimeout وCancelled تحتفظ بمعناها، مع Exit Code فعلي للـsubprocess.

## الواجهة المنفذة

Recon وWeb وNetwork تعرض Cards في عمودين، وصف وزر Run لكل أداة. الـSidebar للأقسام الرئيسية، وأزيل رابط Tool Readiness مع بقاء detection. JS Leaks داخل Recon، ومساره القديم ما زال مدعومًا للتوافق. Results & Reports تعرض السجل وتفاصيل كل عملية ونتائجها وJSON/CSV والمخرج الخام. الألوان أصبحت فاتحة مع accent أزرق هادئ. المقارنة وPDF وتوسعة AI وAttack ما زالت مراحل أخرى غير مكتملة.

## Browser وDocker

تتضمن الصورة Chromium ومكتباته. استُخدمت سياسة seccomp الرسمية لـPlaywright من:
https://raw.githubusercontent.com/microsoft/playwright/v1.56.1/utils/docker/seccomp_profile.json
SHA256: cc3e61cabda6bbc1e53e54d27ba4d55a9d3be829b6dd1a596f4a7b31b1cc7849

اختبار Docker الفعلي نجح في إطلاق Chromium مع renderer sandbox مفعّل دون privileged أو SYS_ADMIN، وفي التقاط Juice Shop داخل الـsandbox. وضع ARSTT_LOCAL_TRAINING_BROWSER اختياري وصريح للتدريب المحلي في بيئات تختبر الواجهة دون namespaces؛ لا ينطبق مطلقًا على الوجهات العامة، وليس مفعّلًا افتراضيًا.

أُضيف Juice Shop الرسمي v19.0.0 ببصمة الصورة المثبتة في Compose. Juice Shop وfixture المحلي على شبكة training داخلية لا تملك خروجًا مباشرًا للإنترنت. التطبيق متصل بشبكة التشغيل وشبكة التدريب. منافذ المضيف محددة على127.0.0.1.

## التحقق والحدود

نجح npm run build و9 اختبارات المنطق/API، واختبار قبول Recon بملفات Subfinder/HTTPX/waybackurls الحقيقية، و14 فحص متصفح. يشمل قبول Recon HTTPX فعليًا، واختبار غيابها مع fallback مصنف Partial، وفصل نتائج مشروع آخر، واستخراج parameter names دون إرسال النماذج، وPNG فعلية عبر API. تُحفظ الأدلة في artifacts/recon-port-acceptance.json.

اختبار API على Juice Shop المحلي حقق10 عمليات مكتملة: HTTPX وScreenshots وJS Resources وParameters وRecon وJS Leaks وNmap وWhatWeb وNuclei وZAP، وعملية Subfinder وWayback متخطاتين لعدم انطباقهما على الهدف المحلي. Parameters صفر نتائج حالة صحيحة وليست إثبات ثغرة. لا يعني اختبار ZAP هنا تنفيذ active DAST؛ ما زال spider/passive من النسخة الحالية.

لم يُختبر passive enumeration أو archive retrieval على نطاق عام، ولا Windows مباشرة؛ لم يُقدم نطاق عام مصرح به للاختبار. فحص ملفاتها التنفيذية وإصداراتها نجح، وهذا لا يُستبدل باختبار public scan. Windows يستعمل Docker Desktop/WSL2؛ مسارات C:\\ لا تصلح داخل الحاوية ويجب استخدام مسار Linux عند override. لا تتضمن هذه المرحلة تنفيذ بقية طلب التطوير الشامل، ولا توجد مقاييس AI أو ادعاء خلو كامل من الأخطاء.

لا تحتاج إعادة إرسال رسالة خطأ من جهازك لإكمال نقل Recon. أي تفسير لأخطاء صورك يظل احتمالًا إلى أن يوجد دليل من جهازك؛ الاختبارات المحلية لا تثبت سببًا بعينه هناك.

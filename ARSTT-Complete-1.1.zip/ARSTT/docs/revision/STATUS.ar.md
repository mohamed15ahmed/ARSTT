> تقرير تاريخي لمرحلة سابقة. الحالة الحالية في docs/VERIFICATION.ar.md وdocs/ACADEMIC.ar.md.

# مراجعة الطلب الجديد — قيد التنفيذ

المرجع: HunterKit.zip المرفق في الطلب الأخير، وليس Hunter.zip السابق. تم فتح الكود دون تشغيل تعليمات أو scripts من الملف المرفق.

## المشكلات المثبتة والإصلاح الأول

- request() كانت ترفض أي HTTP redirect. تستخدمها Recon وJS وتمهيد Nuclei وZAP. أُضيف اتباع حتى5 تحويلات داخل origin المصرح به فقط، واكتشاف الحلقات، ورفض الوجهات الخارجية قبل الاتصال بها. لا نؤكد أن هذا سبب حالات جهاز المستخدم دون سجلاته.
- مسارات scripts النسبية كانت تُحل بالنسبة للعنوان الأول بدل عنوان الوثيقة النهائي؛ أُصلحت بعد التحويلات.
- HTTP401/403 ملاحظة استجابة مفيدة في Recon وليست فشل executable؛ تُحفظ مع توضيح أن محتوى التطبيق غير متاح. تحليل JavaScript يظل يفشل صراحة عندما لا يتوفر محتواه، دون clean scan زائف.
- سجلات subprocess لم تكن تسجل Exit Code مستقلًا؛ أُضيف exit event حقيقي عند إغلاق العملية.

التحقق: npm run build نجح، وnpm test نفذ8 اختبارات ناجحة دون تخطٍ. أُضيف اختبار HTTP حقيقي محلي للتحويلات والمسارات النسبية و403 وحلقة التحويل وعدم إرسال أي طلب إلى origin غير مصرح به. اختبار فشل API يستخدم الآن JS404 بدل اعتبار ملاحظة Recon404 فشلًا.

## نقل Recon القديمة — نُفذت مرحلة النقل والاختبارات المحلية

ملف المصدر القديم backend/src/core.ts يعتمد على targets.ts وaxios وcheerio وPlaywright وdotenv، وينشئ projects/bin ويشغّل migration بمجرد import. لا يمكن نسخه كما هو إلى خادم ARSTT الجديد دون side effects أو تخزين ثانٍ. الوظائف المطلوب نقلها بمحوّل إلى Job ID الحالي:

1. Subfinder: subFinder()، passive domain enumeration، مع تمييز الأهداف المحلية التي لا تنطبق عليها الوظيفة.
2. HTTPX: liveSubDomains()، مع browser-like fallback وتوثيق مصدر كل نتيجة.
3. Screenshots: screenwin() وPlaywright، يتطلب Chromium وصلاحيات sandbox وسياسة وصول scoped.
4. Wayback: wayback() وCDX fallback، مع عزل archive حسب الهدف والعملية.
5. JS resources وParameters من الأرشيف، مع dedup وعدم افتراض صلاحية الأصول المكتشفة للفحص النشط.

يحتاج scope الجديد خيار تفويض صريح للنطاقات الفرعية قبل probing؛ التفويض الحالي origin واحد. لن تتحول نتائج الاكتشاف إلى تفويض ضمني.

## المراحل المتبقية المطلوبة

- نُفذت محولات Recon وقوالب تثبيتها وCards وResults وChromium ونجحت اختبارات محلية وDocker وJuice Shop. راجع RECON-PORT.ar.md؛ passive public scans وWindows الفعلي ما زالا غير مختبرين.
- Juice Shop محلي معزول، وتفعيل ZAP active DAST باشتراط local-training scope منفصل؛ لا active scans على الجامعة أو demo العامة.
- Security Headers وCookies وAPI/security-misconfiguration checks مع evidence/recommendation، ثم فحوص XSS/SQLi/IDOR/auth ضمن إعدادات تدريب ومستخدمين/حسابات اختبار محددة.
- Nmap profiles ومقارنة scans وCPE/CVE enrichment بمصدر موثق؛ لا exploitability من version فقط.
- Findings موحدة وحالة remediation، Results & Reports مخصصة، JSON/CSV/PDF وتصدير واختبارات مقارنة.
- تحليل أولويات وتجميع findings مبني على الأدلة، مع optional AI provider؛ لا تصنيف confirmed من تخمين نموذج ولا مقاييس تدريب مختلقة.
- Dashboard بحسب target، risk formula موثقة وتغطية مستقلة عن وجود النتائج، دون خلط تاريخ فاشل بنتيجة آمنة.
- Sidebar أقسام فقط، أدوات في Cards عمودين، إزالة Tool Readiness من التنقل مع بقاء detection، وتحديث الألوان البسيطة.
- تم تصحيح npm run dev: يشغّل Vite والخادم معًا على5175 و4311 افتراضيًا، مع proxy يحتفظ بـOrigin وCSRF. نجح اختبار فعلي للواجهة وإنشاء مشروع عبر proxy بقاعدة بيانات مؤقتة مستقلة.

بعض بنود Recon والواجهة الواردة أعلاه نُفذت كما يوضح RECON-PORT.ar.md؛ بقية المراحل غير مكتملة، والنسخة ليست التسليم النهائي للطلب الشامل. لم تُرفع الإصلاحات الحالية إلى GitHub ولم يُستبدل ZIP التسليم السابق. تحتاج مطابقة أسباب الفشل على جهاز المستخدم رسائل Execution log؛ الصور وحدها لا تكفي. لا تُعتبر اختبارات النسخة السابقة نجاحًا لهذه التعديلات.

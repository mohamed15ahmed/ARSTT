# تعريف مهمة التعلم الآلي قبل التنفيذ

المهمة: تصنيف مستوى الخطورة المرجعي لوصف advisory أمني نصي إلى LOW وMODERATE وHIGH وCRITICAL، لمساعدة ترتيب مراجعة Findings ذات الوصف الكافي. لا يكتشف النموذج ثغرة جديدة ولا يثبت قابلية الاستغلال ولا يرقّي نتيجة إلى Confirmed. تدريب مستقل محلي، وليس API أو rules معاد تسميتها.

المدخلات: summary + details فقط بعد تنظيفها، دون severity/CVSS/CWE/affected-package metadata أو معرفات CVE/GHSA أو URLs أو إصدارات أو عبارات تصنيف صريحة. المخرجات: فئة متوقعة وتوزيع احتمالات النموذج، أو امتناع إذا كان النص غير كافٍ أو الثقة منخفضة. احتمالات النموذج ليست ثقة بوجود ثغرة. أثناء الدمج تبقى نتيجة الأداة وشدتها ودليلها منفصلين.

المصدر: GitHub Advisory Database، advisories/github-reviewed، snapshot commit d9dc212ef01743bc06ac8ffb78cc88aee8e83cb4. تم قراءة LICENSE.md فعليًا: Creative Commons Attribution 4.0 International (CC-BY-4.0). Attribution إلى GitHub Advisory Database ومساهميها، https://github.com/github/advisory-database، والترخيص https://creativecommons.org/licenses/by/4.0/. البيانات مشتقة بالتنظيف واختيار الحقول وتقسيم المجموعات؛ لا endorsement من GitHub. لا نستخدم unreviewed أو withdrawn advisories في التدريب.

الفحص الأولي: 37192 advisory reviewed؛ HIGH=13494 وMODERATE=16109 وLOW=2716 وCRITICAL=4873؛ summary/details غير مفقودين في الفحص الأولي. العد النهائي بعد تنظيف النص واستبعاد withdrawn والنصوص القصيرة والتكرار يُحسب بالكود ويُحفظ في data-audit.json؛ لا تُستعمل هذه الأرقام كادعاء بأعداد التدريب النهائية.

معاني Labels: القيمة المنقولة من database_specific.severity في البيانات المراجعة. MODERATE يقابل medium في عرض ARSTT. لا تتساوى label مع تأكيد أمان/ضعف هدف المستخدم.

التقسيم: train70% وvalidation15% وtest15% بمجموعات aliases/CVE مشتركة والنصوص المطابقة/شديدة التشابه، قبل اختيار المعلمات. التقسيم seed ثابت وتُحفظ معرّفات records/groups في split-manifest.json. لا تُستخدم test في اختيار النموذج أو ضبط معلماته. التكرار المتقارب يُجمع بـMinHash/LSH مع تحقق Jaccard على word shingles؛ ليست هناك دعوى بأنه يمنع كل تشابه لغوي محتمل.

النموذج المرشح للنصوص: TF-IDF + Logistic Regression مع class weighting؛ مناسب للبيانات النصية المتناثرة وأبسط في إعادة التشغيل من Random Forest على ملايين أبعاد النص. مقارنة بخط أساس most-frequent، واختيار regularization باستخدام validation فقط. التقييم المستقل الأخير: Precision/Recall/F1/support لكل فئة وmacro/weighted F1 وconfusion matrix، مع توثيق عدم توازن الفئات والامتناع وحدود domain shift إلى نتائج scanners.

القيود: Labels خارجية قد تحمل أخطاء، CVSS severity ليست أولوية remediation كاملة، النصوص الإنجليزية المراجعة تختلف عن أدلة HTML أو banners؛ لا استنتاج impact مؤكد من وصف قصير أو منفذ مفتوح. لا ندّعي أداء جيدًا أو نكتب أرقامًا افتراضية قبل تنفيذ التقييم. إذا فشل تحميل النموذج أو inference تبقى الفحوصات والسجل والتقارير تعمل دون نتائج AI وهمية.

## تجربة ثانية محددة قبل كودها: تصنيف نوع المشكلة

تجربة الشدة الأولى حققت Test accuracy≈0.581 وmacro-F1≈0.525 مقابل baseline macro-F1≈0.152. هذه نتيجة متوسطة، وخصوصًا فئة LOW، ولن تُعرض كحكم موثوق للشدة أو قابلية الاستغلال. لا تُحذف مقاييس التجربة ولا تُضبط معلماتها باستخدام Test.

المهمة الثانية المستقلة: تصنيف نوع المشكلة النصي إلى XSS(CWE79)، SQL_INJECTION(CWE89)، PATH_TRAVERSAL(CWE22)، SSRF(CWE918)، COMMAND_INJECTION(CWE78)، DESERIALIZATION(CWE502)، ACCESS_CONTROL(CWE284/285/862/863/639/306/287)، MEMORY_SAFETY(CWE119/125/416/787)، OTHER (CWEs أخرى). تُستبعد السجلات بلا CWE أو التي تنتمي لأكثر من فئة مختارة منعًا لLabel غامض؛ لا يُستخدم CWE نفسه كميزة.

نفس snapshot والترخيص وcleaning وgroup split المعتمد قبل التدريب. نوع المشكلة هو Label جديد لم يُستخدم في tuning التجربة الأولى. لا يُستخدم Test لاختيار معلمات نموذج النوع. المقارنة والمقاييس تحفظ في type-metrics.json مستقلة؛ يضاف model card يشرح domain shift وabstention. المدخلات وصف نصي فقط، والمخرجات نوع مقترح؛ هذا لا يعني تأكيد وجود المشكلة على هدف المستخدم. هذا النموذج هو المرشح الأساسي للتجميع، بينما تبقى قواعد الأدلة والشدة الأصلية أساس الأولوية.

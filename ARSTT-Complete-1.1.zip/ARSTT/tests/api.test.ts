import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs/promises';
import {application,temporary,lab,wait,evidence} from './support.js';
test('real API: authorization, sessions, job isolation, SSE replay, cancellation, history and exports',async()=>{
 const dir=await temporary(),fixture=await lab(),app=await application({data:dir});
 try{
  assert.equal((await fetch(app.base+'/api/jobs')).status,401);
  assert.equal((await app.req('/projects','POST',{name:'Lab',target:fixture.http,authorized:false})).status,400);
  assert.equal((await app.req('/projects','POST',{name:'Lab',target:fixture.http,authorized:true},{'x-arstt-csrf':''})).status,403);
  const created=await app.req('/projects','POST',{name:'Lab',target:fixture.http,authorized:true});assert.equal(created.status,201);const p=await created.json() as any;
  assert.equal((await app.req('/jobs','POST',{projectId:p.id,tool:'recon',target:'http://outside.invalid/'})).status,400);
  assert.equal((await app.req('/jobs','POST',{projectId:p.id,tool:'shell',target:fixture.http})).status,400);
  const started=await app.req('/jobs','POST',{projectId:p.id,tool:'recon',target:fixture.http});assert.equal(started.status,202);const a=await started.json() as any;
  const good=await wait(app.store,a.id);assert.equal(good.status,'completed',good.error||'');assert.ok(good.findings.length);
  const badResponse=await app.req('/jobs','POST',{projectId:p.id,tool:'jsleaks',target:fixture.http+'/missing'});const b=await badResponse.json() as any;const failed=await wait(app.store,b.id);assert.equal(failed.status,'failed');assert.deepEqual(failed.findings,[]);
  const csv=await app.req('/jobs/'+a.id+'/export?format=csv');assert.equal(csv.status,200);const csvText=await csv.text();assert.match(csvText,new RegExp(a.id));assert.ok(!csvText.includes(b.id));
  const report=await(await app.req('/jobs/'+b.id+'/export')).json() as any;assert.equal(report.status,'failed');assert.deepEqual(report.findings,[]);assert.ok(report.error);
  const raw=await app.req('/jobs/'+a.id+'/raw');assert.equal(raw.status,200);JSON.parse(await raw.text());assert.equal((await app.req('/jobs/'+b.id+'/raw')).status,404);
  const controller=new AbortController();const stream=await fetch(app.base+'/api/jobs/'+a.id+'/events',{headers:{cookie:app.cookie,'Last-Event-ID':String(app.store.logs(a.id)[0].seq)},signal:controller.signal});const read=await stream.body!.getReader().read();const text=new TextDecoder().decode(read.value);controller.abort();assert.match(text,new RegExp(a.id));assert.ok(!text.includes(b.id));
  const slow=await(await app.req('/jobs','POST',{projectId:p.id,tool:'recon',target:fixture.http+'/slow'})).json() as any;
  assert.equal((await app.req('/jobs','POST',{projectId:p.id,tool:'recon',target:fixture.http+'/slow'})).status,409);
  assert.equal((await app.req('/jobs/'+slow.id,'DELETE')).status,200);assert.equal((await wait(app.store,slow.id)).status,'cancelled');
  const history=await(await app.req('/jobs')).json() as any[];assert.equal(history.length,3);assert.equal(new Set(history.map(j=>j.id)).size,3);
  const html=await fetch(app.base+'/');assert.equal(html.status,200);assert.match(await html.text(),/Automated Reconnaissance/);
  await evidence('api-acceptance.json',{passed:true,jobs:history,csv:csvText,failedReport:report});
 }finally{await app.close();await fixture.close();await fs.rm(dir,{recursive:true,force:true});}
});

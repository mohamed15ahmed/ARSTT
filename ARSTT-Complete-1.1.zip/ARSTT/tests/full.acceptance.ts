import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs/promises';import http from 'node:http';
import {application,temporary,wait,evidence} from './support.js';

test('Nmap profiles execute actual authorized port scope and preserve independent results',{timeout:180000},async()=>{
 const one=http.createServer((_q,s)=>s.end('Authorized service one')),two=http.createServer((_q,s)=>s.end('Authorized service two'));await Promise.all([new Promise<void>(r=>one.listen(0,'127.0.0.1',r)),new Promise<void>(r=>two.listen(0,'127.0.0.1',r))]);const p1=(one.address() as any).port,p2=(two.address() as any).port,origin=`http://127.0.0.1:${p1}`,dir=await temporary(),app=await application({data:dir});
 try{assert.equal((await app.req('/projects','POST',{name:'Invalid scope',target:origin,authorized:true,networkPorts:String(p2),networkAuthorized:false})).status,400);const p=app.store.addProject('Network scope',origin,String(p2)),results=[];
  for(const profile of ['quick','basic','detailed'] as const){const j=await wait(app.store,app.runner.create(p.id,'nmap',origin+'/',profile).id);assert.equal(j.status,'completed',j.error||'');assert.ok(j.findings.some(f=>f.title.startsWith(String(p1)+'/')));assert.ok(j.findings.some(f=>f.title.startsWith(String(p2)+'/')));const commands=app.store.logs(j.id).filter(l=>l.level==='command').map(l=>JSON.parse(l.message));const args=commands[0].args;assert.equal(args.includes('-sV'),profile!=='quick');assert.equal(args.includes('--version-all'),profile==='detailed');assert.ok(args[args.indexOf('-p')+1].includes(String(p2)));results.push({job:j,logs:app.store.logs(j.id)});}
  assert.equal(new Set(results.map(r=>r.job.id)).size,3);await evidence('network-profiles.json',{passed:true,results});
 }finally{await app.close();one.closeAllConnections();two.closeAllConnections();await Promise.all([new Promise<void>(r=>one.close(()=>r())),new Promise<void>(r=>two.close(()=>r()))]);await fs.rm(dir,{recursive:true,force:true});}
});

test('real PDF export opens as PDF, preserves failure status, Unicode and separates ML predictions',{timeout:90000},async()=>{
 const dir=await temporary(),app=await application({data:dir});const fixture=http.createServer((_q,s)=>{s.setHeader('content-type','text/html');s.end('<title>PDF training</title>');});await new Promise<void>(r=>fixture.listen(0,'127.0.0.1',r));const origin=`http://127.0.0.1:${(fixture.address() as any).port}`;
 try{const p=app.store.addProject('تقرير تدريب',origin),good=await wait(app.store,app.runner.create(p.id,'headers',origin+'/').id);
  const ai=await app.req('/projects/'+p.id+'/ml','POST',{});assert.equal(ai.status,200);const predicted=await ai.json() as any;assert.ok(predicted.analysisId);assert.ok((await(await app.req('/projects/'+p.id+'/ml')).json() as any).id);
  const pdf=await app.req('/jobs/'+good.id+'/export?format=pdf');assert.equal(pdf.status,200);const bytes=Buffer.from(await pdf.arrayBuffer());assert.equal(bytes.subarray(0,5).toString(),'%PDF-');await fs.mkdir('artifacts',{recursive:true});await fs.writeFile('artifacts/report-completed.pdf',bytes);const json=await(await app.req('/jobs/'+good.id+'/export')).json() as any;assert.equal(json.aiAnalysis.analysisId,predicted.analysisId);
  const closed=app.store.addProject('Closed PDF target','http://127.0.0.1:1'),failed=await wait(app.store,app.runner.create(closed.id,'api-check',closed.origin+'/').id);assert.equal(failed.status,'failed');const response=await app.req('/jobs/'+failed.id+'/export?format=pdf');assert.equal(response.status,200);await fs.writeFile('artifacts/report-failed.pdf',Buffer.from(await response.arrayBuffer()));
  const saved=process.env.ARSTT_BROWSER;process.env.ARSTT_BROWSER='/missing/browser';try{assert.equal((await app.req('/jobs/'+good.id+'/export?format=pdf')).status,500);}finally{if(saved===undefined)delete process.env.ARSTT_BROWSER;else process.env.ARSTT_BROWSER=saved;}
  assert.equal((await app.req('/jobs/'+good.id+'/export?format=pdf')).status,200);await evidence('pdf-acceptance.json',{passed:true,completedJob:good.id,failedJob:failed.id,aiAnalysisId:predicted.analysisId,byteLength:bytes.length});
 }finally{await app.close();fixture.closeAllConnections();await new Promise<void>(r=>fixture.close(()=>r()));await fs.rm(dir,{recursive:true,force:true});}
});

test('local DAST real process timeout and cancellation retain truthful terminal states',{timeout:30000},async()=>{
 const dir=await temporary(),app=await application({data:dir,deadlines:{'zap-active':1000}});
 try{const p=app.store.addProject('Isolated active timeout','http://juice-shop:3000');const timed=await wait(app.store,app.runner.create(p.id,'zap-active',p.origin+'/').id);assert.equal(timed.status,'timeout',timed.error||'');assert.deepEqual(timed.findings,[]);assert.ok(app.store.logs(timed.id).some(l=>l.level==='command'));
  const cancelled=app.runner.create(p.id,'zap-active',p.origin+'/');app.runner.cancel(cancelled.id);assert.equal((await wait(app.store,cancelled.id)).status,'cancelled');await evidence('dast-timeout-cancel.json',{passed:true,timed,logs:app.store.logs(timed.id),cancelled:app.store.job(cancelled.id)});
 }finally{await app.close();await fs.rm(dir,{recursive:true,force:true});}
});

import test from 'node:test';import assert from 'node:assert/strict';import http from 'node:http';
import {request,reconnaissance,javascriptLeaks} from '../server/web-analysis.js';
test('actual HTTP: scoped redirects, final-relative JS, error responses, external redirects and loops',async()=>{
 let externalRequests=0;
 const outside=http.createServer((_q,s)=>{externalRequests++;s.end('outside');});await new Promise<void>(r=>outside.listen(0,'127.0.0.1',r));
 const external=`http://127.0.0.1:${(outside.address() as any).port}`;
 const server=http.createServer((q,s)=>{
  if(q.url==='/'){s.writeHead(302,{Location:'/app/index.html'});s.end();}
  else if(q.url==='/app/index.html')s.end('<script src="bundle.js"></script>');
  else if(q.url==='/app/bundle.js'){s.setHeader('content-type','application/javascript');s.end('const route="/api/v1/test";');}
  else if(q.url==='/external'){s.writeHead(302,{Location:external});s.end();}
  else if(q.url==='/loop'){s.writeHead(302,{Location:'/loop'});s.end();}
  else{s.writeHead(403);s.end('Permission required');}
 });await new Promise<void>(r=>server.listen(0,'127.0.0.1',r));
 const base=`http://127.0.0.1:${(server.address() as any).port}`,signal=new AbortController().signal;
 try{
  const r=await request(new URL(base),signal);assert.equal(r.finalURL.pathname,'/app/index.html');
  const js=await javascriptLeaks(new URL(base),signal,()=>{});assert.ok(js.findings.some(f=>f.evidence.includes('/api/v1/test')));assert.ok(js.findings.every(f=>f.source.endsWith('/app/bundle.js')));
  const recon=await reconnaissance(new URL(base+'/forbidden'),signal,()=>{});assert.ok(recon.findings.some(f=>f.title==='HTTP 403'));assert.match(recon.raw,/inaccessible/);
  await assert.rejects(javascriptLeaks(new URL(base+'/forbidden'),signal,()=>{}),/HTTP 403/);
  await assert.rejects(request(new URL(base+'/external'),signal),/authorized origin/);assert.equal(externalRequests,0);
  await assert.rejects(request(new URL(base+'/loop'),signal),/loop/);
 }finally{server.closeAllConnections();outside.closeAllConnections();await Promise.all([new Promise<void>(r=>server.close(()=>r())),new Promise<void>(r=>outside.close(()=>r()))]);}
});

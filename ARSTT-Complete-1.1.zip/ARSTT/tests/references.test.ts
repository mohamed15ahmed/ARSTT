import test from 'node:test';import assert from 'node:assert/strict';import {knownCVEs,overview,compare} from '../server/analysis.js';import type {Job} from '../server/types.js';
test('actual reference lookup uses NVD or reviewed local advisory source; version alone is never exploit proof',{timeout:85000},async()=>{
 // Explicit metadata fixture for the enrichment unit, not a claimed live Nmap result.
 const job:Job={id:'reference-metadata-fixture',projectId:'fixture',tool:'nmap',target:'http://localhost:8080/',status:'completed',createdAt:'2026-01-01',startedAt:null,endedAt:null,error:null,rawAvailable:true,profile:'basic',findings:[{title:'8080/tcp open',kind:'Open port',source:'127.0.0.1',severity:'info',verification:'observation',evidence:JSON.stringify({product:'Tomcat',version:'9.0.0'})}]};
 const result=await knownCVEs(job);assert.equal(result.rows.length,1);const row=result.rows[0];assert.ok(['lookup-completed','local-advisory-candidates'].includes(row.status),JSON.stringify(row));if(row.status==='local-advisory-candidates')assert.ok(row.candidates?.length);
 const missing=await knownCVEs({...job,id:'reference-missing-version',findings:[{...job.findings[0],evidence:'{"product":"Tomcat","version":null}'}]});assert.equal(missing.rows[0].status,'insufficient-version-data');
});
test('risk never displays safe zero for failed scans; comparison records changed service evidence',()=>{
 const j:Job={id:'a',projectId:'p',tool:'nmap',target:'http://localhost/',status:'failed',createdAt:'2026-01-01',startedAt:null,endedAt:null,error:'failure',rawAvailable:false,findings:[],profile:'basic'};assert.equal(overview([j]).reviewIndex,null);
 const a={...j,status:'completed' as const,findings:[{title:'80/tcp open',kind:'Open port',source:'localhost',severity:'info' as const,verification:'observation' as const,evidence:'{"version":"1"}'}]};const b={...a,id:'b',findings:[{...a.findings[0],evidence:'{"version":"2"}'}]};assert.equal(compare(a,b).changed.length,1);assert.equal(compare(a,b).unchanged.length,0);
});

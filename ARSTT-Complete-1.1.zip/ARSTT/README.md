# Automated Reconnaissance and Security Testing Toolkit (ARSTT)

> الإصدار 1.1: تنفيذ الأدوات، Recon المنقول، مختبر Juice Shop معزول، نموذج ML مدرّب محليًا، نتائج ومقارنة وتقارير JSON/CSV/PDF. راجع [تقرير التحقق الحالي](docs/VERIFICATION.ar.md) و[توثيق النموذج](docs/ACADEMIC.ar.md).

مشروع مستقل بواجهة React/TypeScript وخادم Node.js 24، مع SQLite وسجل Jobs وSSE لمتابعة التنفيذ. المصادر مكتوبة من جديد ولا تعتمد على HunterKit أو إعداداته أو مساراته.

## Windows: ابدأ من هنا

1. ثبّت Docker Desktop، وفعّل WSL2 وLinux containers. خصّص 8 GB RAM على الأقل و15 GB مساحة متاحة. المعمارية المدعومة حاليًا x86_64/amd64.
2. فك ZIP بالكامل في مجلد قابل للكتابة. افتح Docker Desktop وانتظر جاهزيته.
3. شغّل `START-WINDOWS.cmd`، أو نفّذ من PowerShell داخل مجلد المشروع:

```powershell
docker compose --profile training up --build -d
docker compose exec app npm run doctor
docker compose ps
```

البناء الأول يحتاج اتصال إنترنت بـDocker Hub، Debian، npm registry، GitHub وcodeload.github.com. لا تحتاج تثبيت Node أو Ruby أو Java أو أدوات الفحص على Windows؛ تُثبت داخل الصورة مع التحقق من بصمات الأدوات المحملة.

بعد جاهزية الحاوية افتح المتصفح على `http://localhost:4310`. أنشئ مشروعًا باسم Training وTarget `http://lab:8088/`، وأقر بأن هذا الهدف التدريبي مصرح به. جرّب Recon ثم Nmap ثم JavaScript Leaks ثم WhatWeb وNuclei وZAP من Web Assessment.

لـTLS أنشئ مشروعًا ثانيًا بالهدف `https://lab:8443/`، ثم اختر TLS Assessment. شهادة التدريب موقعة ذاتيًا عمدًا؛ ظهور مشاكل الثقة في الشهادة نتيجة حقيقية متوقعة. لا تتوقع نتيجة «آمنة» مصطنعة.

**داخل Docker، لا تستخدم localhost للوصول إلى برنامج على Windows.** استخدم `http://host.docker.internal:PORT/` للبرنامج المصرح به على جهازك، وتأكد من أنه يقبل الاتصال من Docker وأن جدار الحماية يسمح به. استخدم `lab` فقط لخدمة التدريب المرفقة. لا يلزم فتح التطبيق على الشبكة العامة.

## الأدوات والتغطية

| الوظيفة | التنفيذ الفعلي | حدود التغطية الافتراضية |
|---|---|---|
| Reconnaissance | وظائف HunterKit المنقولة مع Jobs الحالية | Subfinder وHTTPX وScreenshots وWayback وJS Resources وParameters، مع DNS/HTTP منفصل |
| Subfinder / Wayback | ملفات تنفيذ أصلية + CDX/Common Crawl | الأهداف المحلية Skipped؛ النطاقات العامة لم تختبر بعد؛ اكتشافها لا يمنح تفويض فحص نشط |
| Screenshots | Chromium/Playwright داخل Docker | sandbox مفعّل، origin محدد وصورة مستقلة لكل Job |
| Nmap | Native Nmap TCP connect + service detection | Profiles سريع/أساسي/تفصيلي؛ منفذ الهدف أو قائمة TCP محددة يقر المستخدم بتفويضها؛ لا shell flags |
| JavaScript Leaks | تحليل نصي محلي بدون تنفيذ JS | 12 ملفًا من نفس origin، 2 MiB لكل استجابة، inline scripts، مؤشرات وأسماء endpoints |
| WhatWeb | Native Ruby/WhatWeb | aggression 1، دون اتباع redirects |
| TLS | testssl.sh 3.2.1 | JSON مستقل لكل Job، شهادة وبروتوكولات وإعدادات متاحة؛ 240 ثانية كحد أقصى |
| Nuclei | 3.11.1 + upstream signed templates 10.5.0 | profile محدد من 3 قوالب: phpMyAdmin وmissing headers وGit configuration؛ ليس كامل مكتبة CVEs |
| OWASP ZAP | Native ZAP 2.17.0 + Java داخل نفس الحاوية | spider وpassive؛ active SQLi/XSS محدود على http://juice-shop:3000 فقط |

نُقلت وظائف Recon من HunterKit في المراجعة الحالية؛ راجع [تقرير النقل وحدوده](docs/revision/RECON-PORT.ar.md). لا تتضمن النسخة sqlmap أو Dalfox أو Wapiti. يوجد DAST محلي محدود ونموذج تصنيف أنواع نتائج مدرّب، دون ادعاء اكتشاف مستقل للثغرات. اختبار إصدارات أدوات الاكتشاف العام ليس إثباتًا لنجاح فحص نطاق عام.

## النتائج وحالات التنفيذ

- `queued`: سُجلت العملية وتنتظر أحد مقعدين للتنفيذ. الحد الأقصى للطابور 20.
- `running`: بدأ تنفيذ هذه العملية بالفعل.
- `completed`: انتهى التنفيذ بنجاح وتحقق المحلل من اكتمال المخرج المطلوب وحُفظت النتائج.
- `failed`: فشل بدء الأداة أو الاتصال أو التحليل أو حفظ النتيجة. لا تُعرض نتائج قديمة بدلًا منها.
- `timeout`: انتهت مهلة التنفيذ، أو أبلغت الأداة عن مهلة اتصال/قراءة معروفة.
- `partial`: التغطية غير مكتملة أو استُخدم fallback بعد تعذر الأداة؛ تعرض الأدلة المتاحة والتحذير دون ادعاء اكتمال.
- `skipped`: الوظيفة غير منطبقة على هذا الهدف؛ لم تُنفذ.
- `cancelled`: أُلغي الطلب؛ تُنهى مجموعة العملية وتُحتفظ برسالة الإلغاء.

المنافذ المفتوحة observations وليست إثبات ثغرات. نتائج Nuclei وZAP وtestssl هي تقارير أدوات تحتاج مراجعة. مؤشرات الأسرار غير مؤكدة وقيمها مخفية؛ لا تُجرب بيانات الاعتماد. توقعات ML منفصلة عن الأدلة؛ دقة Test الفعلية 87.27% وMacro F1 مقدارها 0.8513 لتصنيف تسعة أنواع من أوصاف advisories، وليست قياسًا لدقة اكتشاف ثغرات المواقع. انظر [الخطة الأكاديمية](docs/ACADEMIC.ar.md).

النتائج والتقارير JSON/CSV/PDF مرتبطة بـJob ID. يمكن تنزيل المخرج المنقح من صفحة تفاصيل العملية. PDF مولد محليًا داخل Chromium ومختبر، مع فصل تنبؤات النموذج عن النتائج الأصلية. تُعطَّل صيغ CSV الخطرة وتُنقح أنماط الأسرار الشائعة، لكن لا يُعد ذلك ضمانًا لإخفاء كل نوع أسرار ممكن؛ راجع التقارير قبل مشاركتها.

## التشغيل والإيقاف والتحديث

```powershell
docker compose logs --tail=100 app
docker compose stop
docker compose --profile training up -d
```

البيانات محفوظة في volume باسم `arstt-data`. لا تستخدم `docker compose down -v` إلا إذا أردت حذف بياناتك صراحةً. لا توجد أزرار حذف بيانات في الواجهة.

عند تعديل المصادر: `docker compose up --build -d`. عند تعطل فحص، افتح **Execution log** للعملية نفسها، أو قسم المتطلبات داخل About لمراجعة المتطلبات. لا تعامل ظهور الصفحة أو جاهزية executable كدليل على نجاح فحص.

## إعادة الاختبارات

```powershell
docker compose exec app npm test
docker compose exec app npm run test:tools
docker compose exec app npm run test:recon
```

اختبارات الأدوات تستخدم خوادم تدريب محلية داخل الحاوية نفسها، وتشغّل الأدوات الحقيقية، ثم تختبر الفشل والمهلة وعزل النتائج. الاختبار الكامل يشغّل TLS مرتين، وقد يستغرق عدة دقائق. الأدلة JSON تُكتب إلى `/app/artifacts`؛ لنسخها:

```powershell
docker compose cp app:/app/artifacts ./test-artifacts
```

اختبار المتصفح يحتاج Chromium على جهاز Linux المستخدم للاختبار، ويشمل شاشة 320/390/768/1440 والتنقل والتصدير. الحاوية الإنتاجية تحتوي Chromium لتصدير PDF وScreenshots داخل sandbox.

## تطوير محلي على Linux

Node 24+، Python 3، Nmap وWhatWeb وRuby وJava 17+ وOpenSSL وPerl وhexdump مطلوبة. تثبيت أدوات النظام على Debian/Ubuntu متاح في Dockerfile. ثم:

```bash
npm ci
npm run setup:tools
npm run doctor
npm run build
npm start
```

تُقرأ `.env` فقط عند تشغيل Node بخيار `--env-file=.env`؛ الملف `.env.example` مثال اختياري وليس مطلوبًا مع Docker. `npm run dev` يشغّل Vite على5175 والخادم على4311 معًا، مع proxy للـAPI وتحديث ملفات التطوير. لا يتطلب بناء الواجهة مسبقًا. المنفذ4310 يظل للنسخة المبنية/Docker.

هذه خدمة محلية لمستخدم واحد، وليست SaaS متعددة المستخدمين. session cookies وCSRF وقيود origin تحمي واجهة المتصفح المحلية، ولا تُغني عن مصادقة حقيقية وعزل الشبكات إذا قررت نشرها خارجيًا. لا تنشرها على الإنترنت بإعداداتها الحالية.

انظر [البنية وعقود API](docs/ARCHITECTURE.ar.md)، [اختبارات التسليم](docs/VERIFICATION.ar.md)، و[تراخيص الأطراف الثالثة](docs/THIRD-PARTY.md).

## Juice Shop المحلي

خدمة التدريب الجديدة تحت profile training. أنشئ مشروعًا مصرحًا به للهدف `http://juice-shop:3000/` من داخل ARSTT. هذه الخدمة على شبكة تدريب داخلية. لا تستخدم نسخة demo العامة للاختبارات المؤثرة. اختُبرت أدوات Recon والفحص وZAP النشط المحدود واختبار وصول حساب إلى سلة حساب آخر فعليًا داخل المختبر المعزول.

## المزايا المكملة والتدريب

- داخل Web: WhatWeb وNuclei وZAP passive وTLS وJS Leaks وSecurity Headers وCookie Security.
- داخل Attack: CORS وAPI observations وZAP active محلي محدود واختبار وصول بين حسابين مؤقتين في Juice Shop. الاختبارات المؤثرة مقفلة في الخادم على origin المختبر حرفيًا. لا تستخدم نطاق الجامعة أو أي هدف غير مصرح به.
- Results: سجل مستقل، dedup للعرض دون حذف الأصل، حالة مراجعة، مقارنة عمليات مكتملة من نفس الهدف والأداة وProfile، وتقارير فعلية.
- Dashboard يحسب آخر نتائج كل أداة للهدف الحالي. Review Index موزون معلن وليس احتمال استغلال؛ نقص التغطية لا يعرض كأمان.
- CVE lookup عند توفر إصدار حقيقي: NVD أو index محلي من GitHub Advisories؛ التطابق مرشح للمراجعة ولا يؤكد قابلية الاستغلال.
- النموذج محلي بلا API Key. `models/` يتضمن artifact مدرّبًا ونتائج Test ومصدر البيانات وترخيص CC-BY-4.0. تعليمات إعادة التدريب في `docs/ACADEMIC.ar.md`.

لتجربة المختبر أنشئ هدفًا `http://juice-shop:3000/` داخل الواجهة بعد تشغيل profile training. افتح Juice Shop من Windows عبر `http://localhost:3000`. ظهور Subfinder/Wayback بحالة Skipped على اسم داخلي متوقع؛ ليستا عدّادي نطاقات داخلية.

اختبارات التكامل الإضافية من بيئة التطوير: `npm run test:full`، ثم `node --import tsx tests/deployment.acceptance.ts` و`node --import tsx tests/full-browser.acceptance.ts` مع التطبيق والمختبر عاملين. اختبارات deployment تنشئ سجلات وحسابات تدريب فعلية داخل المختبر فقط.

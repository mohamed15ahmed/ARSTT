import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { EventEmitter } from 'node:events';
import type { Finding, Job, Project, Status, ToolId, Log } from './types.js';
import { redact } from './safety.js';
export class Store {
  db: DatabaseSync; events = new EventEmitter();
  constructor(public dir: string) {
    mkdirSync(dir, {recursive: true, mode: 0o700});
    this.db = new DatabaseSync(path.join(dir, 'arstt.sqlite'));
    this.db.exec(`PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;
      CREATE TABLE IF NOT EXISTS projects(id TEXT PRIMARY KEY, name TEXT NOT NULL, origin TEXT NOT NULL, authorizedAt TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY, projectId TEXT NOT NULL REFERENCES projects(id), tool TEXT NOT NULL, target TEXT NOT NULL, status TEXT NOT NULL, createdAt TEXT NOT NULL, startedAt TEXT, endedAt TEXT, error TEXT, findings TEXT NOT NULL DEFAULT '[]', rawAvailable INTEGER NOT NULL DEFAULT 0);
      CREATE TABLE IF NOT EXISTS logs(seq INTEGER PRIMARY KEY AUTOINCREMENT, jobId TEXT NOT NULL REFERENCES jobs(id), time TEXT NOT NULL, level TEXT NOT NULL, message TEXT NOT NULL);
      CREATE INDEX IF NOT EXISTS jobs_project ON jobs(projectId,createdAt); CREATE INDEX IF NOT EXISTS logs_job ON logs(jobId,seq);`);
    this.db.exec(`CREATE TABLE IF NOT EXISTS finding_state(projectId TEXT NOT NULL REFERENCES projects(id), fingerprint TEXT NOT NULL, state TEXT NOT NULL, updatedAt TEXT NOT NULL, PRIMARY KEY(projectId,fingerprint));`);
    if(!this.db.prepare('PRAGMA table_info(jobs)').all().some((x:any)=>x.name==='profile'))this.db.exec("ALTER TABLE jobs ADD COLUMN profile TEXT NOT NULL DEFAULT 'basic'");
    this.db.exec('CREATE TABLE IF NOT EXISTS analysis_runs(id TEXT PRIMARY KEY, projectId TEXT NOT NULL REFERENCES projects(id), createdAt TEXT NOT NULL, result TEXT NOT NULL)');
    if(!this.db.prepare('PRAGMA table_info(projects)').all().some((x:any)=>x.name==='networkPorts')){this.db.prepare('VACUUM INTO ?').run(path.join(dir,'before-network-scope-'+Date.now()+'.sqlite'));this.db.exec("ALTER TABLE projects ADD COLUMN networkPorts TEXT NOT NULL DEFAULT ''");}
    // A previous process disappearing is a failure, never a completed scan.
    this.db.prepare("UPDATE jobs SET status='failed', error='Server stopped before the scan completed.', endedAt=? WHERE status IN ('queued','running')").run(new Date().toISOString());
  }
  projects(): Project[] { return this.db.prepare('SELECT * FROM projects ORDER BY authorizedAt DESC').all() as unknown as Project[]; }
  project(id: string): Project | undefined { return this.db.prepare('SELECT * FROM projects WHERE id=?').get(id) as unknown as Project | undefined; }
  addProject(name: string, origin: string, networkPorts=''): Project {
    const p = {id: randomUUID(), name, origin, networkPorts, authorizedAt: new Date().toISOString()};
    this.db.prepare('INSERT INTO projects(id,name,origin,authorizedAt,networkPorts) VALUES (?,?,?,?,?)').run(p.id, p.name, p.origin, p.authorizedAt,p.networkPorts!); return p;
  }
  decode(row: any): Job { return {...row, findings: JSON.parse(row.findings), rawAvailable: !!row.rawAvailable}; }
  jobs(projectId?: string): Job[] {
    const rows = projectId ? this.db.prepare('SELECT * FROM jobs WHERE projectId=? ORDER BY createdAt DESC').all(projectId) : this.db.prepare('SELECT * FROM jobs ORDER BY createdAt DESC').all();
    return rows.map(r => this.decode(r));
  }
  job(id: string): Job | undefined { const r = this.db.prepare('SELECT * FROM jobs WHERE id=?').get(id); return r ? this.decode(r) : undefined; }
  addJob(projectId: string, tool: ToolId, target: string,profile='basic') {
    const id = randomUUID(), now = new Date().toISOString();
    this.db.prepare("INSERT INTO jobs(id,projectId,tool,target,status,createdAt,profile) VALUES(?,?,?,?,'queued',?,?)").run(id, projectId, tool, target, now,profile);
    return this.job(id)!;
  }
  begin(id: string) { this.db.prepare("UPDATE jobs SET status='running',startedAt=? WHERE id=? AND status='queued'").run(new Date().toISOString(), id); this.events.emit(id); }
  finish(id: string, status: Status, findings: Finding[], error: string | null, rawAvailable: boolean) {
    this.db.prepare('UPDATE jobs SET status=?,findings=?,error=?,rawAvailable=?,endedAt=? WHERE id=?').run(status, JSON.stringify(findings), error ? redact(error) : null, rawAvailable ? 1 : 0, new Date().toISOString(), id); this.events.emit(id);
  }
  log(id: string, level: string, message: string) {
    if (!message.trim()) return;
    this.db.prepare('INSERT INTO logs(jobId,time,level,message) VALUES(?,?,?,?)').run(id, new Date().toISOString(), level, redact(message).slice(0, 5000)); this.events.emit(id);
  }
  logs(id: string, after = 0): Log[] { return this.db.prepare('SELECT seq,time,level,message FROM logs WHERE jobId=? AND seq>? ORDER BY seq LIMIT 500').all(id, after) as unknown as Log[]; }
  saveAnalysis(projectId:string,result:unknown){const id=randomUUID(),createdAt=new Date().toISOString();this.db.prepare('INSERT INTO analysis_runs VALUES(?,?,?,?)').run(id,projectId,createdAt,redact(JSON.stringify(result)));return {id,createdAt,result};}
  latestAnalysis(projectId:string){const row=this.db.prepare('SELECT * FROM analysis_runs WHERE projectId=? ORDER BY createdAt DESC LIMIT 1').get(projectId) as any;return row?{id:row.id,createdAt:row.createdAt,result:JSON.parse(row.result)}:null;}
  findingStates(projectId:string){return this.db.prepare('SELECT fingerprint,state,updatedAt FROM finding_state WHERE projectId=?').all(projectId);}
  setFindingState(projectId:string,fingerprint:string,state:string){this.db.prepare('INSERT INTO finding_state VALUES(?,?,?,?) ON CONFLICT(projectId,fingerprint) DO UPDATE SET state=excluded.state,updatedAt=excluded.updatedAt').run(projectId,fingerprint,state,new Date().toISOString());}
  close() { this.db.close(); }
}

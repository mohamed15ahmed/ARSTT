import {XMLParser, XMLValidator} from 'fast-xml-parser';
import type {Finding, Severity} from './types.js';
import {DeadlineError} from './process.js';
const list = (x: any): any[] => x == null ? [] : Array.isArray(x) ? x : [x];
const info = (title:string, kind:string, source:string, evidence:string, severity: Severity = 'info', verification:Finding['verification'] = 'observation'): Finding => ({title,kind,source,evidence,severity,verification});
export function nmap(raw:string): Finding[] {
  if (XMLValidator.validate(raw) !== true) throw new Error('Nmap returned incomplete or malformed XML.');
  const x = new XMLParser({ignoreAttributes:false,attributeNamePrefix:''}).parse(raw).nmaprun;
  if (x?.runstats?.finished?.exit !== 'success' || Number(x.runstats.hosts?.total) < 1) throw new Error('Nmap did not complete a scan of a resolved host.');
  if(list(x.host).some(h=>String(h.timedout)==='true'))throw new DeadlineError();
  return list(x.host).flatMap(h => list(h.ports?.port).filter(p=>p.state?.state==='open').map(p => info(`${p.portid}/${p.protocol} open`, 'Open port', String(list(h.address)[0]?.addr ?? 'Unknown'), JSON.stringify({port:Number(p.portid),protocol:p.protocol,service:p.service?.name ?? 'Unknown',product:p.service?.product ?? null,version:p.service?.version ?? null,extra:p.service?.extrainfo ?? null,cpe:p.service?.cpe??null}))));
}
export function whatweb(raw:string, target:string): Finding[] {
  const rows = JSON.parse(raw);
  if (!Array.isArray(rows) || !rows.length || !rows.some(r=>r.http_status && new URL(r.target).origin===new URL(target).origin)) throw new Error('WhatWeb did not return a valid HTTP fingerprint for this target.');
  return rows.flatMap(r=>Object.entries(r.plugins ?? {}).map(([name,value]) => info(name,'Technology',String(r.target),JSON.stringify(value))));
}
export function tls(raw:string, target:string): Finding[] {
  const rows = JSON.parse(raw);
  if (!Array.isArray(rows) || !rows.some(x=>x.id==='scanTime') || rows.some(x=>x.id==='scanProblem' || x.severity==='FATAL')) throw new Error('testssl.sh did not produce a complete TLS report. Check connectivity and TLS support.');
  return rows.filter(x=>x.id !== 'scanTime').map(x => info(String(x.id), String(x.severity)==='OK' ? 'Positive TLS observation' : ['WARN','LOW','MEDIUM','HIGH','CRITICAL'].includes(x.severity) ? 'TLS review' : 'TLS observation',String(x.ip ? `${x.ip}:${x.port}` : target),String(x.finding), ({LOW:'low',MEDIUM:'medium',HIGH:'high',CRITICAL:'critical',WARN:'unknown'} as Record<string,Severity>)[x.severity] ?? 'info','tool-reported'));
}
export function nuclei(raw:string, log:string, target:string): Finding[] {
  const stats = log.split(/\r?\n/).flatMap(l=>{ try {const x=JSON.parse(l); return x.requests != null && x.templates != null && Number.isFinite(Number(x.requests)) && Number.isFinite(Number(x.templates)) ? [x] : [];} catch{return [];} });
  if (!stats.some(s=>s.requests>0 && s.templates>0) || stats.some(s=>Number(s.errors)>0) || /\[(?:ERR|FTL)\]/.test(log)) throw new Error('Nuclei coverage could not be confirmed or requests/templates failed; an empty report is not proof of a clean scan.');
  return raw.trim().split('\n').filter(Boolean).map(l=>{ const x=JSON.parse(l); if(!x.info || !x['template-id']) throw new Error('Invalid Nuclei finding.'); return {...info(String(x.info.name),'Template match',String(x['matched-at'] || target),JSON.stringify({description:x.info.description||'',template:x['template-id'],matcher:x['matcher-name'],extracted:x['extracted-results']}), ['info','low','medium','high','critical'].includes(x.info.severity) ? x.info.severity : 'unknown','tool-reported'),recommendation:String(x.info.remediation||'Review the template description and vendor advisory; validate impact and apply the vendor-supported fix.'),references:list(x.info.reference).filter(x=>typeof x==='string' && /^https?:\/\//.test(x))}; });
}
export function zap(raw:string, target:string): Finding[] {
  const x=JSON.parse(raw); if (!Array.isArray(x.site) || !x.site.some((s:any)=>new URL(s['@name']).origin===new URL(target).origin)) throw new Error('ZAP report contains no matching scanned site.');
  return x.site.flatMap((s:any)=>list(s.alerts).map(a=>({...info(String(a.name || a.alert),'Passive alert',String(s['@name']),JSON.stringify({description:a.desc,solution:a.solution,instances:a.instances,cwe:a.cweid,confidence:a.confidence}),({0:'info',1:'low',2:'medium',3:'high'} as Record<string,Severity>)[a.riskcode] ?? 'unknown','tool-reported'),recommendation:String(a.solution||'Review the ZAP alert evidence and applicable remediation.').replace(/<[^>]*>/g,' '),references:String(a.reference || '').match(/https?:\/\/[^\s<>"']+/g) ?? []})));
}

import {createHash} from 'node:crypto';import type {Finding,Job} from './types.js';import {InputError} from './safety.js';
import fs from 'node:fs/promises';
let advisoryIndex:any;
async function localCandidates(product:string){
 if(!advisoryIndex)advisoryIndex=JSON.parse(await fs.readFile('models/advisory-index.json','utf8'));
 const tokens=product.toLowerCase().match(/[a-z0-9]{3,}/g)?.filter(t=>!['http','server','framework','apache','service'].includes(t))||[];
 if(!tokens.length)return [];
 return advisoryIndex.advisories.filter((a:any)=>{const text=(a.summary+' '+a.affected.map((p:any)=>p.name).join(' ')).toLowerCase();return tokens.every(t=>text.includes(t));}).slice(0,10);
}
export const fingerprint=(j:Job,f:Finding)=>f.fingerprint||createHash('sha256').update(JSON.stringify([j.tool,f.kind,f.title,f.source])).digest('hex');
export function classification(j:Job,f:Finding){
 if(j.tool==='access-control'&&new URL(j.target).origin==='http://juice-shop:3000'&&f.kind==='Access-control evidence'){
  try{if(JSON.parse(f.evidence).crossUserReadReturnedFirstUserObject===true)return 'Confirmed';}catch{}
 }
 return f.verification==='potential'||(f.verification==='tool-reported'&&['low','medium','high','critical'].includes(f.severity))?'Potential':'Informational';
}
export function overview(jobs:Job[]){
 const latest=new Map<string,Job>();for(const j of [...jobs].sort((a,b)=>b.createdAt.localeCompare(a.createdAt)))if(!latest.has(j.tool+'|'+j.target))latest.set(j.tool+'|'+j.target,j);
 const observations=new Map<string,{finding:Finding;jobId:string;tool:string;classification:string;fingerprint:string;relatedJobIds?:string[];relatedTools?:string[]}>();
 for(const j of latest.values())if(['completed','partial'].includes(j.status))for(const f of j.findings){const id=fingerprint(j,f);observations.set(id,{finding:f,jobId:j.id,tool:j.tool,classification:classification(j,f),fingerprint:id});}
 const grouped=new Map<string,(typeof observations extends Map<any,infer V>?V:never)>();const rank:Record<string,number>={critical:5,high:4,medium:3,low:2,unknown:1,info:0};
 for(const row of observations.values()){
  let header:string|undefined;let evidence:any;try{evidence=JSON.parse(row.finding.evidence);}catch{}
  if(row.finding.kind==='Header absent')header=row.finding.title;
  else if(evidence?.template==='http-missing-security-headers')header=evidence.matcher;
  else if(/not set|missing|absent/i.test(row.finding.title)){
   if(/content security policy|\bcsp\b/i.test(row.finding.title))header='content-security-policy';
   if(/strict.transport.security/i.test(row.finding.title))header='strict-transport-security';
   if(/content.type.options/i.test(row.finding.title))header='x-content-type-options';
  }
  let location=row.finding.source;try{const u=new URL(location);location=u.origin+u.pathname;}catch{}
  const key=header?'missing-policy:'+header+':'+location:row.fingerprint;const old=grouped.get(key);
  if(!old)grouped.set(key,{...row,relatedJobIds:[row.jobId],relatedTools:[row.tool]});
  else{const primary=rank[row.finding.severity]>rank[old.finding.severity]?row:old;grouped.set(key,{...primary,relatedJobIds:[...new Set([...(old.relatedJobIds||[]),row.jobId])],relatedTools:[...new Set([...(old.relatedTools||[]),row.tool])]});}
 }
 const rows=[...grouped.values()],severity=Object.fromEntries(['critical','high','medium','low','info','unknown'].map(s=>[s,rows.filter(r=>r.finding.severity===s&&r.classification!=='Informational').length]));
 const weight:Record<string,number>={critical:10,high:7,medium:4,low:1,info:0,unknown:0};const weighted=rows.reduce((n,r)=>n+(r.classification==='Informational'?0:weight[r.finding.severity]),0);
 const incomplete=[...latest.values()].filter(j=>j.status!=='completed');
 const count=(kinds:string[])=>new Set(rows.filter(r=>kinds.includes(r.finding.kind)).map(r=>r.finding.source+'|'+r.finding.title)).size;
 return {totalScans:jobs.length,statuses:Object.fromEntries(['completed','failed','timeout','partial','skipped','cancelled','queued','running'].map(s=>[s,jobs.filter(j=>j.status===s).length])),observations:rows,severity,
  assets:count(['Discovered subdomain','IPv4 address','IPv6 address','Live URL']),endpoints:count(['Endpoint reference','Archived URL','Parameter URL','Discovered resource']),ports:count(['Open port']),
  reviewIndex:weighted>0?Math.round(100*(1-Math.exp(-weighted/30))):null,reviewIndexFormula:'100 × (1 − exp(−weightedSum/30)); critical10, high7, medium4, low1; unique latest tool/target findings only. Review priority, NOT probability or proof of safety. No weighted evidence => not estimated, never a safe zero.',
  coverage:{latestJobs:latest.size,completed:[...latest.values()].filter(j=>j.status==='completed').length,incomplete:incomplete.map(j=>({id:j.id,tool:j.tool,status:j.status,error:j.error})),interpretation:'Unrun tools and failed/partial jobs do not establish safety. Coverage is of recorded tool/target pairs, not the entire application.'},latestJobs:[...latest.values()].slice(0,10)};
}
export function compare(before:Job,after:Job){
 if(before.projectId!==after.projectId||before.target!==after.target||before.tool!==after.tool||before.profile!==after.profile)throw new InputError('Compare scans of the same project, exact target, tool and profile.');
 if(before.status!=='completed'||after.status!=='completed')throw new InputError('A failed, partial or incomplete scan cannot establish that previous findings were resolved.');
 const a=new Map(before.findings.map(f=>[fingerprint(before,f),f])),b=new Map(after.findings.map(f=>[fingerprint(after,f),f]));
 const content=(f:Finding)=>JSON.stringify([f.evidence,f.severity,f.recommendation]);
 return {beforeId:before.id,afterId:after.id,added:[...b].filter(([id])=>!a.has(id)).map(([,f])=>f),removed:[...a].filter(([id])=>!b.has(id)).map(([,f])=>f),changed:[...b].filter(([id,f])=>a.has(id)&&content(a.get(id)!)!==content(f)).map(([id,f])=>({before:a.get(id),after:f})),unchanged:[...b].filter(([id,f])=>a.has(id)&&content(a.get(id)!)===content(f)).map(([,f])=>f),interpretation:'Removed means not observed in the later scan; it is not independent verification of remediation.'};
}
const cveCache=new Map<string,{at:number;value:any}>();
export async function knownCVEs(job:Job){
 const cached=cveCache.get(job.id);if(cached&&Date.now()-cached.at<600000)return cached.value;
 if(job.tool!=='nmap'||job.status!=='completed')throw new InputError('CVE enrichment requires a completed Nmap scan.');
 const rows=[];for(const f of job.findings.slice(0,5)){
  let service:any;try{service=JSON.parse(f.evidence);}catch{continue;}
  if(!service.product||!service.version){rows.push({finding:f.title,status:'insufficient-version-data',cves:[]});continue;}
  const query=String(service.product)+' '+String(service.version);const u=new URL('https://services.nvd.nist.gov/rest/json/cves/2.0');u.search=new URLSearchParams({keywordSearch:query,resultsPerPage:'10'}).toString();
  try{const r=await fetch(u,{signal:AbortSignal.timeout(15000)});if(!r.ok)throw new Error('NVD HTTP '+r.status);const x=await r.json() as any;rows.push({finding:f.title,query,status:'lookup-completed',cves:(x.vulnerabilities||[]).map((v:any)=>({id:v.cve.id,description:v.cve.descriptions?.find((d:any)=>d.lang==='en')?.value,reference:'https://nvd.nist.gov/vuln/detail/'+v.cve.id})),interpretation:'Keyword/version candidates only. Check CPE, affected ranges, backports and configuration. This does not confirm exploitability.'});}
  catch(e){let candidates:any[]=[];try{candidates=await localCandidates(String(service.product));}catch{}
   rows.push({finding:f.title,query,status:candidates.length?'local-advisory-candidates':'source-unavailable',error:(e as Error).message,cves:[],localSource:candidates.length?{name:'GitHub Advisory Database',commit:advisoryIndex.commit,license:advisoryIndex.license}:null,candidates,interpretation:'Local product-keyword candidates are not version-range or CPE confirmations. Review affected ranges, ecosystem, backports and vendor notices. An unavailable upstream source is not a clean result.'});}
 }
 const result={jobId:job.id,checkedAt:new Date().toISOString(),source:'NIST NVD CVE API 2.0 / local reviewed advisory fallback',rows};cveCache.set(job.id,{at:Date.now(),value:result});return result;
}

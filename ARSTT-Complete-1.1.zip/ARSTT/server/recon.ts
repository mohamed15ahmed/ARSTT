/** HunterKit Recon port: same CLI contracts, current-site/archive inventory and
 * separate screenshot stage. All execution uses ARSTT's one process/job engine.
 * See docs/revision/RECON-PORT.ar.md for scope and deliberate corrections. */
import fs from 'node:fs/promises';import path from 'node:path';import {isIP} from 'node:net';import dns from 'node:dns/promises';
import {chromium} from 'playwright-core';
import {load} from 'cheerio';
import {execute} from './process.js';import {executable} from './tools.js';import {request} from './web-analysis.js';
import {redact} from './safety.js';import type {Finding,Job,ToolId} from './types.js';
export const reconTools=['subfinder','httpx','screenshots','wayback','recon-js','parameters'] as const;
export class NotApplicable extends Error {}
type Context={target:URL;work:string;signal:AbortSignal;log:(level:string,text:string)=>void;history:Job[]};
type Result={findings:Finding[];raw:string;attachments?:string[];coverage?:'partial'|'complete';warnings?:string[]};
function privateHost(host:string){return host==='localhost'||host==='::1'||!host.includes('.')&&!isIP(host)||/^(?:127\.|10\.|192\.168\.|172\.(?:1[6-9]|2\d|3[01])\.)/.test(host);}
function observe(title:string,kind:string,source:string,evidence:string):Finding{return {title,kind,source,evidence,severity:'info',verification:'observation'};}
function scoped(value:string,target:URL):URL|undefined{try{const u=new URL(value,target);return u.origin===target.origin&&!u.username&&!u.password?u:undefined;}catch{return;}}
function lines(raw:string){return [...new Set(raw.split(/\r?\n/).map(s=>s.trim()).filter(Boolean))];}
async function providerText(url:URL,signal:AbortSignal){
 const r=await fetch(url,{signal:AbortSignal.any([signal,AbortSignal.timeout(12000)])});if(!r.ok){await r.body?.cancel();throw new Error(`${url.hostname}: HTTP ${r.status}`);}
 const parts:Uint8Array[]=[];let size=0;if(r.body)for await(const chunk of r.body as any){size+=chunk.length;if(size>2*1024*1024)throw new Error('Passive archive response exceeds 2 MiB.');parts.push(chunk);}return Buffer.concat(parts).toString('utf8');
}
async function command(tool:ToolId,args:string[],c:Context,input?:string,timeout=60000){
 const exe=await executable(tool);c.log('command',JSON.stringify({executable:exe,args,stdin:input?'Authorized hostname via STDIN':undefined}));
 const p=await execute(exe,args,{input,cwd:c.work,signal:c.signal,timeout,log:c.log,env:{XDG_CONFIG_HOME:path.join(c.work,'config'),XDG_CACHE_HOME:path.join(c.work,'cache')}});
 if(p.code!==0)throw new Error(`${tool} exited ${p.code}: ${p.stderr.slice(-1200)}`);return p;
}
async function inventory(c:Context){
 const found=new Set<string>(),formURLs=new Set<string>(),seen=new Set<string>(),warnings:string[]=[],queue=[c.target.href];
 while(queue.length&&seen.size<12){
  if(c.signal.aborted)throw c.signal.reason;const url=queue.shift()!;if(seen.has(url))continue;seen.add(url);
  try{const page=await request(new URL(url),c.signal);found.add(page.finalURL.href);const $=load(page.body);
   $('[href],[src],[action]').each((_i,element)=>{for(const attribute of ['href','src','action']){
    const value=$(element).attr(attribute);if(!value||value.length>2048)continue;const u=scoped(value,page.finalURL);if(!u)continue;u.hash='';found.add(u.href);
    if(element.tagName==='a'&&!u.search&&!/\.(?:m?js|css|png|jpe?g|gif|svg|woff2?|pdf|zip)$/i.test(u.pathname)&&!/logout|delete|remove|destroy|reset/i.test(u.pathname)&&!seen.has(u.href)&&queue.length+seen.size<12)queue.push(u.href);
   }});
   $('form').each((_i,element)=>{const form=$(element);if((form.attr('method')||'get').toLowerCase()!=='get')return;const u=scoped(form.attr('action')||page.finalURL.href,page.finalURL);if(!u)return;
    form.find('input[name],select[name],textarea[name]').each((_j,input)=>{const field=$(input),type=(field.attr('type')||'').toLowerCase();if(field.is('[disabled]')||['submit','button','reset','file','password'].includes(type))return;if(['checkbox','radio'].includes(type)&&!field.is('[checked]'))return;u.searchParams.append(field.attr('name')!,'');});
    if(u.search){formURLs.add(u.href);found.add(u.href);} // Reference only: never submit forms or request these synthetic URLs.
   });
  }catch(e){if(c.signal.aborted)throw e;warnings.push(`${new URL(url).pathname}: ${(e as Error).message}`);}
 }
 if(!found.size)throw new Error('Current-site inventory failed: '+warnings.join('; '));
 const archive=c.history.filter(j=>j.tool==='wayback'&&j.status==='completed'&&new URL(j.target).origin===c.target.origin).sort((a,b)=>b.createdAt.localeCompare(a.createdAt))[0];
 if(archive)for(const f of archive.findings){const u=scoped(f.source,c.target);if(u)found.add(u.href);}
 return {urls:[...found].slice(0,2000),formURLs:[...formURLs],visited:[...seen],warnings,archiveJobId:archive?.id??null};
}
export async function runRecon(tool:ToolId,c:Context):Promise<Result>{
 const host=c.target.hostname.replace(/^\[|\]$/g,'');
 if(tool==='subfinder'){
  if(isIP(host)||privateHost(host))throw new NotApplicable('Subfinder is not applicable to IP, localhost or a private training hostname. No passive enumeration was run.');
  const p=await command('subfinder',['-silent','-d',host],c,undefined,120000);
  if(/\[(?:ERR|FTL)\]/i.test(p.stderr))throw new Error('Subfinder reported a provider/runtime error: '+p.stderr.slice(-700));
  const domains=lines(p.stdout).map(s=>s.toLowerCase()).filter(s=>/^[a-z0-9.-]+$/.test(s)&&(s===host||s.endsWith('.'+host)));
  return {findings:domains.map(s=>observe(s,'Discovered subdomain',s,'Passive Subfinder discovery. This does not authorize active scanning of the discovered host.')),raw:JSON.stringify({provider:'subfinder',domains,activeProbePerformed:false})};
 }
 if(tool==='httpx'){
  const input=path.join(c.work,'httpx-input.txt'),output=path.join(c.work,'httpx-output.txt');await fs.writeFile(input,c.target.href+'\n');
  let processError:string|null=null,outputURLs:string[]=[];
  try{const p=await command('httpx',['-silent','-duc','-timeout','8','-retries','1','-l',input,'-o',output],c,undefined,30000);outputURLs=lines(p.stdout+'\n'+await fs.readFile(output,'utf8').catch(()=>''));}catch(e){if(c.signal.aborted)throw e;processError=(e as Error).message;c.log('warning',processError);}
  const urls=outputURLs.flatMap(s=>{const u=scoped(s,c.target);return u?[u.href]:[];});
  if(urls.length)return {findings:[...new Set(urls)].map(u=>observe(u,'Live URL',u,'Responded through ProjectDiscovery HTTPX; status details were not requested.')),raw:JSON.stringify({source:'httpx',urls:[...new Set(urls)],processError})};
  // HunterKit's fallback remains explicit: never claim that HTTPX succeeded if it failed.
  c.log('progress','HTTPX returned no scoped live URLs. Running the bounded HTTP fallback.');
  const r=await request(c.target,c.signal,{allowErrorStatus:true});
  return {coverage:'partial',warnings:[processError||'HTTPX returned no usable result; bounded HTTP fallback used.'],findings:[observe(`HTTP ${r.status}`,'Live URL',r.finalURL.href,'HTTP fallback response; HTTPX produced no usable result. '+(processError||''))],raw:JSON.stringify({source:'http-fallback',httpStatus:r.status,url:r.finalURL.href,httpxError:processError})};
 }
 if(tool==='wayback'){
  if(isIP(host)||privateHost(host))throw new NotApplicable('Public archive enumeration is domain-based; IP and local/private training targets are not enumerated. JS and Parameters still inspect the current site.');
  let raw='',error:string|null=null;
  try{raw=(await command('wayback',[],c,host+'\n',60000)).stdout;}catch(e){if(c.signal.aborted)throw e;error=(e as Error).message;c.log('warning',error);}
  let urls=lines(raw).flatMap(s=>{const u=scoped(s,c.target);return u?[u.href]:[];});let source='waybackurls';
  if(!urls.length){
   const endpoint=new URL('https://web.archive.org/cdx/search/cdx');endpoint.search=new URLSearchParams({url:host+'/*',output:'json',fl:'original',collapse:'urlkey',limit:'2000'}).toString();
   c.log('progress','Querying passive Wayback CDX fallback. No archived URL is actively fetched.');
   try{const data=JSON.parse(await providerText(endpoint,c.signal));if(!Array.isArray(data))throw new Error('Invalid Wayback CDX response');
    urls=data.slice(1).flatMap((row:any)=>{const u=scoped(String(row[0]),c.target);return u?[u.href]:[];});source='wayback-cdx';
   }catch(e){if(c.signal.aborted)throw e;error=[error,(e as Error).message].filter(Boolean).join('; ');source='none';c.log('warning',(e as Error).message);}
   if(!urls.length){
    try{const indexes=JSON.parse(await providerText(new URL('https://index.commoncrawl.org/collinfo.json'),c.signal));
     const index=new URL(indexes[0]?.['cdx-api']);if(index.protocol!=='https:'||index.hostname!=='index.commoncrawl.org')throw new Error('Unexpected Common Crawl index endpoint');
     index.search=new URLSearchParams({url:host+'/*',output:'json',pageSize:'100'}).toString();
     const data=await providerText(index,c.signal);urls=lines(data).flatMap(row=>{const u=scoped(String(JSON.parse(row).url),c.target);return u?[u.href]:[];});source='common-crawl';
    }catch(e){if(c.signal.aborted)throw e;if(source==='none')throw new Error(`All passive archive providers failed: ${error}; ${(e as Error).message}`);c.log('warning','Common Crawl fallback unavailable: '+(e as Error).message);}
   }
  }
  urls=[...new Set(urls)].slice(0,2000);return {findings:urls.map(u=>observe(new URL(u).pathname,'Archived URL',u,'Passive historical reference; current existence and security are not verified.')),raw:JSON.stringify({source,urls,cliError:error})};
 }
 if(tool==='recon-js'||tool==='parameters'){
  const data=await inventory(c);const urls=data.urls.filter(s=>tool==='recon-js'?/\.m?js(?:[?#]|$)/i.test(s):new URL(s).search.length>1);
  return {coverage:data.warnings.length?'partial':'complete',warnings:data.warnings,findings:urls.map(u=>observe(tool==='recon-js'?new URL(u).pathname:[...new Set(new URL(u).searchParams.keys())].join(', '),tool==='recon-js'?'JavaScript resource':'Parameter URL',u,JSON.stringify({inventory:'current-site + latest scoped archive',archiveJobId:data.archiveJobId,formReferenceOnly:data.formURLs.includes(u),parameterNames:[...new Set(new URL(u).searchParams.keys())]}))),raw:JSON.stringify({source:'current-site+archive',...data,matched:urls})};
 }
 if(tool==='screenshots'){
  // Explicit deployment setting for isolated LOCAL training only. Public targets
  // always require the browser sandbox; the API cannot override this setting.
  const training=process.env.ARSTT_LOCAL_TRAINING_BROWSER==='1'&&['lab','juice-shop','localhost','127.0.0.1','::1'].includes(host);
  c.log('progress',training?'Local training browser mode explicitly enabled; renderer sandbox unavailable in this isolated test environment.':'Browser sandbox required for this target.');
  c.log('command',JSON.stringify({driver:'Playwright',executable:process.env.ARSTT_BROWSER||'/usr/bin/chromium',chromiumSandbox:!training}));
  const browser=await chromium.launch({executablePath:process.env.ARSTT_BROWSER||'/usr/bin/chromium',headless:true,timeout:10000,chromiumSandbox:!training,args:training?['--disable-dev-shm-usage']:['--disable-dev-shm-usage','--disable-setuid-sandbox']});
  if(c.signal.aborted){await browser.close();throw c.signal.reason;}
  const abort=()=>{void browser.close();};c.signal.addEventListener('abort',abort,{once:true});
  try{const context=await browser.newContext({ignoreHTTPSErrors:false,viewport:{width:1366,height:900},serviceWorkers:'block'});
   await context.route('**/*',route=>{const u=scoped(route.request().url(),c.target);return u?route.continue():route.abort();});
   await context.routeWebSocket('**/*',socket=>socket.close());
   const page=await context.newPage();c.log('progress','Capturing the authorized origin. Off-origin requests and WebSockets are blocked.');
   const response=await page.goto(c.target.href,{timeout:20000,waitUntil:'domcontentloaded'});if(!response)throw new Error('Browser received no HTTP response.');
   await page.waitForLoadState('networkidle',{timeout:5000}).catch(()=>c.log('warning','Page network did not become idle within 5 seconds; the screenshot reflects the current rendered state.'));
   const file=path.join(c.work,'screenshot.png');await page.screenshot({path:file,timeout:15000,fullPage:false});
   return {findings:[observe('Target screenshot','Screenshot',c.target.href,`Browser HTTP ${response.status()}. View the job attachment; external resources were blocked.`)],raw:JSON.stringify({httpStatus:response.status(),url:page.url(),filename:'screenshot.png'}),attachments:[file]};
  }finally{c.signal.removeEventListener('abort',abort);await browser.close();}
 }
 throw new Error('Unknown Recon tool');
}

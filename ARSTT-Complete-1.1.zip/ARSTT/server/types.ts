export const toolIds = ['recon', 'subfinder', 'httpx', 'screenshots', 'wayback', 'recon-js', 'parameters', 'nmap', 'jsleaks', 'whatweb', 'tls', 'nuclei', 'zap','headers','cookies','cors','api-check','zap-active','access-control'] as const;
export type ToolId = typeof toolIds[number];
export type Status = 'queued' | 'running' | 'completed' | 'failed' | 'timeout' | 'cancelled' | 'skipped' | 'partial';
export type Severity = 'info' | 'low' | 'medium' | 'high' | 'critical' | 'unknown';
export interface Finding {
  title: string; kind: string; source: string; severity: Severity;
  evidence: string; verification: 'observation' | 'potential' | 'tool-reported'; references?: string[];
  fingerprint?:string; recommendation?:string;
}
export interface Project { id: string; name: string; origin: string; authorizedAt: string; networkPorts?:string; }
export interface Job {
  id: string; projectId: string; tool: ToolId; target: string; status: Status;
  createdAt: string; startedAt: string | null; endedAt: string | null;
  error: string | null; findings: Finding[]; rawAvailable: boolean;
  profile?:'quick'|'basic'|'detailed';
}
export interface Log { seq: number; time: string; level: string; message: string; }
export interface ToolHealth { id: ToolId; name: string; ready: boolean; version: string; detail: string; }
export const active = (s: Status) => s === 'queued' || s === 'running';

import {request} from './web-analysis.js';import {redact} from './safety.js';import type {Finding,ToolId} from './types.js';
export const checkTools=['headers','cookies','cors','api-check','access-control'];
function finding(title:string,kind:string,source:string,evidence:unknown,recommendation:string,severity:Finding['severity']='info'):Finding{return {title,kind,source,evidence:redact(JSON.stringify(evidence)),recommendation,severity,verification:severity==='info'?'observation':'potential'};}
export async function webCheck(tool:ToolId,target:URL,signal:AbortSignal,log:(m:string)=>void){
 log(`HTTP assessment of ${target.origin}${target.pathname}; no credentials supplied.`);const r=await request(target,signal,{allowErrorStatus:true}),findings:Finding[]=[];
 if(tool==='headers'){
  const rules=[['x-content-type-options','Use X-Content-Type-Options: nosniff.'],['referrer-policy','Choose an explicit Referrer-Policy appropriate for the application.'],...(/html/i.test(r.headers.get('content-type')||'')?[['content-security-policy','Define a Content-Security-Policy appropriate for the application; review script and frame sources.']]:[]),...(target.protocol==='https:'?[['strict-transport-security','Consider HSTS after verifying HTTPS deployment and subdomain requirements.']]:[])];
  for(const [header,fix] of rules){const value=r.headers.get(header);findings.push(finding(header,value?'Header observed':'Header absent',r.finalURL.href,{header,present:!!value,value:value||null,status:r.status},value?'Review the observed policy in the application context.':fix,value?'info':'low'));}
  const frame=r.headers.get('x-frame-options'),csp=r.headers.get('content-security-policy');if(/html/i.test(r.headers.get('content-type')||''))findings.push(finding('Framing policy',frame||/frame-ancestors/i.test(csp||'')?'Header observed':'Header absent',r.finalURL.href,{xFrameOptions:frame,frameAncestors:/frame-ancestors/i.test(csp||'')},'Use CSP frame-ancestors where framing restrictions are required.',frame||/frame-ancestors/i.test(csp||'')?'info':'low'));
 }
 if(tool==='cookies'){
  for(const header of r.headers.getSetCookie()){
   const parts=header.split(';').map(x=>x.trim()),name=parts[0].split('=')[0];const flags=parts.slice(1).map(x=>x.toLowerCase());const secure=flags.includes('secure'),httpOnly=flags.includes('httponly'),sameSite=flags.find(x=>x.startsWith('samesite='))?.split('=')[1]||null;
   const authLike=/session|auth|token|sid/i.test(name);const concerns=[...(!secure&&target.protocol==='https:'?['Secure absent on HTTPS']:[]),...(authLike&&!httpOnly?['HttpOnly absent on session-like cookie']:[]),...(!sameSite?['SameSite unspecified']:[]),...(sameSite==='none'&&!secure?['SameSite=None without Secure']:[])];
   findings.push(finding(name,'Cookie attributes',r.finalURL.href,{name,secure,httpOnly,sameSite,concerns,value:'[NOT COLLECTED]'},'For authentication cookies use Secure, HttpOnly and a suitable SameSite policy. JavaScript-readable non-authentication cookies may intentionally omit HttpOnly.',concerns.length?'low':'info'));
  }
  if(!findings.length)findings.push(finding('No Set-Cookie observed','Cookie coverage',r.finalURL.href,{httpStatus:r.status},'This unauthenticated response did not set a cookie. Login/session cookies were not assessed.'));
 }
 if(tool==='cors'){
  const origin='https://arstt-untrusted.invalid';const response=await fetch(target,{method:'OPTIONS',headers:{Origin:origin,'Access-Control-Request-Method':'GET'},redirect:'manual',signal:AbortSignal.any([signal,AbortSignal.timeout(10000)])});await response.body?.cancel();
  const allow=response.headers.get('access-control-allow-origin'),credentials=response.headers.get('access-control-allow-credentials');const reflected=allow===origin&&credentials==='true';
  findings.push(finding('CORS preflight response','CORS configuration',target.href,{status:response.status,allowOrigin:allow,allowCredentials:credentials,untrustedOriginReflectedWithCredentials:reflected},'Restrict credentialed CORS to explicitly trusted origins. Preflight reflection alone does not prove readable sensitive data.',reflected?'medium':'info'));
 }
 if(tool==='api-check'){
  let json=false;try{JSON.parse(r.body);json=true;}catch{}
  findings.push(finding('Unauthenticated API response','API observation',r.finalURL.href,{httpStatus:r.status,contentType:r.headers.get('content-type'),validJSON:json,wwwAuthenticate:r.headers.get('www-authenticate')},'Test the intended API endpoint with documented roles. HTTP 200 alone does not establish an authentication or authorization bypass.'));
  if(/SQL syntax.*MySQL|PostgreSQL.*ERROR|SQLITE_ERROR|Traceback \(most recent call last\)|System\.Data\.SqlClient/i.test(r.body))findings.push(finding('Database/error disclosure indicator','Error disclosure',r.finalURL.href,{httpStatus:r.status,indicator:'Known database or stack-trace pattern; response content not retained'},'Return generic errors and retain detailed traces in protected server logs. This indicator does not prove SQL injection.','medium'));
 }
 if(tool==='access-control'){
  // Reproducible safe cross-user IDOR test ONLY against the isolated Juice Shop lab.
  if(target.origin!=='http://juice-shop:3000'||process.env.ARSTT_LOCAL_DAST!=='1')throw new Error('Cross-user access testing requires the isolated Juice Shop service and ARSTT_LOCAL_DAST=1. It is never run on public targets.');
  const suffix=crypto.randomUUID().replaceAll('-','');const password='ARSTT-local-training-'+suffix;
  async function call(endpoint:string,method='GET',data?:unknown,token?:string,tolerateBlocked=false){const res=await fetch(new URL(endpoint,target),{method,headers:{'content-type':'application/json',...(token?{Authorization:'Bearer '+token}:{})},body:data===undefined?undefined:JSON.stringify(data),redirect:'error',signal:AbortSignal.any([signal,AbortSignal.timeout(10000)])});const text=await res.text();if(!res.ok&&tolerateBlocked&&[401,403,404].includes(res.status))return {blocked:true,status:res.status};if(!res.ok)throw new Error(`Training API ${endpoint} returned HTTP ${res.status}`);try{return JSON.parse(text);}catch{throw new Error('Training API returned invalid JSON');}}
  const accounts=[];for(const letter of ['a','b']){const email=`arstt-${suffix}-${letter}@example.invalid`;await call('/api/Users/','POST',{email,password,passwordRepeat:password,securityQuestion:{id:1,question:'Your eldest siblings middle name?'},securityAnswer:'local-training'});const login=await call('/rest/user/login','POST',{email,password});if(!login.authentication?.token||!login.authentication?.bid)throw new Error('Training login did not return the required session context');accounts.push(login.authentication);}
  await call('/api/BasketItems/','POST',{ProductId:1,BasketId:accounts[0].bid,quantity:1},accounts[0].token);
  const own=await call('/rest/basket/'+accounts[0].bid,'GET',undefined,accounts[0].token);await call('/rest/basket/'+accounts[1].bid,'GET',undefined,accounts[1].token);const cross=await call('/rest/basket/'+accounts[0].bid,'GET',undefined,accounts[1].token,true);
  const exposed=String(own.data?.id)===String(accounts[0].bid)&&String(cross.data?.id)===String(accounts[0].bid);
  findings.push(finding('Cross-user basket read','Access-control evidence',new URL('/rest/basket/'+accounts[0].bid,target).href,{firstUserBasket:accounts[0].bid,secondUserBasket:accounts[1].bid,crossUserReadReturnedFirstUserObject:exposed,credentials:'Ephemeral local training accounts; tokens and passwords not retained'},'Enforce object ownership server-side for every basket request. This evidence applies only to this isolated lab operation.',exposed?'high':'info'));
 }
 return {findings,raw:JSON.stringify({tool,status:r.status,url:r.finalURL.href,findings})};
}

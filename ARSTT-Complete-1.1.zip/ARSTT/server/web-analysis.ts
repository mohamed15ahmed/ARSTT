import dns from 'node:dns/promises';
import {load} from 'cheerio';
import type {Finding} from './types.js';
export async function request(url:URL, signal:AbortSignal, options:{allowErrorStatus?:boolean}={}): Promise<{body:string; headers:Headers; status:number; finalURL:URL}> {
  const origin=url.origin,visited=new Set<string>();
  let current=new URL(url),response:Response;
  for(let hop=0;;hop++){
  if(visited.has(current.href))throw new Error('Redirect loop detected within the authorized origin.');
  visited.add(current.href);
  try {response = await fetch(current,{signal:AbortSignal.any([signal,AbortSignal.timeout(10000)]),redirect:'manual',headers:{'User-Agent':'ARSTT/1.1 authorized-assessment'}});}
  catch(error){const e=error as Error & {cause?:{code?:string;message?:string}};if(signal.aborted || e.name==='TimeoutError')throw e;const hint=['localhost','127.0.0.1','[::1]'].includes(url.hostname)?' In Docker, localhost means the app container. Use lab:8088 for the included lab, or host.docker.internal for an authorized service on Windows.':'';throw new Error(`Cannot reach ${url.origin}: ${e.cause?.code || e.cause?.message || e.message}.${hint}`);}
  if ([301,302,303,307,308].includes(response.status)) {
    const location=response.headers.get('location');await response.body?.cancel();
    if(!location)throw new Error(`HTTP ${response.status} redirect has no Location header.`);
    const next=new URL(location,current);
    if(next.origin!==origin||next.username||next.password)throw new Error(`Redirect leaves the authorized origin (${origin}). Create or select a separately authorized project for ${next.origin} and retry. No request was sent to that destination.`);
    if(hop>=5)throw new Error('Redirect limit exceeded (5).');current=next;continue;
  }
  break;
  }
  if (!response.ok && !options.allowErrorStatus) { await response.body?.cancel(); throw new Error(`HTTP ${response.status} returned by ${current.origin}${current.pathname}; content coverage is unavailable.`); }
  const chunks:Uint8Array[]=[]; let count=0;
  if (response.body) for await(const chunk of response.body as any) { count+=chunk.length; if(count>2*1024*1024) { throw new Error('HTTP response exceeds the 2 MiB limit.'); } chunks.push(chunk); }
  return {body:Buffer.concat(chunks).toString('utf8'),headers:response.headers,status:response.status,finalURL:current};
}
export async function reconnaissance(target:URL, signal:AbortSignal, log:(s:string)=>void) {
  log(`Resolving ${target.hostname}`);
  const addresses = await dns.lookup(target.hostname.replace(/^\[|\]$/g,''),{all:true});
  log(`Requesting ${target.origin}${target.pathname}`);
  const r=await request(target,signal,{allowErrorStatus:true});
  const findings:Finding[]=addresses.map(a=>({title:a.address,kind:`IPv${a.family} address`,source:target.hostname,severity:'info',evidence:'Resolved by the operating system DNS resolver.',verification:'observation'}));
  findings.push({title:`HTTP ${r.status}`,kind:'HTTP response',source:target.href,severity:'info',evidence:JSON.stringify({server:r.headers.get('server') ?? 'Unknown',contentType:r.headers.get('content-type') ?? 'Unknown',title:r.body.match(/<title[^>]*>([^<]{0,300})/i)?.[1] ?? 'Unknown'}),verification:'observation'});
  const links=new Set<string>();
  for(const m of r.body.matchAll(/(?:href|src)\s*=\s*["']([^"']{1,2048})["']/gi)) { try { const u=new URL(m[1],r.finalURL); if(u.origin===target.origin && ['http:','https:'].includes(u.protocol)){ u.search='';u.hash='';links.add(u.href); } } catch{} }
  for(const source of [...links].slice(0,200)) findings.push({title:new URL(source).pathname,kind:'Discovered resource',source,severity:'info',evidence:'Linked in the target HTML; not a vulnerability.',verification:'observation'});
  return {findings,coverage:'complete' as const,warnings:[] as string[],raw:JSON.stringify({addresses,httpStatus:r.status,finalURL:r.finalURL.href,resources:[...links],coverage:r.status>=400?'HTTP response observed; application content inaccessible':'HTTP document observed'},null,2)};
}
export async function javascriptLeaks(target:URL, signal:AbortSignal, log:(s:string)=>void) {
  const page=await request(target,signal), files=new Set<string>();
  if (/javascript/i.test(page.headers.get('content-type') || '') || /\.m?js$/i.test(target.pathname)) files.add(target.href);
  const $=load(page.body);
  $('script[src]').each((_i,element)=>{try{const u=new URL($(element).attr('src')!,page.finalURL);if(u.origin===target.origin&&!u.username&&!u.password){u.hash='';files.add(u.href);}else log('Skipped a script outside the authorized origin.');}catch{}});
  const findings:Finding[]=[], scanned:string[]=[],warnings:string[]=[]; let failures=0,inlineCount=0;
  const analyze=(source:string,body:string)=>{
    const patterns:[string,RegExp][]=[['AWS access-key indicator',/\b(?:AKIA|ASIA)[A-Z0-9]{16}\b/g],['GitHub token indicator',/\b(?:gh[pousr]_[A-Za-z0-9_]{20,}|github_pat_[A-Za-z0-9_]{20,})\b/g],['JWT indicator',/\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b/g],['Assigned credential indicator',/\b(?:api[_-]?key|access[_-]?token|client[_-]?secret|password)\s*[:=]\s*["']([^"'\n]{8,200})["']/gi],['Private-key indicator',/-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/g]];
    for(const [title,re] of patterns) for(const m of body.matchAll(re)) findings.push({title,kind:'Potential secret',source,severity:'unknown',verification:'potential',evidence:`Line ${body.slice(0,m.index).split('\n').length}; value hidden. Pattern match only; no credential validation was attempted.`});
    const endpoints=new Set<string>(); for(const m of body.matchAll(/["'`](\/(?:api|v[1-9]|graphql|rest)[/A-Za-z0-9_.?=&%{}:-]*)["'`]/g)) { try {const u=new URL(m[1],target);u.search='';endpoints.add(u.href);}catch{} }
    for(const endpoint of endpoints) findings.push({title:new URL(endpoint).pathname,kind:'Endpoint reference',source,severity:'info',verification:'observation',evidence:endpoint});
  };
  const selected=[...files].slice(0,12);
  for(const source of selected){ if(signal.aborted) throw signal.reason; log(`Reading JavaScript ${new URL(source).pathname}`); try {const body=source===target.href ? page.body : (await request(new URL(source),signal)).body; analyze(source,body);scanned.push(source);} catch(e){if(signal.aborted)throw e;failures++;const warning=`JavaScript ${new URL(source).pathname}: ${(e as Error).message}`;warnings.push(warning);log(warning);} }
  // Analyze inline script as text; never evaluate, import or run discovered content.
  if(!/javascript/i.test(page.headers.get('content-type') || '')) $('script:not([src])').each((_i,element)=>{inlineCount++;analyze(page.finalURL.href+'#inline-'+inlineCount,$(element).text());});
  if(failures&&!scanned.length&&!inlineCount)throw new Error('No discovered JavaScript could be analyzed. '+warnings.join('; '));
  if(files.size>12)warnings.push(`${files.size-12} file(s) omitted by the 12-file resource limit.`);
  log(`Analyzed ${scanned.length} external file(s); ${Math.max(0,files.size-12)} skipped by the file limit. Indicators are unverified.`);
  return {findings,coverage:warnings.length?'partial' as const:'complete' as const,warnings,raw:JSON.stringify({scanned,inlineCount,discovered:files.size,fileLimit:12,coverage:warnings.length?'partial':'complete',warnings,verifiedSecrets:0,findings},null,2)};
}

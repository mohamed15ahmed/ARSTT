import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url));
const children=[];let stopping=false;
function stop(code=0){if(stopping)return;stopping=true;for(const p of children)p.kill('SIGTERM');setTimeout(()=>{for(const p of children)p.kill('SIGKILL');process.exit(code);},1500).unref();}
function start(args,env){const p=spawn(process.execPath,args,{cwd:root,env:{...process.env,...env},stdio:'inherit',shell:false});children.push(p);p.on('error',e=>{console.error(e.message);stop(1);});p.on('exit',code=>{if(!stopping)stop(code??1);});}
start(['--watch','--import','tsx','server/main.ts'],{HOST:'127.0.0.1',PORT:process.env.ARSTT_DEV_API_PORT||'4311'});
start(['node_modules/vite/bin/vite.js','--host','127.0.0.1','--port',process.env.ARSTT_DEV_WEB_PORT||'5175','--strictPort'],{});
process.on('SIGINT',()=>stop());process.on('SIGTERM',()=>stop());

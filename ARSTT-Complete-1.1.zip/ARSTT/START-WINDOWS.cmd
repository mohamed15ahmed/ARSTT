@echo off
cd /d "%~dp0"
docker info >nul 2>&1
if errorlevel 1 (
  echo Start Docker Desktop and enable the WSL2 Linux engine first.
  pause
  exit /b 1
)
docker compose --profile training up --build -d
if errorlevel 1 (
  echo Setup failed. Read the error above; do not treat this as a successful installation.
  pause
  exit /b 1
)
docker compose exec app npm run doctor
if errorlevel 1 (
  echo One or more tools are unavailable. Check requirements in About and container logs.
  pause
  exit /b 1
)
docker compose exec app /opt/arstt-ml/bin/python ml/predict.py --status
if errorlevel 1 (
  echo The ML model is unavailable. Core scanning remains running; inspect AI Analysis for the error.
)
start http://localhost:4310
echo Local Juice Shop target inside Docker: http://juice-shop:3000/
echo ARSTT started. Training origins INSIDE Docker: http://lab:8088 and https://lab:8443
pause

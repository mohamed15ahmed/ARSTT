import {defineConfig} from 'vite';
export default defineConfig({root:'client',base:'/',server:{proxy:{'/api':{target:`http://127.0.0.1:${process.env.ARSTT_DEV_API_PORT||'4311'}`,changeOrigin:false}}},build:{outDir:'../dist/public',emptyOutDir:true}});

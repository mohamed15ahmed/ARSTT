import json,hashlib,time,argparse,subprocess
from pathlib import Path
from collections import Counter
import numpy as np,joblib,sklearn
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.dummy import DummyClassifier
from sklearn.metrics import classification_report,confusion_matrix,f1_score,accuracy_score
from text import clean
root=Path(__file__).resolve().parent.parent;out=root/'models';parser=argparse.ArgumentParser();parser.add_argument('--data',required=True);args=parser.parse_args();source=Path(args.data);assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()=='d9dc212ef01743bc06ac8ffb78cc88aee8e83cb4';manifest={r['id']:r for r in json.loads((out/'split-manifest.json').read_text())}
mapping={'XSS':{79},'SQL_INJECTION':{89},'PATH_TRAVERSAL':{22},'SSRF':{918},'COMMAND_INJECTION':{78},'DESERIALIZATION':{502},'ACCESS_CONTROL':{284,285,862,863,639,306,287},'MEMORY_SAFETY':{119,125,416,787}}
rows=[];excluded=Counter()
for file in sorted((source/'advisories/github-reviewed').rglob('*.json')):
 x=json.loads(file.read_text());m=manifest.get(x['id'])
 if not m:continue
 cwes={int(s.removeprefix('CWE-')) for s in x.get('database_specific',{}).get('cwe_ids',[]) if s.startswith('CWE-') and s[4:].isdigit()}
 if not cwes:excluded['missing_CWE']+=1;continue
 labels=[name for name,ids in mapping.items() if cwes&ids]
 if len(labels)>1:excluded['ambiguous_multiple_types']+=1;continue
 rows.append({'id':x['id'],'split':m['split'],'group':m['group'],'label':labels[0] if labels else 'OTHER','text':clean(x.get('summary','')+'\n'+x.get('details',''))})
texts=np.array([r['text'] for r in rows],dtype=object);labels=np.array([r['label'] for r in rows]);part={name:np.array([i for i,r in enumerate(rows) if r['split']==name]) for name in ['train','validation','test']}
for a,b in [('train','validation'),('train','test'),('validation','test')]:assert not {rows[i]['group'] for i in part[a]}&{rows[i]['group'] for i in part[b]}
counts={name:dict(Counter(labels[idx])) for name,idx in part.items()};assert all(len(x)==9 and min(x.values())>30 for x in counts.values()),counts
print('Retained type records',len(rows),'counts',counts,flush=True)
experiments=[];best=None
for c in [.5,2.,8.]:
 pipeline=Pipeline([('tfidf',TfidfVectorizer(ngram_range=(1,2),min_df=3,max_df=.98,max_features=100000,sublinear_tf=True)),('classifier',LogisticRegression(C=c,class_weight='balanced',max_iter=700,solver='lbfgs',random_state=42))]);t=time.time();pipeline.fit(texts[part['train']],labels[part['train']]);score=f1_score(labels[part['validation']],pipeline.predict(texts[part['validation']]),average='macro');experiments.append({'C':c,'validationMacroF1':float(score),'seconds':time.time()-t});print(experiments[-1],flush=True)
 if best is None or score>best[0]:best=(score,pipeline,c)
model=best[1];pred=model.predict(texts[part['test']]);baseline=DummyClassifier(strategy='most_frequent');baseline.fit(np.zeros((len(part['train']),1)),labels[part['train']]);bp=baseline.predict(np.zeros((len(part['test']),1)))
joblib.dump(model,out/'type.joblib',compress=3)
metrics={'modelVersion':'arstt-finding-type-v1','task':'Text-only vulnerability-type classification from reviewed CWE labels','sourceCommit':'d9dc212ef01743bc06ac8ffb78cc88aee8e83cb4','license':'CC-BY-4.0','retained':len(rows),'excluded':dict(excluded),'splitCounts':counts,'groupOverlap':0,'labelMapping':{k:sorted(v) for k,v in mapping.items()},'selectedC':best[2],'selection':'validation macro F1 only; independent type test evaluated after model selection','experiments':experiments,'test':{'accuracy':accuracy_score(labels[part['test']],pred),'macroF1':f1_score(labels[part['test']],pred,average='macro'),'weightedF1':f1_score(labels[part['test']],pred,average='weighted'),'classes':classification_report(labels[part['test']],pred,output_dict=True,zero_division=0),'confusionMatrix':confusion_matrix(labels[part['test']],pred,labels=model.classes_).tolist(),'classOrder':model.classes_.tolist()},'baseline':{'strategy':'most_frequent','accuracy':accuracy_score(labels[part['test']],bp),'macroF1':f1_score(labels[part['test']],bp,average='macro')},'artifactSHA256':hashlib.sha256((out/'type.joblib').read_bytes()).hexdigest(),'versions':{'scikit-learn':sklearn.__version__},'limitations':['Type prediction, not confirmation','OTHER is heterogeneous','English reviewed advisories differ from scanner output','No arbitrary automatic escalation of finding severity','No API or rule-based system is counted as trained ML']}
(out/'type-metrics.json').write_text(json.dumps(metrics,indent=2));(out/'type-split-manifest.json').write_text(json.dumps([{k:v for k,v in r.items() if k!='text'} for r in rows]));print('TEST',metrics['test']['accuracy'],metrics['test']['macroF1'],flush=True)

"""Fetch the immutable public dataset snapshot without replacing an existing checkout."""
import argparse,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--destination',required=True);a=p.parse_args();dest=Path(a.destination).resolve();commit='d9dc212ef01743bc06ac8ffb78cc88aee8e83cb4'
if dest.exists():
    if not (dest/'.git').is_dir():raise SystemExit('Destination exists and is not the expected dataset checkout')
    actual=subprocess.check_output(['git','rev-parse','HEAD'],cwd=dest,text=True).strip()
    if actual!=commit:raise SystemExit('Existing checkout has a different snapshot; use a new destination')
else:
    dest.mkdir(parents=True);subprocess.run(['git','init','-q'],cwd=dest,check=True);subprocess.run(['git','remote','add','origin','https://github.com/github/advisory-database.git'],cwd=dest,check=True)
    subprocess.run(['git','config','core.sparseCheckout','true'],cwd=dest,check=True);(dest/'.git/info/sparse-checkout').write_text('/LICENSE.md\n/README.md\n/advisories/github-reviewed/\n')
    subprocess.run(['git','fetch','--depth=1','origin',commit],cwd=dest,check=True);subprocess.run(['git','checkout','--detach','FETCH_HEAD'],cwd=dest,check=True)
assert 'Attribution 4.0 International' in (dest/'LICENSE.md').read_text();print('Verified dataset snapshot:',commit)

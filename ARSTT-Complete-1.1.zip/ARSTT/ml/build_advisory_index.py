"""Build a local keyword/reference index, not an exploitability classifier."""
import argparse,json,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--data',required=True);p.add_argument('--output',default='models/advisory-index.json');a=p.parse_args();source=Path(a.data);commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip();assert commit=='d9dc212ef01743bc06ac8ffb78cc88aee8e83cb4'
rows=[]
for p in sorted((source/'advisories/github-reviewed').rglob('*.json')):
 x=json.loads(p.read_text())
 if x.get('withdrawn'):continue
 rows.append({'id':x['id'],'aliases':x.get('aliases',[]),'summary':x.get('summary',''),'affected':[{'name':v.get('package',{}).get('name',''),'ecosystem':v.get('package',{}).get('ecosystem',''),'ranges':v.get('ranges',[])} for v in x.get('affected',[])],'reference':'https://github.com/advisories/'+x['id']})
Path(a.output).write_text(json.dumps({'source':'GitHub Advisory Database','commit':commit,'license':'CC-BY-4.0','advisories':rows},separators=(',',':')));print(len(rows),'non-withdrawn advisories indexed')

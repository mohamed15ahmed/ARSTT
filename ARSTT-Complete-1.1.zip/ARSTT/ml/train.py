"""Train only after docs/ML-TASK.ar.md. Input: pinned reviewed GitHub advisories."""
import argparse,hashlib,json,subprocess,time,zlib,os
from pathlib import Path
from collections import Counter,defaultdict
import numpy as np,joblib,sklearn,scipy
from sklearn.model_selection import GroupShuffleSplit
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.dummy import DummyClassifier
from sklearn.metrics import classification_report,confusion_matrix,f1_score,accuracy_score
from text import clean
SEED=42
p=argparse.ArgumentParser();p.add_argument('--data',required=True);p.add_argument('--output',default='models');a=p.parse_args();source=Path(a.data);out=Path(a.output);out.mkdir(parents=True,exist_ok=True)
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
if commit!='d9dc212ef01743bc06ac8ffb78cc88aee8e83cb4':raise SystemExit('Dataset snapshot differs from the documented task. Review and pin it before retraining.')
license_text=(source/'LICENSE.md').read_text();assert 'Attribution 4.0 International' in license_text
records=[];excluded=Counter();initial=Counter()
for file in sorted((source/'advisories/github-reviewed').rglob('*.json')):
    x=json.loads(file.read_text());label=x.get('database_specific',{}).get('severity');initial[label]+=1
    if x.get('withdrawn'):excluded['withdrawn']+=1;continue
    if label not in ['LOW','MODERATE','HIGH','CRITICAL']:excluded['missing_or_invalid_label']+=1;continue
    text=clean(x.get('summary','')+'\n'+x.get('details',''))
    if len(text.split())<15:excluded['insufficient_text']+=1;continue
    records.append({'id':x['id'],'aliases':x.get('aliases',[]),'label':label,'text':text})
assert len(records)>15000,'Insufficient labeled data'
n=len(records);parent=list(range(n))
def find(i):
    while parent[i]!=i:parent[i]=parent[parent[i]];i=parent[i]
    return i
def union(i,j):
    x,y=find(i),find(j)
    if x!=y:parent[y]=x
alias_index={};exact={};exact_duplicates=0
for i,r in enumerate(records):
    for alias in [r['id']]+r['aliases']:
        if alias in alias_index:union(i,alias_index[alias])
        else:alias_index[alias]=i
    digest=hashlib.sha256(r['text'].encode()).hexdigest()
    if digest in exact:union(i,exact[digest]);exact_duplicates+=1
    else:exact[digest]=i
# Near duplicates: 64-permutation MinHash, 16 bands of four; verify actual Jaccard.
rng=np.random.default_rng(SEED);coef=rng.integers(1,2**31,size=64,dtype=np.uint64);offset=rng.integers(0,2**32,size=64,dtype=np.uint64);prime=np.uint64(4294967311)
buckets=defaultdict(list);shingles=[];near_edges=0
for i,r in enumerate(records):
    words=r['text'].split()[:1000];s={zlib.crc32(' '.join(words[j:j+5]).encode()) for j in range(max(1,len(words)-4))};shingles.append(s)
    h=np.fromiter(s,dtype=np.uint64);sig=np.min((h[:,None]*coef[None,:]+offset[None,:])%prime,axis=0)
    keys=[(band,tuple(int(v) for v in sig[band*4:band*4+4])) for band in range(16)];candidates=set()
    for key in keys:candidates.update(buckets[key][:128])
    for j in sorted(candidates)[:256]:
        if find(i)==find(j):continue
        other=shingles[j]
        if min(len(s),len(other))/max(len(s),len(other))<.8:continue
        if len(s&other)/len(s|other)>=.8:union(i,j);near_edges+=1
    for key in keys:
        if len(buckets[key])<128:buckets[key].append(i)
    if i%5000==0:print('Grouped',i,'/',n,flush=True)
groups=np.array([find(i) for i in range(n)]);labels=np.array([r['label'] for r in records]);texts=np.array([r['text'] for r in records],dtype=object)
train,rest=next(GroupShuffleSplit(n_splits=1,train_size=.7,random_state=SEED).split(texts,labels,groups));v,t=next(GroupShuffleSplit(n_splits=1,train_size=.5,random_state=SEED+1).split(texts[rest],labels[rest],groups[rest]));val,test=rest[v],rest[t]
for left,right in [(train,val),(train,test),(val,test)]:assert not set(groups[left])&set(groups[right])
counts={name:dict(Counter(labels[ids])) for name,ids in [('train',train),('validation',val),('test',test)]};assert all(len(x)==4 and min(x.values())>50 for x in counts.values())
audit={'source':'https://github.com/github/advisory-database','commit':commit,'license':'CC-BY-4.0','licenseSHA256':hashlib.sha256(license_text.encode()).hexdigest(),'initialLabels':dict(initial),'excluded':dict(excluded),'retained':n,'retainedLabels':dict(Counter(labels)),'exactDuplicateRecords':exact_duplicates,'nearDuplicateEdges':near_edges,'groups':len(set(groups)),'splitCounts':counts,'groupOverlap':0,'seed':SEED,'features':'clean(summary + details), no metadata labels/CVSS/IDs/URLs/versions','limitations':'LSH approximate similarity grouping can miss some semantic duplication; security advisories differ from scanner observations.'}
(out/'data-audit.json').write_text(json.dumps(audit,indent=2))
manifest=[{'id':records[int(i)]['id'],'group':int(groups[i]),'label':str(labels[i]),'split':name} for name,ids in [('train',train),('validation',val),('test',test)] for i in ids]
(out/'split-manifest.json').write_text(json.dumps(manifest))
# Freeze the split BEFORE selecting regularization. Test remains untouched until final evaluation.
best=None;experiments=[]
for c in [.5,2.0,8.0]:
    pipeline=Pipeline([('tfidf',TfidfVectorizer(ngram_range=(1,2),min_df=3,max_df=.98,max_features=80000,sublinear_tf=True)),('classifier',LogisticRegression(C=c,class_weight='balanced',max_iter=700,solver='lbfgs',random_state=SEED))])
    started=time.time();pipeline.fit(texts[train],labels[train]);score=f1_score(labels[val],pipeline.predict(texts[val]),average='macro');experiments.append({'C':c,'validationMacroF1':float(score),'seconds':round(time.time()-started,2)});print(experiments[-1],flush=True)
    if best is None or score>best[0]:best=(score,pipeline,c)
model=best[1];pred=model.predict(texts[test]);baseline=DummyClassifier(strategy='most_frequent');baseline.fit(np.zeros((len(train),1)),labels[train]);basepred=baseline.predict(np.zeros((len(test),1)))
metrics={'modelVersion':'arstt-advisory-severity-v1','task':'Text-only reviewed advisory severity classification; not vulnerability detection','sourceCommit':commit,'selectedC':best[2],'selection':'validation macro F1 only; test evaluated once after selection','experiments':experiments,'test':{'accuracy':accuracy_score(labels[test],pred),'macroF1':f1_score(labels[test],pred,average='macro'),'weightedF1':f1_score(labels[test],pred,average='weighted'),'classes':classification_report(labels[test],pred,output_dict=True,zero_division=0),'confusionMatrix':confusion_matrix(labels[test],pred,labels=model.classes_).tolist(),'classOrder':model.classes_.tolist()},'baseline':{'strategy':'most_frequent','accuracy':accuracy_score(labels[test],basepred),'macroF1':f1_score(labels[test],basepred,average='macro')},'versions':{'scikit-learn':sklearn.__version__,'numpy':np.__version__,'scipy':scipy.__version__,'joblib':joblib.__version__},'limitations':['No independent finding confirmation or exploitability inference','English advisories; scanner text is out-of-distribution','Class imbalance and label noise remain','Predictions abstain for short text or probability below 0.55; probability is not evidence of a vulnerability']}
joblib.dump(model,out/'severity.joblib',compress=3)
metrics['artifactSHA256']=hashlib.sha256((out/'severity.joblib').read_bytes()).hexdigest();(out/'metrics.json').write_text(json.dumps(metrics,indent=2));(out/'DATA-LICENSE.txt').write_text(license_text)
print(json.dumps({'testMacroF1':metrics['test']['macroF1'],'baselineMacroF1':metrics['baseline']['macroF1'],'testAccuracy':metrics['test']['accuracy'],'counts':counts},indent=2),flush=True)

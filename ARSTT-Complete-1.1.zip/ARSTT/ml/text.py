import html,re

def clean(text):
    text=html.unescape(re.sub(r'<[^>]*>',' ',str(text)))
    text=re.split(r'(?im)^\s*#{1,6}\s*(?:credits|acknowledg|references)',text)[0]
    text=re.sub(r'https?://\S+|\b[^\s@]+@[^\s@]+\b',' ',text)
    text=re.sub(r'(?im)^.*(?:cvss|severity\s*:|severity\s*\|).*$', ' ',text)
    text=re.sub(r'\b(?:CVE-\d{4}-\d+|GHSA-[a-z0-9-]+)\b',' ',text,flags=re.I)
    text=re.sub(r'\b(?:critical|high|moderate|medium|low)\b',' ',text,flags=re.I)
    text=re.sub(r'\b\d+(?:\.\d+)*\b',' ',text)
    return ' '.join(re.findall(r'[a-zA-Z]{2,}',text.lower()))[:16000]

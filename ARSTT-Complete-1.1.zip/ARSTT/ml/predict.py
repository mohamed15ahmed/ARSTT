import json,sys,hashlib
from pathlib import Path
import joblib
from text import clean
root=Path(__file__).resolve().parent.parent;folder=Path(__import__('os').environ.get('ARSTT_MODEL_DIR',root/'models'));metrics=json.loads((folder/'type-metrics.json').read_text());artifact=folder/'type.joblib'
if hashlib.sha256(artifact.read_bytes()).hexdigest()!=metrics['artifactSHA256']:raise RuntimeError('Model artifact integrity check failed')
model=joblib.load(artifact)
if '--status' in sys.argv:
 print(json.dumps({'loaded':True,'version':metrics['modelVersion'],'classes':[str(x) for x in model.classes_],'artifactSHA256':metrics['artifactSHA256']}));raise SystemExit()
request=json.loads(sys.stdin.read(2*1024*1024));items=request['items']
if not isinstance(items,list) or len(items)>100:raise ValueError('Expected up to 100 findings')
result=[]
for item in items:
 if not isinstance(item,dict) or not isinstance(item.get('text'),str) or len(item['text'])>20000:raise ValueError('Invalid text input')
 text=clean(item['text'])
 if len(text.split())<15:result.append({'id':item['id'],'status':'abstained','reason':'Insufficient descriptive text for the trained advisory task'});continue
 scores=model.predict_proba([text])[0];order=scores.argsort()[::-1];confidence=float(scores[order[0]]);label=str(model.classes_[order[0]])
 vector=model.named_steps['tfidf'].transform([text]);idx=int(order[0]);terms=model.named_steps['tfidf'].get_feature_names_out();weighted=vector.multiply(model.named_steps['classifier'].coef_[idx]).tocoo();influential=sorted([(str(terms[c]),float(v)) for c,v in zip(weighted.col,weighted.data) if v>0],key=lambda x:x[1],reverse=True)[:5]
 result.append({'id':item['id'],'influentialTerms':[{'term':t,'contribution':v} for t,v in influential],'status':'predicted' if confidence>=.65 else 'abstained','suggestedType':label if confidence>=.65 else None,'modelProbability':confidence,'distribution':{str(c):float(v) for c,v in zip(model.classes_,scores)},'reason':'Text-only learned advisory CWE category; not evidence or confirmation. English scanner text can be outside the training distribution.'})
print(json.dumps({'modelVersion':metrics['modelVersion'],'predictions':result,'interpretation':'Predictions never replace original scanner findings or evidence classification; probabilities are not independently calibrated vulnerability confidence.'}))

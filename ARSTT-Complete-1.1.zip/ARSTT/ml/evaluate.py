"""Independent reload/evaluation of frozen artifacts. Does not train or tune."""
import argparse,json,hashlib
from pathlib import Path
import joblib,numpy as np
from sklearn.metrics import accuracy_score,f1_score,confusion_matrix
from text import clean
p=argparse.ArgumentParser();p.add_argument('--data',required=True);a=p.parse_args();root=Path(__file__).resolve().parent.parent;folder=root/'models';source=Path(a.data)
manifest=json.loads((folder/'type-split-manifest.json').read_text());test=[r for r in manifest if r['split']=='test'];data={}
for file in (source/'advisories/github-reviewed').rglob('*.json'):
 x=json.loads(file.read_text());data[x['id']]=x
metrics=json.loads((folder/'type-metrics.json').read_text());assert hashlib.sha256((folder/'type.joblib').read_bytes()).hexdigest()==metrics['artifactSHA256'];model=joblib.load(folder/'type.joblib')
texts=[clean(data[r['id']].get('summary','')+'\n'+data[r['id']].get('details','')) for r in test];truth=[r['label'] for r in test];pred=model.predict(texts);prob=model.predict_proba(texts).max(axis=1)
assert abs(accuracy_score(truth,pred)-metrics['test']['accuracy'])<1e-12
assert abs(f1_score(truth,pred,average='macro')-metrics['test']['macroF1'])<1e-12
assert confusion_matrix(truth,pred,labels=model.classes_).tolist()==metrics['test']['confusionMatrix']
sets={part:{r['group'] for r in manifest if r['split']==part} for part in ['train','validation','test']}
assert not sets['train']&sets['test'] and not sets['validation']&sets['test'] and not sets['train']&sets['validation']
selected=prob>=.65
check={'passed':True,'testRecords':len(test),'accuracy':accuracy_score(truth,pred),'macroF1':f1_score(truth,pred,average='macro'),'groupOverlap':0,'artifactSHA256':metrics['artifactSHA256'],'frozenAbstentionThreshold':.65,'thresholdCoverage':float(selected.mean()),'thresholdSelectiveAccuracy':accuracy_score(np.array(truth)[selected],pred[selected]) if selected.any() else None,'interpretation':'Threshold is a fixed deployment heuristic; probabilities are not calibrated and held-out advisory performance is not scanner-domain validation.'}
(folder/'evaluation-check.json').write_text(json.dumps(check,indent=2));(folder/'type-test-predictions.json').write_text(json.dumps([{'id':r['id'],'truth':r['label'],'prediction':str(v),'probability':float(c)} for r,v,c in zip(test,pred,prob)]));print(json.dumps(check,indent=2))

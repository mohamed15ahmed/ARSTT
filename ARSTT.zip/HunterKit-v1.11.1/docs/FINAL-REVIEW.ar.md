# ARSTT — تقرير التنفيذ والمراجعة النهائية

التاريخ: 2026-10-23. المقارنة مع آخر نسخة مُسلَّمة `ARSTT-jsleaks-update.zip`، بصمة SHA256: `2552b074b37b590b06a72b2755058e009816f659864bf124e4792c5669804286`.

نُفذت مراحل الأدوات والسجل والتيرمنال والتقارير والواجهة بالتتابع. **لا يوجد Commit أو Push أو رفع إلى GitHub**. المشروع المستورد ما زال Untracked في Git؛ لذلك اعتمدت المقارنة على بصمات ZIP، لا على Git diff. أسماء الحزم وملفات Lock والمسارات الحالية محفوظة.

**النتيجة ليست «كل شيء يعمل»:** البناء نجح؛ suite النهائية 58 اختبارًا: 56 Passed و2 Failed، وهما اختبار screenshots المحمي واختباره الأب فقط، بسبب Chromium SUID sandbox. مراجعة المتصفح اجتازت 18 فحصًا وظيفيًا دون أخطاء JavaScript، لكنها تُرجع فشلًا صريحًا عند390px. تدريب AI متوقف وفق شرط البيانات، وليس مكتملًا.

## ما تغير فعليًا

- Nmap بقي Nmap وبنمط TCP connect/version-light. أضيف Target داخل scope مفوّض، حدود عملية ومخرجات وتزامن، وXML مستقل والتحقق من اكتماله. أثبت الاختبار أن Nmap يمكنه الخروج بـexit success مع0hosts عند فشل DNS؛ هذا أصبح Failed، وليس نتيجة نظيفة. المنافذ المفتوحة تظل observations.
- WhatWeb بقيت بشدة1؛ أُثبت أن التنفيذ السابق يعرض الهدف المغلق كنجاح مع0تقنيات. الآن يتطلب HTTP JSON صالحًا للهدف، ويعرض Unknown للمعلومات غير المُبلّغة، ويصنف Net::ReadTimeout كمهلة. النتائج القديمة لا تُستخدم للفحص الجديد.
- testssl.sh الأصلية متاحة وموثوقة في الاختبارات المحلية؛ لم نضف SSLyze. مسار مؤقت فريد لكل Job، ثم مخرج محفوظ مستقل. لا اكتمال دون exit ناجح وJSON صالح وعلامة scanTime وعدم وجود scanProblem/FATAL. تصنيف Positive/Warning/Issue من severity الأداة، دون درجة أمنية مخترعة.
- ZAP الأصلية شُغلت مباشرة عبر Java وحزمة2.17.0 الرسمية بعد التحقق من SHA256، لأن سحب صورة Docker فشل بنفاد مساحة Docker. الخطة spider+passiveScan فقط؛ حدود واضحة للزحف وانتظار الطابور والعملية، مع إيقاف مجموعة العمليات عند المهلة والإلغاء. مسار Docker يطلب صورة جاهزة ويستخدم اسم حاوية مستقلًا وتنظيفًا محددًا، لكن تشغيل الحاوية **لم يُثبت** هنا. سبب مهلة300s التاريخية غير محسوم؛ لا ننسبها تلقائيًا إلى عطل المساحة الحالي.
- Nuclei بقيت بإصدار3.11.1 والقوالب المقفلة v10.5.0. حُفظت Profiles الضرورية، مع outputs مستقلة، والتحقق من requests/templates وأخطاء التغطية، والشدة والمراجع الأصلية. لا تُعرض matches كإثبات مستقل لثغرة أو استغلال.
- صفحة `/security` أصبحت **Web Security Assessment** باختيار الأداة وProfile عند الحاجة، Target، Scan، حالة، Terminal وتفاصيل نتائج. بقي رابط Sidebar واسمه وتخطيطه كما كان لحماية مكوّن Recon المشترك. صفحة `/attacks` ومساراتها وملفاتها محفوظة لوظائف Dalfox/sqlmap/Wapiti؛ ملفات Profiles القديمة لم تُحذف، واختيار Nuclei انتقل للصفحة المناسبة.
- Jobs/SSE الأصلية أُعيد استخدامها؛ لم نضف محرك Jobs ثانيًا أو قاعدة بيانات. التيرمنال الجديد مرتبط بـJob ID محدد، يعيد الاتصال دون تشغيل عملية ثانية، ويرتب الرسائل برقمها ووقتها، وينقح السجلات. على صفحة Attacks يمكن فتح Job من السجل للوصول إلى تفاصيله والتيرمنال نفسه؛ التيرمنال المشترك مع Recon لم يتغير.
- السجل يستعمل ملفات `logs/jobs` و`security/runs` و`js-leaks/runs` الموجودة/المتخصصة، ويزيل ازدواج الـJob وتقريره بالمعرف. يحتفظ بالفشل والمهلة والإلغاء وPartial وSkipped، ولا يحوّل skipped إلى completed. فشل حفظ التقرير يحتفظ بالهدف والخطأ في الـJob، ولا يدّعي وجود outputFile غير محفوظ. القديم غير القابل للربط بـJob يبقى معلّمًا كـLegacy.
- Dashboard تحسب عدد المعرفات المسجلة وحالاتها وآخر5عمليات، دون أرقام تجريبية أو تشغيل فحص عند فتحها. JSON/CSV/PDF تشمل الهدف والأداة والمعرف والتوقيت والحالة والنتائج والمراجع؛ AI predictions فارغة بوضوح. PDF نص ASCII معلن؛ JSON/CSV يحفظان Unicode.

## الملفات التي تغيرت وسببها

| الملف | التغيير |
|---|---|
| `backend/src/assessment.ts` — جديد | محوّلات Nmap/WhatWeb/testssl/ZAP/Nuclei، validation، عمليات محددة دون Shell، حدود وإلغاء، parsers وتقارير مستقلة وتنقيح |
| `backend/src/scan-history.ts` — جديد | قراءة السجل والتفاصيل والملخص من التخزين الحالي، فصل المعرفات والحالات والقديم |
| `backend/src/security.ts` | تفويض exports الأدوات الأربع للمحوّل المصحح؛ وظائف sqlmap/Wapiti والقراءة القديمة محفوظة |
| `backend/src/server.ts` | routes الفحوصات والسجل وJSON، وربط قنوات الأدوات الحالية؛ Recon routes وJobs/SSE الحالية دون تغيير |
| `backend/src/reports.ts` | تصدير بيانات العمليات الفعلية وحالات الفشل، تنقيح، CSV آمن، PDF والتحقق من محتواه |
| `frontend/src/components/AssessmentScan.tsx` — جديد | نموذج موحد بسيط، جداول، استرجاع نفس العملية، عزل الردود القديمة وأخطاء الحفظ |
| `frontend/src/components/AssessmentTerminal.tsx` — جديد | عرض خاص بمعرف Job عبر SSE/API الموجودة، إعادة اتصال وCancel فعلي وسجلات مرتبة |
| `frontend/src/views/project/securityTesting.tsx` | Web Security Assessment داخل المسار الحالي دون صفحات جديدة |
| `frontend/src/views/project/attacks.tsx` | نقل اختيار Nuclei، الإبقاء على الأدوات الأخرى، ربط السجلات بتفاصيل Job |
| `frontend/src/views/project/attackResults.tsx` | سجل وتفاصيل العملية المختارة وLegacy منفصل، باستخدام الصفحة الموجودة |
| `frontend/src/views/project/status.tsx` | Dashboard من البيانات الفعلية وتعريف طريقة الحساب |
| `frontend/src/views/project/aiAnalysis.tsx` | حالة تدريب صادقة دون Chatbot أو توقعات/مقاييس مصطنعة |
| `tests/api.test.ts` | قبول عقود النتائج الجديدة واختبار React فعليًا مع Nuclei وJSLeak |
| `tests/assessment.test.ts` — جديد | أدوات حقيقية، parsers، scope، فشل ومهلة وإلغاء وتزامن وصلاحيات وعدم إعادة نتائج قديمة |
| `tests/history.test.ts` — جديد | تاريخ فعلي وأهداف مختلفة، counts، تصدير، failed/timeout/skipped |
| `tests/assessment-browser.mjs` — جديد | 18 فحصًا وظيفيًا حقيقيًا، SSE/reconnect/timeout/permissions والتجاوب والتنقل |
| `docs/ACADEMIC-AI.ar.md` — جديد | تعريف المهمة والبيانات والترخيص وخطة التقسيم والتقييم وسبب توقف التدريب |
| `docs/ASSESSMENT-RUNBOOK.ar.md` — جديد | المتطلبات والأوامر والـAPIs وتعريف الحالات وحدود التشغيل وإعادة الاختبارات |
| `docs/FINAL-REVIEW.ar.md` — جديد | هذا التقرير |

تجددت مخرجات `backend/dist` و`frontend/dist` وذاكرة بناء TypeScript. لم تتغير ملفات package.json أو package-lock.json أو locks الأدوات والقوالب. الأدوات المثبتة محليًا ومكتباتها في مجلد تشغيل منفصل؛ لا تُضمّن في ZIP المصدر.

## جدول الاختبارات النهائي

| الاختبار | الحالة | الدليل/حدود النتيجة |
|---|---|---|
| تثبيت npm بالـLock | Passed | `npm ci --cache /workspace/arstt-runtime/npm-cache`؛372حزمة، دون تغيير Lock |
| Frontend + Backend وTypeScript/imports | Passed | `npm run build`؛ لا أخطاء TS أو imports، تحذير bundle>500KB غير مانع |
| تشغيل التطوير وVite proxy | Passed | Backend وFrontend health عبر4000 و5173: `ok:true`؛ تم تشغيل `npm run dev` |
| API + React فعليان | Passed | إنشاء مشروع، فحص Nuclei Panels، عرض تقريره، ثم JSLeak حقيقية؛ ضمن suite |
| Nmap | Passed | منفذ محلي حقيقي، XML صالح، إدخال غير صالح/out-of-scope، DNS0hosts، مهلة وفصل النتائج |
| JavaScript Leaks | Passed | اختبارات التنفيذ الحقيقي السابقة أُعيدت ضمن suite، candidates منقحة، لا تنفيذ JS ولا ادعاء أسرار verified |
| WhatWeb | Passed | nginx/PHP/Apache من المخرجات الحقيقية للـfixtures، clean rescan، اتصال فاشل، مهلة قراءة8s حقيقية، دون نتائج قديمة |
| testssl.sh | Passed | فحصان متتاليان مستقلان173سجلًا لكل منهما، فشل الاتصال والمهلة، ثم إعادة نهائية173سجلًا |
| ZAP Native | Passed |3تنبيهات فعلية من spider/passive، فشل هدف مغلق، مهلة وإيقاف العملية؛ لا activeScan |
| ZAP Docker | Failed | سحب الصورة فشل `failed to register layer: no space left on device`؛ daemon موجود لكن نجاح الحاوية غير مثبت |
| Nuclei | Passed | binary/templates المقفلة، قوالب upstream موقعة غير معدلة، positive/clean/failure/timeout، حفظ ID والهدف الصحيحين |
| Profiles القديمة وDalfox | Passed | اختبارات integration الأصلية نفذت General/Panels/Default-login/Takeover/Exposure/CVE/LFI/SQLi وDalfox محليًا |
| sqlmap وWapiti | Passed | smoke للتنفيذ الحالي المحدود على HTTP محلي مصرح؛0matches؛ ليس تقييمًا لكل أنواع الاكتشاف |
| Recon المحلي وHTTPX واستخراج GET/JS | Passed | integration الأصلية؛ URL والـport وscope محفوظة، دون تعديل الكود |
| Subfinder/Wayback الخارجيان | Not Tested | تم تجهيز binaries بالإصدارات والبصمات الأصلية خارج المشروع؛ الفروع المحلية تتخطى enumeration/archive العام. لا يوجد نطاق عام مصرح به لاختبار ذلك |
| Recon screenshots | Failed | Chromium SUID sandbox abort داخل الحاوية. لم نلغِ الاختبار أو نغير إعداد Recon |
| Job IDs، الحالة، الإلغاء وحد العمليتين | Passed | اختبارات عمليات حقيقية، Timeout لاCompleted، Cancelled لاFailed عشوائيًا، الفشل يحفظ الهدف والخطأ |
| Live Terminal وإعادة الاتصال | Passed | سجلات وأوامر حقيقية، استعادة نفسID، دون تكرار العملية أو سجلات الهدف السابق؛ لا Shell من الواجهة |
| السجل وDashboard | Passed |5عمليات في اختبار السجل، dedup بالمعرف، failed/timeout/skipped صحيحة؛ أرقام الواجهة مطابقة للسجل |
| JSON/CSV/PDF | Passed | فُتحت JSON وCSV بقارئ فعلي وPDF بـpypdf/استخراج نصه؛ كل IDs والحالات موجودة؛ اختبارات empty/failed أيضًا |
| أخطاء صلاحيات المخرجات | Passed | منع كتابة security/runs فعليًا؛ خطأ واضح، لا polling بلا نهاية، لا نجاح أو ملف نتائج وهمي |
| واجهة المتصفح | Passed |18فحصًا وظيفيًا،5طلبات فحص فعلية،9مسارات، keyboard، دونpage errors |
| العرض1440 و768px | Passed | عرض حقل Target نحو768px و318px، مع الجداول والتفاصيل |
| العرض390px | Failed | عرض Target26px بسبب Sidebar/Layout المشتركين؛ لقطة فعلية محفوظة، لا ادعاء توافق |
| حماية Recon والاعتماديات | Passed |83ملف مصدر/إعداد غير مستهدف دون أي فرق، منها46ملفًا حساسًا وملفات البناء المحمية؛ بصمات محفوظة |
| تحميل/تدريب/تقييم نموذج AI | Not Tested | لا Dataset مرخصة مُعلّمة متحققة، ولا نموذج أو artifact أو metrics. توقف التدريب شرط مطلوب |
| عزل عدم توفر AI | Passed | الصفحة تعلن عدم التدريب، لا أرقام أو توقعات؛ وظائف الفحص والسجل والتقارير اجتازت الاختبارات مستقلة |

ملخص runner: **58 tests /56 pass /2 fail /0 skipped**. الفشلان subtest screenshots والـparent نفسه، وليس عطلين مستقلين. suite المتصفح تُرجع exit1 لقيد390px رغم نجاح وظائفها18؛ لا تُخفى هذه النتيجة. القوالب التدريبية تحاكي signatures فقط؛ لا تمثل منتجات ضعيفة حقيقية أو إثبات استغلال كل CVE. مجموعات القوالب الصغيرة لا تثبت نجاح مكتبة Nuclei كاملة على كل الأهداف.

## AI: ما لم يكتمل

حددت مهمة قابلة للقياس قبل أي كود نموذج: تصنيف LOW/MEDIUM/HIGH/CRITICAL من وصف أمني مناسب، مع منع إدخال CVSS/severity/CVE ID كميزات تسبب تسرب Label، ومقارنة baseline وتقسيم grouped Training/Validation/Test قبل الضبط. الحدود والـLabels وخطة المقاييس موثقة.

مصادر NVD API/feed والترخيص وCVE Terms أعادت403. README الرسمي لـCVE متاح ويشير إلى **CVE Program Terms of Use**؛ لا ننسب للبيانات ترخيص CC0/MIT من دون إثبات. لا توجد Dataset مُعلّمة في ZIP. لذلك **لم يُدرّب نموذج، ولم تُحسب Precision/Recall/F1، ولم تُنفذ اختبارات تحميل نموذج غير موجود**. الـLLM الخارجي السابق محفوظ في Backend ولا يُسمى نموذجًا دربناه. الاستكمال يحتاج بيانات متاحة بترخيص موثق وLabels موثوقة، ثم تنفيذ خطة الوثيقة.

## التعارضات والحدود المتبقية

1.390px: الإصلاح يحتاج تغيير التخطيط/Sidebar المشتركين، مثل `frontend/src/layout/projectLayout.tsx` و`frontend/src/components/sidebar.tsx`. هذا يتعارض مع حماية المكونات المشتركة ومظهر Recon؛ لم أطبّقه. يلزم تحديد نطاق استثناء قبل إصلاحه.
2. screenshots: يلزم بيئة Chromium sandbox مدعومة؛ لا تغيير تلقائي لملفات Recon أو تعطيل حماية متصفحها.
3. Docker: يلزم توفير مساحة لصورة ZAP وتشغيل اختبار حاوية فعلي؛ Native ناجح لا يثبت Docker، ولا يحسم مهلة300s السابقة.
4. النموذج الأكاديمي: يحتاج البيانات والترخيص قبل التدريب؛ لا ادعاء أنه أُنجز خلال هذه الجولة.
5. اختبار المصادر العامة لـSubfinder/Wayback يحتاج نطاقًا مصرحًا به؛ بيئة الاختبار الحالية محلية. Windows/macOS ومسارات WSL/Docker لم تُختبر على أجهزتها؛ لم أصفها بـPassed.
6. PDF محدود بـASCII؛ JSON/CSV هما الخيار الكامل للنصوصUnicode والحقول المنظمة. التطبيق كما كان محليًا لمستخدم واحد ولا يملك مصادقة متعددة المستخدمين.

لم يحدث أي فرق غير مقصود في الملفات المحمية، فلم نحتج إلى استرجاعها. لم أغير ملفات Recon أو أُثبت SSLyze أو ماسحًا بديلًا لتجاوز هذه القيود.

## بيئة Cloud والتسليم

تم حفظ `install_script` و`start_skill` في مسودة إعداد البيئة، ويشملان cache قابلًا للكتابة وتشغيل الخدمات والأدوات الموجودة دون worktree أو push. الحفظ لا ينشر البيئة؛ لتفعيل المسودة لاحقًا تُراجَع وتُحفَظ من إعدادات البيئة ثم تُنشر عبر المنصة. لم أُجرِ النشر، ولم أختبر الاستعادة في مهمة جديدة، ولم أرفع المشروع إلىGitHub.

تعليمات التشغيل والتفاصيل في `ASSESSMENT-RUNBOOK.ar.md`، وخطة AI في `ACADEMIC-AI.ar.md`. مصدر الأدلة المرافقة هو التنفيذ المحلي الفعلي؛ لا scanner mocks للنتائج الإيجابية. أخطاء الأدوات والمهلات في الاختبارات لا تُسجَّل كنجاح نظيف. النسخة المرفقة تضم المصدر والبناء الحاليين والتوثيق والاختبارات، وتستبعد node_modules وبيانات المشروعات و.git والأسرار وأدوات التشغيل المحلية.

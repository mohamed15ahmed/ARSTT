# تشغيل الفحوصات والتحقق منها

التعديلات مخصصة لفحوصات Security ونتائجها؛ لم تتغير ملفات Recon أو إعداداتها أو runner المشترك أو Sidebar/Layout/Theme.

## التشغيل

Node.js >=20.18 وnpm حسب ملف Lock. من جذر المشروع:

```bash
npm ci --cache /tmp/arstt-npm-cache
npm run build
npm run dev
```

Frontend: منفذ 5173؛ Backend: منفذ 4000، كلاهما loopback وفق الإعدادات الحالية. `npm run start:built` يشغّل النسخة المبنية ويقدّم Frontend أيضًا. لا تنشر API متعددة المستخدمين كما هي: التطبيق المحلي الحالي لا يملك نظام حسابات أو جلسات؛ وصول الـJobs مقيد بمجلد المشروع، ولا يمثل مصادقة مستخدم.

تحتاج الأدوات الأصلية المتاحة في PATH أو مسارات الإعداد الحالية: Nmap، WhatWeb مع Ruby/plugins، testssl.sh مع OpenSSL وملفاتها. مسارات `HUNTERKIT_NMAP` و`HUNTERKIT_WHATWEB` و`HUNTERKIT_TESTSSL` الموجودة ما زالت مدعومة، وكذلك WSL في مواضع دعمه السابقة. ثبت Nuclei والقوالب بالإصدارات والبصمات الموجودة في `scripts/tools-lock.json` و`scripts/templates-lock.json`. لم تتغير هذه الملفات أو package-lock.json.

ZAP: Docker الرسمي يظل مسارًا مدعومًا، ويحتاج صورة `ghcr.io/zaproxy/zaproxy:stable` جاهزة؛ لا ننزّل صورة كبيرة ضمن مهلة الفحص. في هذه البيئة فشل سحب الصورة بسبب مساحة Docker، ولذلك تم اختبار نفس أداة OWASP ZAP عبر الحزمة الرسمية 2.17.0 وJava 21 مباشرة:

```bash
export ARSTT_ZAP=/path/to/ZAP_2.17.0/zap.sh
```

بصمة حزمة Linux الرسمية: `efe799aaa3627db683b43f00c9c210aea0b75c00cc8f0a0f0434d12bb3ddde5a`. خطة Automation Framework Native تستخدم spider + passiveScan فقط، وميزانية 1 دقيقة للزحف و2 لانتظار التحليل، و240 ثانية للعملية، وheap أقصاه 1024MB. لا فعاليات activeScan. مسار Docker وسلوك Windows/macOS لم يُختبرا فعليًا في هذه الحاوية. لا نثبت SSLyze أو ماسحًا بديلًا.

في بيئة العمل الحالية الأدوات المُحضّرة منفصلة عن المصادر تحت `/workspace/arstt-runtime`؛ يلزم PATH الخاص بها، وARSTT_ZAP كما أعلاه. sqlmap وWapiti الحاليان موجودان في `security-venv/bin` المنفصلة، ولم تُضَف صفحة أو ماسحات جديدة لهما.

## واجهة وعقود البيانات

المسار `/PROJECT/security` يعرض Web Security Assessment: اختيار أداة، Target وزر Scan واحد. يبقى اسم رابط Sidebar الأصلي Security Testing لحماية المكوّن المشترك مع Recon. Nuclei تحتفظ بملفات General/Panels/Exposures/Default logins/Takeovers/CVEs/LFI/SQLi كاختيار Profile، وLFI/SQLi يتطلبان query URL. صفحة Attacks ومسارها وملفاتها محفوظة لوظائف Dalfox/sqlmap/Wapiti؛ لا تكرار لأزرار Nuclei هناك.

- `POST /api/assessments/PROJECT/scans`: `{tool,target,profile?}` فقط؛ لا executable أو Shell أو flags من العميل. يتطلب إقرار تفويض مخزنًا وهدفًا داخل scope المشروع. يرد بمعرف Job؛ تكرار الأداة الحالية يرد 409 بالمعرف القائم.
- `GET /api/assessments/PROJECT/runs/ID`: تقرير عملية واحدة؛ الملفات تحت `projects/PROJECT/security/runs/ID`، والملفات الخام المحفوظة منقحة من الأسرار. مخرجات التشغيل المؤقتة فريدة خارج المجلد العام، وتُنظَّف بعد حفظ التقرير/تشخيص الفشل.
- `GET /api/scans/PROJECT` و`/summary` و`/ID`: سجل وملخص وتفاصيل من آلية الملفات الحالية، مع إزالة ازدواج الـJob وتقريره بالمعرف نفسه. لا قاعدة بيانات جديدة ولا إعادة كتابة للسجل الأصلي.
- `GET /api/jobs/ID?project=PROJECT` و`/events?project=PROJECT`: نفس Jobs/SSE الحالية للتيرمنال؛ يعاد الاتصال بنفس ID دون بدء فحص أو خلط سجلات. `DELETE` الحالي يلغي تلك العملية فقط.
- APIs القديمة وأسماء الحزم والمسارات محفوظة. صادرات Nmap/WhatWeb/testssl/ZAP في `security.ts` أصبحت wrappers للمحوّل المصحح. قنوات Nuclei القديمة تستدعي الملف الوظيفي نفسه في محوّل المخرجات المستقلة؛ قيمة result هي عدد السجلات وoutputFile مرجع JSON خاص بالعملية. قراءة `get-attack-result` و`get-security-state` القديمة تبقى للملفات القديمة؛ النتائج الجديدة تُقرأ بعقود الـJobs أعلاه، ويُعرض القديم منفصلًا عند توفره.

Queued: حفظت الـJob ولم يبدأ runner؛ Running: بدأ التنفيذ؛ Completed: انتهت الأداة بكود مقبول وتحقق المخرج المطلوب؛ Failed: تشغيل/اتصال/تحليل/حفظ غير ناجح؛ Timeout: بلغت مهلة الأداة/الاتصال. يحتفظ Cancelled وPartial وSkipped بمعناها، ولا يُعرض الفحص المتخطى كفحص مكتمل؛ لا يدل تخطي مدخلات غير متاحة على تشغيل الأداة. ويُحفظ سجل العمليات الأصلي دون إعادة كتابته. ولا تتحول الحالات غير المكتملة إلى نجاح نظيف. لحماية Recon، لم يتغير enum المحرك المشترك: خام Job قد يسجل failed مع `result.status=timeout`؛ طبقة التقارير والسجل والتيرمنال تعرض Timeout من التقرير الأصلي. لا نفترض اكتمال عملية توقفت بإعادة تشغيل الخادم.

Nmap يحتفظ بـTCP connect وversion-light، ويضيف حدود 100 packet/s و10 عمليات probe متوازية. URL بport صريح يقيد الفحص بذلك المنفذ؛ غير ذلك يبقى نطاق Nmap الافتراضي. حدود العمليات: عمليتان Assessment متزامنتان لكل Backend، Nmap 120s وhost-timeout60s، WhatWeb90s واتصال/قراءة8s، testssl180s واتصال/OpenSSL5s، Nuclei180s مع40طلب/s وثمانية workers؛ إعداد HUNTERKIT_SCAN_TIMEOUT_MS الحالي ما زال محدودًا بـ1–600 ثانية لـNuclei. مخرجات العملية8MiB والملف16MiB؛ تجاوز الحد فشل واضح.

WhatWeb لا يتبع redirects، وشدته1. HTTP result صالح ومطابق للهدف مطلوب؛ exit0 مع[] ليس نجاحًا. testssl تحتاج scanTime صحيحًا ولا scanProblem/FATAL. Nmap يحتاج XML كاملًا وexit success وهدفًا حُلّ وفُحص بالفعل، لا مجرد exit0. Nuclei تحتاج requests/templates فعلية وغياب أخطاء التغطية قبل Completed. ZAP يجب أن تنهي انتظار passiveScan، لا مجرد وجود JSON. نتائج التوقيع/التنبيه تحتاج مراجعة، والمنفذ المفتوح ليس ثغرة.

## التقارير

`/api/reports/PROJECT.json|csv|pdf`، مع ID والهدف والأداة والأوقات والحالة والسجلات الفعلية والمراجع. يحتفظ JSON بالبيانات المنظمة؛ CSV يعطّل صيغ spreadsheet الخطرة؛ PDF يستخدم ASCII ويذكر أن JSON/CSV يحفظان Unicode. لا يُنسب legacy finding إلى Job غير معروف. لا توقعات AI أو أرقام تقييم مصطنعة؛ academicAI.trained=false إلى أن تتوفر بيانات مرخصة وتدريب مُقيّم.

## إعادة الاختبارات

```bash
npm test
node --import tsx --test --test-concurrency=1 tests/assessment.test.ts tests/history.test.ts
HUNTERKIT_TEST_BROWSER=/path/to/chromium node --import tsx --test tests/api.test.ts
ARSTT_TEST_NO_SANDBOX=1 HUNTERKIT_TEST_BROWSER=/usr/bin/chromium node tests/assessment-browser.mjs
```

توضع `ARSTT_ZAP` وPATH للأدوات قبل اختبارات التنفيذ. `ARSTT_TEST_EVIDENCE` مجلد اختياري لحفظ الأدلة. `ARSTT_TEST_NO_SANDBOX=1` خاص بمتصفح مراجعة الواجهة في الحاوية، ولا يغير إعداد screenshots أو ملفات Recon. اختبار Recon screenshots الحقيقي يفشل هنا بقيود SUID sandbox؛ لم نخفه أو نلغِ شرطه. suite المتصفح تفصل نجاح الوظائف عن فشل العرض الضيق عند390px، وتخرج بكود فشل لهذا القيد المشترك بدل ادعاء التوافق.

اختبارات Nuclei تستخدم قوالب upstream موقعة غير معدلة في مجموعة صغيرة للتحقق على خادم تدريب محلي؛ ليست إثباتًا لتنفيذ كل المكتبة أو استغلال منتجات حقيقية. اختبارات الخطأ قد تقصّر المهلة داخليًا، ولا يمكن تمرير هذه الآلية من الواجهة. اختبارات WhatWeb من المتصفح تشمل انتهاء قراءة8s فعلية. تفاصيل AI وخطة الاستكمال في ACADEMIC-AI.ar.md.

# HunterKit Changelog

## v1.11.1 — Windows tool runtime repair

- Replaced the old "append .exe to every tool" assumption with a runtime resolver.
- Nmap now detects normal Windows installs in both Program Files locations even when PATH is missing.
- sqlmap and Wapiti can run from HunterKit's private `.security-venv`.
- OWASP ZAP Baseline automatically uses the official stable Docker image when Docker Desktop is running.
- testssl.sh supports WSL and the official `ghcr.io/testssl/testssl.sh:3.2` Docker image.
- WhatWeb uses the real WSL executable on Windows instead of looking for a nonexistent `whatweb.exe`.
- Fixed Windows-to-WSL output-path conversion for WhatWeb and testssl.sh.
- Added `SETUP-SECURITY-TOOLS.cmd` and integrated it into `INSTALL-TOOLS.cmd`.
- Docker scans against localhost automatically use `host.docker.internal` on Windows/macOS.
- Refreshed backend `dist` from the repaired TypeScript sources.

# 1.11.0 — Security Testing, active-tool separation, AI repair and Live Terminal

- Add a dedicated Security Testing page for Nmap, testssl.sh, ZAP Baseline and WhatWeb.
- Add bounded sqlmap and Wapiti active profiles while retaining the existing Dalfox/Nuclei integrations.
- Enforce stored authorization acknowledgement in the backend for active tests.
- Add a persistent backend job engine with SSE logs, reconnectable history and real process cancellation.
- Add Live Terminal to Recon, JavaScript Leaks, Security Testing, Attacks and AI Analysis.
- Replace the single-provider AI path with configurable Cloudflare or OpenAI-compatible backend providers plus connection diagnostics.
- Add unified evidence-based findings, cross-tool deduplication, scan comparison, CSV export and backend-generated PDF export.
- Add Windows compatibility diagnostics and setup notes for optional scanners.
- See `DEVELOPMENT-REPORT.ar.md` and `validation/v1.11-validation.json` for verified tests and environment limitations.

# 1.10.0 — Attack pipeline repair

- Preserve target scheme, port, path and query; separate HTTP inputs from DNS hostnames.
- Discover scoped current-page links and GET form parameters even with an existing archive.
- Remove General's technology-detection prerequisite and unnecessary info filtering for exposures.
- Enable parameter-based Nuclei DAST for LFI and retain the dedicated SQLi DAST profile.
- Persist request/template counts, raw reports, skipped/partial/failed states and finding provenance.
- Reject duplicate same-module jobs and serialize atomic project metadata updates.
- Distinguish Dalfox V findings from reflection/static/information observations.
- Fix JSLeak output parsing, scan discovered JS files and expose saved results in the UI.
- Replace unreliable browser screenshot CLI calls with Playwright Core controlling an installed browser.
- Pin tool/template releases, archive and executable digests; fix executable permissions on Unix.
- Add a package lock, reproducible installers, real-tool regression tests, and repair production TypeScript builds.
- Remove the hardcoded frontend AI credential; use the backend environment configuration.

See FIX-REPORT.ar.md and validation/ for evidence and limitations.

import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import http from 'node:http';
import { spawn } from 'node:child_process';
import axios from 'axios';
import { load } from 'cheerio';
import { getDetails, projectPath, toolPath } from './core.js';
import { parseTarget, isScopedUrl } from './targets.js';
import { currentJob, getJob, registerChild, appendJobEvent } from './job-engine.js';

type Source = { id: string; url: string; kind: 'javascript' | 'html'; line?: number };
type Document = { url: string; body: string; kind: Source['kind'] };
export type JsFinding = {
  id: string; type: 'secret-candidate' | 'endpoint' | 'observation'; rule: string;
  value: string; verification: 'unverified' | 'observed'; sources: Source[];
};
export type JsReport = {
  id: string; target: string; status: 'running' | 'completed' | 'partial' | 'failed' | 'cancelled';
  phase: string; startedAt: string; finishedAt?: string; error?: string;
  findings: JsFinding[]; warnings: string[];
  counts: { documents: number; javascript: number; candidates: number; verified: number; endpoints: number; observations: number };
  limits: { documents: number; documentBytes: number; totalBytes: number; timeoutMs: number; requestTimeoutMs: number };
};
const active = new Map<string, string>();
const digest = (s: string) => crypto.createHash('sha256').update(s).digest('hex').slice(0, 24);
const runFile = (dir: string, id: string) => {
  if (!/^[a-z0-9-]{6,80}$/i.test(id)) throw new Error('Invalid JS Leaks run ID.');
  return path.join(dir, 'js-leaks', 'runs', `${id}.json`);
};
// Query values and candidate matches are never persisted or written to job logs.
export function safeUrl(value: string) {
  try { const u = new URL(value); u.username = ''; u.password = ''; u.hash = ''; for (const k of [...u.searchParams.keys()]) u.searchParams.set(k, '[redacted]'); return u.toString(); }
  catch { return '[invalid URL]'; }
}
export async function validateJsTarget(projectName: string, input: unknown) {
  const details = await getDetails(projectName);
  if (details.authorizationAccepted !== true) throw new Error('This project requires the stored authorization acknowledgement.');
  if (typeof input !== 'string' || input.length > 2048 || /[\x00-\x20\x7f]/.test(input.trim())) throw new Error('Enter a valid HTTP(S) target (maximum 2048 characters).');
  const target = parseTarget(input).targetUrl;
  if (!isScopedUrl(target, details)) throw new Error('Target is outside this project scope.');
  return target;
}
export async function readJsReport(projectName: string, id = 'latest'): Promise<JsReport | null> {
  const dir = projectPath(projectName); await getDetails(projectName);
  if (id === 'latest') {
    try { id = JSON.parse(await fs.readFile(path.join(dir, 'js-leaks', 'latest.json'), 'utf8')).id; }
    catch (e: any) { if (e.code === 'ENOENT') return null; throw new Error('The saved JS Leaks run pointer is unreadable.'); }
  }
  let report: JsReport;
  try { report = JSON.parse(await fs.readFile(runFile(dir, id), 'utf8')); }
  catch (e: any) { if (e.code === 'ENOENT') return null; throw new Error('The saved JS Leaks report is unreadable.'); }
  if (report.status === 'running' && active.get(dir) !== id) {
    // A reader may have opened the old inode just before the final atomic rename.
    report = JSON.parse(await fs.readFile(runFile(dir, id), 'utf8'));
    if (report.status === 'running') return { ...report, status: 'failed', phase: 'interrupted', error: 'The backend restarted before this run finished. Start a new scan.' };
  }
  return report;
}

function parseOutput(raw: string, mirrors: Map<string, Document>, origin: string): JsFinding[] {
  const findings = new Map<string, JsFinding>();
  for (const record of raw.split(/(?=^\[\+\] Found )/m).filter(x => x.trim())) {
    const line = record.trim();
    const endpoint = line.match(/^\[\+\] Found link: \[(.*)\] in \[(http[^\]]+)\]\s*$/);
    const candidate = line.match(/^\[\+\] Found \[([^\]]+)\]\t\[([\s\S]*)\]\t\[(http[^\]]+)\]\s*$/);
    if (!endpoint && !candidate) throw new Error('JSLeak returned unexpected output; no clean result can be established.');
    const doc = mirrors.get(endpoint?.[2] || candidate![3]);
    if (!doc) throw new Error('JSLeak returned an unknown result source.');
    let type: JsFinding['type'], value: string, rule: string, identity: string, matched: string;
    if (endpoint) {
      let u: URL; try { u = new URL(endpoint[1], doc.url); } catch { continue; }
      if (!['http:', 'https:'].includes(u.protocol) || u.origin !== origin || u.username || u.password) continue;
      u.hash = ''; matched = endpoint[1]; identity = u.toString(); value = safeUrl(identity); rule = 'JSLeak endpoint pattern'; type = 'endpoint';
    } else {
      rule = candidate![1]; matched = candidate![2]; identity = `${rule}|${matched}`;
      type = rule === 'Email' ? 'observation' : 'secret-candidate'; value = '[redacted match]';
    }
    const id = digest(`${type}|${identity}`);
    const offset = doc.body.indexOf(matched);
    const source: Source = { id: digest(doc.url), url: safeUrl(doc.url), kind: doc.kind, ...(offset >= 0 ? { line: doc.body.slice(0, offset).split('\n').length } : {}) };
    const existing = findings.get(id);
    if (existing) { if (!existing.sources.some(s => s.id === source.id && s.line === source.line)) existing.sources.push(source); }
    else findings.set(id, { id, type, rule, value, verification: type === 'secret-candidate' ? 'unverified' : 'observed', sources: [source] });
  }
  return [...findings.values()];
}

// Limits/engine injection is internal for deterministic fault tests; HTTP clients cannot set them.
export async function scanJsLeaks(projectName: string, input: string, overrides: Partial<JsReport['limits']> = {}, engine = { command: toolPath('jsleak'), prefix: [] as string[] }) {
  const target = await validateJsTarget(projectName, input), dir = projectPath(projectName);
  if (active.has(dir)) throw new Error('A JavaScript Leaks scan is already running for this project.');
  const id = currentJob()?.jobId || crypto.randomUUID(); active.set(dir, id);
  const limits = { documents: 40, documentBytes: 2 * 1024 * 1024, totalBytes: 8 * 1024 * 1024, timeoutMs: 180000, requestTimeoutMs: 8000, ...overrides };
  const report: JsReport = { id, target: safeUrl(target), status: 'running', phase: 'collecting', startedAt: new Date().toISOString(), findings: [], warnings: [], counts: { documents: 0, javascript: 0, candidates: 0, verified: 0, endpoints: 0, observations: 0 }, limits };
  const runPath = runFile(dir, id); const abort = new AbortController(); let deadline = false, cancelled = false;
  const timer = setTimeout(() => { deadline = true; abort.abort(); }, limits.timeoutMs);
  const ctx = currentJob();
  const cancellation = ctx ? setInterval(() => { void getJob(dir, id).then(j => { if (j?.status === 'cancelled') { cancelled = true; abort.abort(); } }); }, 100) : null;
  let mirror: http.Server | undefined;
  const persist = async () => { await fs.mkdir(path.dirname(runPath), { recursive: true }); const temp = `${runPath}.tmp`; await fs.writeFile(temp, JSON.stringify(report, null, 2), { mode: 0o600 }); await fs.rename(temp, runPath); };
  const emit = async (message: string) => { if (ctx) await appendJobEvent(id, 'info', message, 'JavaScript Leaks'); };
  const check = () => { if (abort.signal.aborted) throw new Error(cancelled ? 'Scan cancelled.' : 'JavaScript Leaks scan timed out.'); };
  // Unlike runProcess, this captures sensitive CLI output only in memory, with a strict cap.
  const cli = (args: string[], input = '') => new Promise<string>((resolve, reject) => {
    check(); const child = spawn(engine.command, [...engine.prefix, ...args], { shell: false, windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] }); registerChild(child);
    let output = '', size = 0, settled = false, hasStderr = false;
    const stop = () => { child.kill('SIGKILL'); finish(new Error(cancelled ? 'Scan cancelled.' : 'JavaScript Leaks scan timed out.')); };
    function finish(error?: Error) { if (settled) return; settled = true; abort.signal.removeEventListener('abort', stop); error ? reject(error) : resolve(output); }
    abort.signal.addEventListener('abort', stop, { once: true });
    child.stdout.on('data', b => { size += b.length; if (size > 4 * 1024 * 1024) { child.kill('SIGKILL'); finish(new Error('JSLeak output exceeded the safety limit.')); } else output += b.toString(); });
    child.stderr.on('data', b => { hasStderr ||= Boolean(b.toString().trim()); size += b.length; if (size > 4 * 1024 * 1024) { child.kill('SIGKILL'); finish(new Error('JSLeak output exceeded the safety limit.')); } });
    child.on('error', () => finish(new Error('JSLeak could not start. Install the pinned existing JSLeak binary with the project installer.')));
    child.on('close', code => finish(code === 0 && !hasStderr ? undefined : new Error(`JSLeak failed (exit ${code ?? 'signal'}${hasStderr ? '; scanner reported errors' : ''}).`)));
    child.stdin.on('error', () => undefined); child.stdin.end(input);
  });
  try {
    await persist();
    const pointer = path.join(dir, 'js-leaks', 'latest.json');
    await fs.writeFile(`${pointer}.tmp`, JSON.stringify({ id }), { mode: 0o600 }); await fs.rename(`${pointer}.tmp`, pointer);
    await emit('Collecting fresh, same-origin JavaScript sources.');
    const origin = new URL(target).origin; const queue: Array<{ url: string; script: boolean }> = [{ url: target, script: /\.m?js$/i.test(new URL(target).pathname) }];
    const seen = new Set<string>(), docs: Document[] = []; let bytes = 0;
    const enqueue = (raw: string, base: string, script = true) => {
      try { const u = new URL(raw, base); u.hash = ''; if (!['http:', 'https:'].includes(u.protocol) || u.origin !== origin || u.username || u.password) { if (!report.warnings.includes('External or unsupported JavaScript references were excluded by scope.')) report.warnings.push('External or unsupported JavaScript references were excluded by scope.'); return; }
        if (!seen.has(u.toString()) && !queue.some(x => x.url === u.toString())) { if (seen.size + queue.length >= limits.documents) { if (!report.warnings.includes('Document limit reached; coverage is partial.')) report.warnings.push('Document limit reached; coverage is partial.'); } else queue.push({ url: u.toString(), script }); }
      } catch { /* Invalid discovered references are never requested. */ }
    };
    while (queue.length) {
      check(); const item = queue.shift()!; if (seen.has(item.url)) continue; seen.add(item.url);
      try {
        const loopback = ['127.0.0.1', 'localhost', '[::1]'].includes(new URL(item.url).hostname);
        const response = await axios.get(item.url, { signal: abort.signal, timeout: limits.requestTimeoutMs, responseType: 'text', transformResponse: [x => x], ...(loopback ? { proxy: false as const } : {}),
          maxContentLength: limits.documentBytes, maxBodyLength: limits.documentBytes, maxRedirects: 3, validateStatus: () => true,
          beforeRedirect: (options: any) => { const u = new URL(`${options.protocol}//${options.hostname}${options.port ? ':' + options.port : ''}${options.path}`); if (u.origin !== origin || u.username || u.password) throw new Error('Out-of-scope redirect.'); },
        });
        if (response.status !== 200) throw new Error(`HTTP ${response.status}`);
        const body = String(response.data); bytes += Buffer.byteLength(body); if (bytes > limits.totalBytes) throw new Error('Total response size limit reached.');
        const finalUrl = response.request?.res?.responseUrl || item.url;
        const isHtml = /html/i.test(String(response.headers['content-type'])) || (!item.script && /^\s*</.test(body));
        if (!isHtml && !item.script && !/javascript|ecmascript|text\/plain/i.test(String(response.headers['content-type']))) throw new Error('Unsupported response content type.');
        const doc: Document = { url: finalUrl, body, kind: isHtml ? 'html' : 'javascript' }; docs.push(doc);
        if (isHtml) { const $ = load(body); $('script[src]').each((_i, e) => { enqueue($(e).attr('src')!, finalUrl); }); $('a[href]').each((_i, e) => { const href = $(e).attr('href')!; if (/\.m?js(?:[?#]|$)/i.test(href)) enqueue(href, finalUrl); }); }
        else for (const m of body.matchAll(/(?:\b(?:import|export)\s+(?:[^'";\n]*?\s+from\s*)?|\bimport\s*\(\s*)['"]([^'"\n]+)['"]/g)) if (/^(?:\.{0,2}\/|https?:\/\/)/.test(m[1])) enqueue(m[1], finalUrl);
        report.counts.documents = docs.length; report.counts.javascript = docs.filter(x => x.kind === 'javascript').length; await persist();
      } catch (e: any) {
        check(); const reason = e.code === 'ECONNABORTED' ? 'request timed out' : /^HTTP \d+$/.test(e.message) ? e.message : 'request failed, redirected out of scope, or exceeded size limits';
        if (!docs.length) throw new Error(`Target ${reason}.`);
        report.warnings.push(`${safeUrl(item.url)}: ${reason}.`);
        if (bytes > limits.totalBytes) break;
      }
    }
    check(); report.phase = 'analyzing'; await persist(); await emit(`Collected ${docs.length} document(s); starting the existing JSLeak scanner.`);
    // JSLeak only receives bounded snapshots on loopback: no JS execution, TLS bypass, or unbounded refetch.
    const mirrors = new Map<string, Document>(), served = new Set<string>(); const token = crypto.randomBytes(16).toString('hex');
    mirror = http.createServer((req, res) => { const key = `http://127.0.0.1:${(mirror!.address() as any).port}${req.url}`; const doc = mirrors.get(key); if (!doc || req.method !== 'GET') { res.writeHead(404); res.end(); return; } served.add(key); res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end(doc.body); });
    await new Promise<void>((resolve, reject) => { mirror!.once('error', reject); mirror!.listen(0, '127.0.0.1', resolve); });
    const port = (mirror.address() as any).port; docs.forEach((doc, i) => mirrors.set(`http://127.0.0.1:${port}/${token}/${i}`, doc));
    const output = await cli(['-s', '-l', '-c', '4'], [...mirrors.keys()].join('\n') + '\n');
    check(); if (served.size !== mirrors.size) throw new Error('JSLeak did not read every collected source. Scan coverage is unverified.');
    report.findings = parseOutput(output, mirrors, origin);
    report.counts.candidates = report.findings.filter(x => x.type === 'secret-candidate').length;
    report.counts.endpoints = report.findings.filter(x => x.type === 'endpoint').length;
    report.counts.observations = report.findings.filter(x => x.type === 'observation').length;
    report.status = report.warnings.length ? 'partial' : 'completed'; report.phase = 'finished';
    await emit(`JSLeak finished: ${report.counts.candidates} unverified candidate(s), ${report.counts.endpoints} endpoint(s). No credentials were validated.`);
  } catch (e: any) {
    report.status = cancelled ? 'cancelled' : 'failed'; report.phase = deadline ? 'timeout' : cancelled ? 'cancelled' : 'failed'; report.findings = [];
    report.error = deadline ? 'JavaScript Leaks scan timed out. Coverage is incomplete.' : String(e.message || 'JavaScript Leaks failed.');
  } finally {
    clearTimeout(timer); if (cancellation) clearInterval(cancellation); if (mirror) { mirror.closeAllConnections(); await new Promise<void>(r => mirror!.close(() => r())); }
    report.finishedAt = new Date().toISOString(); try { await persist(); } finally { active.delete(dir); }
  }
  return { success: report.status === 'completed' || report.status === 'partial', partial: report.status === 'partial', message: `JavaScript Leaks ${report.status}.`, error: report.error || null, report };
}

export async function legacyJsLeaks(projectName: string, kind: 'secret-candidate' | 'endpoint') {
  const details = await getDetails(projectName); const result = await scanJsLeaks(projectName, details.targetUrl || `http://${details.domain}/`);
  const rows = result.report.findings.filter(x => x.type === kind);
  return { ...result, result: rows.length, outputFile: runFile(projectPath(projectName), result.report.id) };
}

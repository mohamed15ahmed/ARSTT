// Assessment adapters reuse the existing Job engine. Recon and its runner are untouched.
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import os from 'node:os';
import { spawn } from 'node:child_process';
import { load } from 'cheerio';
import { ROOT, toolPath, getDetails, projectPath } from './core.js';
import { parseTarget, isScopedUrl } from './targets.js';
import { currentJob, getJob, registerChild, appendJobEvent } from './job-engine.js';
import { windowsPathToWsl, resolveTool } from './tool-runtime.js';

export type AssessmentTool = 'nmap'|'whatweb'|'testssl'|'zap'|'nuclei';
export type AssessmentReport = { id: string; tool: AssessmentTool; target: string; status: 'running'|'completed'|'failed'|'timeout'|'cancelled'; startedAt: string; finishedAt?: string; command?: string; error?: string; rows: any[]; warnings: string[]; artifacts: string[]; profile?: string; transportTarget?: string };
const active = new Set<string>();
const toolSet = new Set(['nmap','whatweb','testssl','zap','nuclei']);
export const assessmentTools = toolSet;
export function scrub(input: unknown): string {
  return String(input ?? '').replace(/\x1b\[[0-9;]*m/g, '')
    .replace(/(https?:\/\/)[^\s/@]+:[^\s/@]+@/gi, '$1[redacted]@')
    .replace(/([?&][\w.-]+=)[^\s&#"']*/g, '$1[redacted]')
    .replace(/((?:authorization|cookie|set-cookie|password|passwd|secret|token|api[_-]?key)\s*["']?\s*[:=]\s*)[^\r\n,;]+/gi, '$1[redacted]')
    .replace(/\b(?:AKIA|ASIA)[A-Z0-9]{16}\b/g, '[redacted credential]')
    .replace(/\b(?:gh[pousr]_[A-Za-z0-9_]{20,}|sk-[A-Za-z0-9_-]{20,})\b/g, '[redacted credential]');
}
export function cleanData<T>(value: T): T {
  if (typeof value === 'string') return scrub(value) as T;
  if (Array.isArray(value)) return value.map(cleanData) as T;
  if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).map(([k,v]) => [k, /^(?:password|passwd|secret|token|api[_-]?key|authorization|cookie|set-cookie|request|response|extracted-results)$/i.test(k) ? '[redacted]' : cleanData(v)])) as T;
  return value;
}
export async function validateAssessmentTarget(project: string, input?: unknown) {
  const details = await getDetails(project);
  if (details.authorizationAccepted !== true) throw new Error('Stored authorization acknowledgement is required.');
  const raw = String(input ?? details.targetUrl ?? details.domain).trim();
  if (!raw || raw.length > 2048 || /[\x00-\x20\x7f\\]/.test(raw)) throw new Error('Invalid target.');
  const parsed = parseTarget(raw);
  if (!/^(?:\[[a-f\d:]+\]|[a-z\d](?:[a-z\d.-]*[a-z\d])?)$/i.test(parsed.domain) || !isScopedUrl(parsed.targetUrl, details)) throw new Error('Target must be within the authorized project scope.');
  return parsed.targetUrl;
}
function containerTarget(input:string){const u=new URL(input);if(process.platform!=='linux'&&['localhost','127.0.0.1','[::1]'].includes(u.hostname))u.hostname='host.docker.internal';return u.toString();}
function runDir(project: string, id: string) {
  if (!/^[a-z0-9-]{6,80}$/i.test(id)) throw new Error('Invalid job ID.');
  return path.join(projectPath(project), 'security', 'runs', id);
}
async function save(project: string, report: AssessmentReport) {
  const dir = runDir(project, report.id); await fs.mkdir(dir, { recursive: true });
  const file = path.join(dir, 'report.json'), temp = `${file}.${crypto.randomBytes(4).toString('hex')}.tmp`;
  await fs.writeFile(temp, JSON.stringify(cleanData(report), null, 2), { mode: 0o600 }); await fs.rename(temp, file);
}
export async function readAssessment(project: string, id: string): Promise<AssessmentReport | null> {
  const file = path.join(runDir(project, id), 'report.json');
  try {
    let report = JSON.parse(await fs.readFile(file, 'utf8')) as AssessmentReport;
    if (report.status === 'running' && !active.has(id)) {
      // A final atomic rename may have completed while readFile read the previous inode.
      report = JSON.parse(await fs.readFile(file, 'utf8'));
      if (report.status === 'running') { report.status = 'failed'; report.error = 'Execution was interrupted; completion was not verified.'; }
    }
    return report;
  } catch (e: any) { if (e.code === 'ENOENT') return null; throw new Error('Saved report is invalid.'); }
}
export async function assessmentLog(level: 'info'|'error'|'command', text: string) {
  const ctx = currentJob(); if (ctx) { let safe=scrub(text); try { safe=JSON.stringify(cleanData(JSON.parse(text))); } catch {} await appendJobEvent(ctx.jobId, level, safe); }
}
export class ScanTimeout extends Error {}
async function checkCancellation(){ const ctx=currentJob(); if(ctx){ const j=await getJob(ctx.projectDir,ctx.jobId); if(j?.status==='cancelled'||j?.events.some(e=>e.message.startsWith('Cancellation requested.')))throw new Error('Scan cancelled.'); } }
export async function assessmentProcess(command: string, args: string[], options: { timeout: number; codes?: number[]; cwd?: string; quiet?: boolean }) {
  await checkCancellation();
  await assessmentLog('command', [command, ...args].map(x => JSON.stringify(x)).join(' '));
  return new Promise<{ stdout: string; stderr: string; code: number }>((resolve, reject) => {
    const child = spawn(command, args, { shell: false, detached: process.platform !== 'win32', windowsHide: true, cwd: options.cwd, env: { ...process.env, XDG_CONFIG_HOME: process.env.XDG_CONFIG_HOME || path.join(ROOT,'.runtime','config'), XDG_CACHE_HOME: process.env.XDG_CACHE_HOME || path.join(ROOT,'.runtime','cache') }, stdio: ['ignore','pipe','pipe'] });
    registerChild(child);
    let stdout = '', stderr = '', failure: Error | undefined, bytes = 0;
    const buffers = { info: '', error: '' }; let pending = Promise.resolve();
    const kill = () => { try { if (process.platform !== 'win32' && child.pid) process.kill(-child.pid, 'SIGKILL'); else child.kill('SIGKILL'); } catch {} };
    const timer = setTimeout(() => { failure = new ScanTimeout('Scanner execution timed out.'); kill(); }, options.timeout);
    const ctx = currentJob();
    const cancelled = setInterval(() => { if (ctx) void getJob(ctx.projectDir, ctx.jobId).then(job => { if (job?.status === 'cancelled') { failure = new Error('Scan cancelled.'); kill(); } }); }, 100);
    function receive(level: 'info'|'error', chunk: Buffer) {
      bytes += chunk.length; if (bytes > 8 * 1024 * 1024) { failure = new Error('Scanner output exceeded the 8 MiB limit.'); kill(); return; }
      if (level === 'info') stdout += chunk.toString(); else stderr += chunk.toString();
      if (options.quiet) return;
      buffers[level] += chunk.toString(); const lines = buffers[level].split(/\r?\n/); buffers[level] = lines.pop() || '';
      for (const line of lines) pending = pending.then(() => assessmentLog(level, line));
    }
    child.stdout.on('data', chunk => receive('info', chunk)); child.stderr.on('data', chunk => receive('error', chunk));
    child.once('error', e => { failure = e; });
    child.once('close', async code => {
      clearTimeout(timer); clearInterval(cancelled);
      if (!options.quiet) for (const level of ['info','error'] as const) if (buffers[level]) pending = pending.then(() => assessmentLog(level, buffers[level]));
      await pending;
      if (failure) return reject(failure);
      if (!(options.codes || [0]).includes(code ?? -1)) return reject(new Error(`Scanner exited with code ${code}. ${scrub(stderr).slice(-1500)}`));
      resolve({ stdout, stderr, code: code! });
    });
  });
}
async function cleanupContainer(name: string) {
  await new Promise<void>(resolve => {
    const child = spawn('docker',['rm','-f',name],{shell:false,stdio:'ignore',windowsHide:true});
    const timer = setTimeout(() => { child.kill('SIGKILL'); resolve(); },8000);
    child.once('error',() => { clearTimeout(timer); resolve(); });
    child.once('close',() => { clearTimeout(timer); resolve(); });
  });
}
export function parseNmap(xml: string) {
  if (!xml.trim().endsWith('</nmaprun>') || /<!ENTITY/i.test(xml)) throw new Error('Nmap XML is incomplete or invalid.');
  const $ = load(xml, { xmlMode: true });
  if ($('nmaprun > runstats > finished').attr('exit') !== 'success') throw new Error('Nmap did not report a successful completion.');
  if ($('host[timedout="true"]').length) throw new ScanTimeout('Nmap host timeout.');
  if (!$('runstats hosts').length || !(Number($('runstats hosts').attr('total')) > 0)) throw new Error('Nmap did not scan a resolved host. Check the target hostname.');
  return $('host').toArray().flatMap(host => {
    const address = $(host).find('address').first().attr('addr') || 'unknown';
    return $(host).find('port').toArray().filter(port => $(port).find('state').attr('state') === 'open').map(port => {
      const service = $(port).find('service');
      return { address, port: Number($(port).attr('portid')), protocol: $(port).attr('protocol'), state: 'open', service: service.attr('name') || 'unknown', product: service.attr('product'), version: service.attr('version'), extra: service.attr('extrainfo') };
    });
  });
}
export function parseWhatWeb(raw: string, target: string) {
  const data = JSON.parse(raw);
  if (!Array.isArray(data) || !data.length || data.some(row => !row || !Number.isInteger(row.http_status) || row.http_status <= 0 || !row.plugins || typeof row.plugins !== 'object' || row.target !== target)) throw new Error('WhatWeb returned no valid HTTP result for this target.');
  return data.flatMap(row => Object.entries(row.plugins).map(([name, value]: [string, any]) => ({ name, version: Array.isArray(value.version) && value.version.length ? value.version.join(', ') : 'Unknown', source: row.target, status: row.http_status, evidence: cleanData(value), confidence: value.certainty ?? 'Not supplied by tool' })));
}
export function parseTestssl(raw: string) {
  const data = JSON.parse(raw);
  if (!Array.isArray(data) || !data.length || data.some(row => !row || typeof row.id !== 'string' || typeof row.severity !== 'string' || typeof row.finding !== 'string')) throw new Error('testssl.sh JSON is invalid.');
  if (data.some(row => row.severity === 'FATAL' || row.id === 'scanProblem')) throw new Error('testssl.sh reported incomplete coverage or a scan problem.');
  if (!data.some(row => row.id === 'scanTime' && row.severity === 'INFO' && !/interrupt/i.test(row.finding))) throw new Error('testssl.sh completion marker is missing.');
  return data.filter(row => row.id !== 'scanTime').map(row => ({ id: row.id, category: row.severity === 'OK' ? 'Positive' : ['WARN','LOW','MEDIUM','HIGH','CRITICAL'].includes(row.severity) ? row.severity === 'WARN' ? 'Warning' : 'Issue' : 'Information', severity: row.severity, finding: row.finding, source: row.ip || row.id, evidence: cleanData(row), references: [row.cve, row.cwe].filter(Boolean) }));
}
export const nucleiProfiles: Record<string, { dirs: string[]; dast?: boolean; severity?: string }> = {
  general: { dirs:['http/misconfiguration','http/exposures','http/exposed-panels'] },
  panels: { dirs:['http/exposed-panels'] },
  exposures: { dirs:['http/exposures'] },
  defaults: { dirs:['http/default-logins'], severity:'low,medium,high,critical' },
  takeovers: { dirs:['http/takeovers'] },
  cves: { dirs:['http/cves'], severity:'medium,high,critical' },
  lfi: { dirs:['dast/vulnerabilities/lfi'], dast:true, severity:'medium,high,critical' },
  sqli: { dirs:['dast/vulnerabilities/sqli'], dast:true, severity:'medium,high,critical' },
};
export function parseNuclei(raw: string, log: string, target: string) {
  if (/\[FTL\]|Could not run nuclei|no valid templates|no templates provided/i.test(log)) throw new Error('Nuclei failed to load or execute its templates.');
  const stats = log.split(/\r?\n/).flatMap(line => { try { const r = JSON.parse(line); return r.requests !== undefined && r.templates !== undefined ? [r] : []; } catch { return []; } }).at(-1);
  if (!stats || Number(stats.templates) <= 0 || Number(stats.requests) <= 0) throw new Error('Nuclei did not provide evidence of executed requests and loaded templates.');
  if (Number(stats.errors) > 0) throw new Error(`Nuclei reported ${Number(stats.errors)} request errors; coverage is incomplete.`);
  const seen = new Set<string>();
  return raw.split(/\r?\n/).filter(Boolean).map(line => {
    const row = JSON.parse(line);
    if (!row['template-id'] || !row.info?.name || !['info','low','medium','high','critical','unknown'].includes(row.info.severity)) throw new Error('Nuclei returned an invalid finding.');
    const source = row['matched-at'] || row.url || row.host || target;
    const input = new URL(target), actual = new URL(source);
    if (input.origin !== actual.origin) throw new Error('Nuclei returned an out-of-scope result.');
    const id = crypto.createHash('sha256').update(JSON.stringify([row['template-id'],source,row['matcher-name'],row['extracted-results']])).digest('hex').slice(0,24);
    return { id, title:row.info.name, severity:row.info.severity, source, verification:'Scanner match — review required', references:row.info.reference || [], evidence:cleanData(row) };
  }).filter(row => { if (seen.has(row.id)) return false; seen.add(row.id); return true; });
}
export function parseZap(raw: string, target: string) {
  const report = JSON.parse(raw), sites = report.site;
  if (!report['@version'] || !Array.isArray(sites) || !sites.length) throw new Error('ZAP produced no valid site report.');
  if (sites.some(site => !site['@name'] || new URL(site['@name']).origin !== new URL(target).origin || !Array.isArray(site.alerts))) throw new Error('ZAP site report does not match this job target.');
  return sites.flatMap(site => site.alerts.map((a: any) => {
    if (!a.pluginid || !a.alert || !['0','1','2','3'].includes(String(a.riskcode))) throw new Error('ZAP returned an invalid alert.');
    return { id:String(a.pluginid), title:a.alert, severity:({ '0':'info','1':'low','2':'medium','3':'high' } as any)[String(a.riskcode)], confidence:a.confidence, source:site['@name'], verification:'Passive alert — review required', references:a.reference ? [a.reference] : [], evidence:cleanData(a) };
  }));
}
// Only internal tests can shorten the budget. HTTP clients cannot supply executable paths or flags.
export async function runAssessment(project: string, tool: AssessmentTool, input?: string, budgetOverride?: number, profile = 'general') {
  const target = await validateAssessmentTarget(project, input);
  if (!toolSet.has(tool)) throw new Error('Unsupported assessment tool.');
  const id = currentJob()?.jobId || crypto.randomUUID();
  const dir = runDir(project, id);
  const report: AssessmentReport = { id, tool, target: scrub(target), status: 'running', startedAt: new Date().toISOString(), rows: [], warnings: [], artifacts: [] };
  let acquired=false, persisted=false;
  try {
    if(active.size>=2)throw new Error('Two assessment processes are already active. Try again after one finishes.');
    active.add(id);acquired=true;
    await save(project, report);
    const runtime = tool === 'nuclei' ? { ready: true, command: toolPath('nuclei'), prefix: [], mode: 'native' } : tool === 'zap' && process.env.ARSTT_ZAP ? { ready: true, command: process.env.ARSTT_ZAP, prefix: [], mode: 'automation' } : await resolveTool(tool as any);
    await checkCancellation();
    if (!runtime.ready) throw new Error('detail' in runtime ? runtime.detail : 'Tool is unavailable.');
    const work = await fs.mkdtemp(path.join(os.tmpdir(), `arstt-${tool}-${id}-`));
    const output = path.join(work, tool === 'nmap' ? 'nmap.xml' : tool === 'nuclei' ? 'nuclei.jsonl' : `${tool}.json`);
    let validated = false;
    try {
      let args: string[]; let transportTarget=target;
      if (tool === 'nmap') {
        const url = new URL(target);
        args = ['-sT','-sV','--version-light','-T3','--max-retries','1','--host-timeout','60s','--stats-every','5s','--max-rate','100','--max-parallelism','10','-oX',output];
        if (url.port) args.push('-p', url.port);
        if (url.hostname.includes(':')) args.push('-6');
        args.push(url.hostname.replace(/^\[|\]$/g, ''));
      } else if (tool === 'whatweb') {
        args = ['-a','1','--follow-redirect=never','--open-timeout=8','--read-timeout=8',`--log-json=${runtime.mode === 'wsl' ? windowsPathToWsl(output) : output}`,target];
      } else if (tool === 'testssl') {
        const url = new URL(runtime.mode==='docker'?containerTarget(target):target), host = `${url.hostname}:${url.port || (url.protocol === 'https:' ? '443' : '80')}`;
        args = ['--warnings','batch','--color','0','--disable-rating','--connect-timeout','5','--openssl-timeout','5','--ip','one','--jsonfile',runtime.mode === 'wsl' ? windowsPathToWsl(output) : output,host];
        if (runtime.mode === 'docker') {
          args = ['run','--rm',...(process.platform==='linux'?['--network','host']:[]),'--memory','512m','--cpus','1','--pids-limit','128','--user',String(process.getuid?.() ?? 1000),'-v',`${work}:/data`,'--workdir','/data','ghcr.io/testssl/testssl.sh:3.2',...args.map(x => x === output ? '/data/testssl.json' : x)];
        }
      }
      else if (tool === 'nuclei') {
        const config = nucleiProfiles[profile]; if (!config) throw new Error('Unknown Nuclei profile.');
        const root = process.env.HUNTERKIT_TEMPLATES || path.join(ROOT,'.tools','nuclei-templates');
        const templates = config.dirs.map(d => path.join(root,d));
        for (const file of templates) await fs.access(file);
        if (config.dast && !new URL(target).search) throw new Error('This DAST profile needs an authorized URL with query parameters.');
        report.profile = profile;
        args = ['-u',target,'-omit-raw','-omit-template','-rsr','2097152','-rss','2097152','-redact','authorization,cookie,set-cookie,token,password,api_key,api-key,secret','-jsonl','-o',output,'-nc','-duc','-ni','-dr','-no-stdin','-ud',root,'-pt','http','-exclude-tags','dos,fuzz,bruteforce','-timeout','8','-retries','0','-mhe','30','-c','8','-bs','8','-rl','40','-stats-json','-si','1'];
        for (const file of templates) args.push('-t',file);
        if (config.dast) args.push('-dast','-fa','low');
        if (config.severity) args.push('-severity',config.severity);
      } else {
        if (runtime.mode === 'automation') {
          await fs.mkdir(path.join(work,'home'));
          const origin = new URL(target).origin.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
          const plan = { env: { contexts: [{ name:'ARSTT', urls:[target], includePaths:[`^${origin}/.*$`] }], parameters:{ failOnError:true, failOnWarning:true, progressToStdout:true } }, jobs:[
            { type:'passiveScan-config', parameters:{ scanOnlyInScope:true } },
            { type:'spider', parameters:{ context:'ARSTT', url:target, maxDuration:1, maxDepth:5, maxChildren:10 } },
            { type:'passiveScan-wait', parameters:{ maxDuration:2 } },
            { type:'report', parameters:{ template:'traditional-json', reportDir:work, reportFile:'zap.json', reportTitle:'ARSTT ZAP passive assessment' } },
            { type:'exitStatus', parameters:{ okExitValue:0, errorExitValue:3, warnExitValue:3 } },
          ] };
          const planFile = path.join(work,'plan.json'); await fs.writeFile(planFile,JSON.stringify(plan));
          args = ['-Xmx1024m','-cmd','-silent','-dir',path.join(work,'home'),'-autorun',planFile,'-config','connection.timeoutInSecs=8','-config','spider.thread=2'];
        } else if (runtime.mode === 'docker') {
          await assessmentProcess('docker',['image','inspect','ghcr.io/zaproxy/zaproxy:stable'],{timeout:10000,quiet:true});
          args = ['run','--rm','--pull=never','--name',`arstt-zap-${id}`,'--memory','2g','--cpus','2','--pids-limit','256'];
          if (process.platform === 'linux') args.push('--network','host');
          transportTarget=containerTarget(target);report.transportTarget=scrub(transportTarget);
          args.push('-v',`${work}:/zap/wrk/:rw`,'-t','ghcr.io/zaproxy/zaproxy:stable','zap-baseline.py','-d','-t',transportTarget,'-m','1','-T','2','-I','-J','zap.json','-z','-silent');
        } else args = ['-d','-t',target,'-m','1','-T','2','-I','-J',output,'-z','-silent'];
      }
      report.command = scrub([runtime.command, ...runtime.prefix, ...args].map(x => JSON.stringify(x)).join(' ')); await save(project, report);
      let budget=budgetOverride ?? (tool==='nmap'?120000:tool==='whatweb'?90000:tool==='zap'?240000:180000);
      if(tool==='nuclei'&&budgetOverride===undefined&&process.env.HUNTERKIT_SCAN_TIMEOUT_MS){budget=Number(process.env.HUNTERKIT_SCAN_TIMEOUT_MS);if(!Number.isFinite(budget)||budget<1000||budget>600000)throw new Error('HUNTERKIT_SCAN_TIMEOUT_MS must be between 1000 and 600000 milliseconds.');}
      const proc = await assessmentProcess(runtime.command, [...runtime.prefix, ...args], { timeout: budget, cwd: work, codes: tool === 'zap' && runtime.mode !== 'automation' ? [0,1,2] : [0] });
      if(tool==='zap'&&runtime.mode!=='automation'){
        const log=proc.stdout+'\n'+proc.stderr;
        if(/Exceeded passive scan timeout/i.test(log))throw new ScanTimeout('ZAP passive scan queue did not finish within its deadline.');
        if(/Automation plan (?:warnings|failures|errors)/i.test(log)||!/(?:Passive scanning complete|Job passiveScan-wait finished)/i.test(log))throw new Error('ZAP passive-scan completion could not be verified. The report is not a completed assessment.');
      }
      if (tool === 'nmap' && /Skipping host.*(?:timeout|timed out)/i.test(proc.stdout + proc.stderr)) throw new ScanTimeout('Nmap host timeout.');
      if ((await fs.stat(output)).size > 16 * 1024 * 1024) throw new Error('Result file exceeded the 16 MiB limit.');
      const raw = await fs.readFile(output, 'utf8');
      if (tool === 'nmap') {
        report.rows = parseNmap(raw);
        report.warnings.push('Open ports are observations; they do not establish a vulnerability.');
      } else if (tool === 'whatweb') {
        const messages = proc.stderr + proc.stdout;
        if (/ERROR Opening:|timed? out|ReadTimeout|OpenTimeout|Timeout::Error|execution expired/i.test(messages)) throw /timed? out|ReadTimeout|OpenTimeout|Timeout::Error|execution expired/i.test(messages) ? new ScanTimeout('WhatWeb connection timed out.') : new Error('WhatWeb could not connect to the target.');
        report.rows = parseWhatWeb(raw, target);
        report.warnings.push('Fingerprints are observations. Unreported versions and technologies remain unknown. Redirects are not followed outside this requested URL.');
      } else if (tool === 'testssl') {
        report.rows = parseTestssl(raw);
        report.warnings.push('Categories preserve testssl.sh severity. No additional security grade is inferred.');
      } else if (tool === 'nuclei') {
        report.rows = parseNuclei(raw, proc.stdout + '\n' + proc.stderr, target);
        report.warnings.push('Template matches are scanner findings requiring review; they are not independent proof of exploitation.');
      } else {
        report.rows = parseZap(raw, transportTarget);
        report.warnings.push('ZAP spider and passive analysis only. No active scan was run.');
      }
      await fs.writeFile(path.join(dir, path.basename(output)), tool === 'nmap' ? scrub(raw) : tool === 'nuclei' ? raw.split(/\r?\n/).filter(Boolean).map(line => JSON.stringify(cleanData(JSON.parse(line)))).join('\n') : JSON.stringify(cleanData(JSON.parse(raw)), null, 2), { mode: 0o600 }); report.artifacts.push(path.basename(output)); validated = true;
    } finally {
      if (!validated) {
        try { const stat = await fs.stat(output); if (stat.size <= 16 * 1024 * 1024) {
          const raw = await fs.readFile(output,'utf8'); let safe = scrub(raw);
          try { safe = JSON.stringify(cleanData(JSON.parse(raw)),null,2); } catch { if (tool === 'nuclei') safe = raw.split(/\r?\n/).filter(Boolean).map(line => { try { return JSON.stringify(cleanData(JSON.parse(line))); } catch { return scrub(line); } }).join('\n'); }
          const name = `incomplete-${path.basename(output)}.txt`; await fs.writeFile(path.join(dir,name),safe,{mode:0o600}); report.artifacts.push(name);
        } } catch {}
      }
      if (tool === 'zap' && runtime.mode === 'docker') await cleanupContainer(`arstt-zap-${id}`);
      await fs.rm(work, { recursive: true, force: true });
    }
    report.status = 'completed';
  } catch (e: any) {
    const ctx=currentJob(), job=ctx?await getJob(ctx.projectDir,ctx.jobId):null;
    const cancelled=job?.status==='cancelled'||job?.events.some(event=>event.message.startsWith('Cancellation requested.'));
    report.rows = []; report.status = cancelled || /cancelled/i.test(e.message) ? 'cancelled' : e instanceof ScanTimeout ? 'timeout' : 'failed'; report.error = cancelled?'Scan cancelled.':scrub(e.message);
    await assessmentLog('error', report.error!);
  } finally {
    report.finishedAt = new Date().toISOString();
    try { await save(project, report); persisted=true; }
    catch(e:any){ report.status='failed';report.rows=[];report.error=`Could not save this run's report: ${scrub(e.message)}`;await assessmentLog('error',report.error); }
    finally { if(acquired)active.delete(id); }
  }
  return { success: report.status === 'completed', status: report.status, result: report.rows.length, id, tool, target: report.target, startedAt:report.startedAt, finishedAt:report.finishedAt, outputFile: persisted?path.join(dir, 'report.json'):undefined, error: report.error, message: `${tool}: ${report.status}; ${report.rows.length} record(s).` };
}

import fs from 'node:fs/promises';
import path from 'node:path';
import { projectPath, attackResults } from './core.js';
import { scanHistory, scanDetail } from './scan-history.js';
import { cleanData } from './assessment.js';

export async function reportData(projectName: string) {
  const history = await scanHistory(projectName), scans=[];
  for (const entry of history) scans.push({ ...entry, report:await scanDetail(projectName,entry.id) });
  let legacySecurity:any[]=[];
  try { legacySecurity=JSON.parse(await fs.readFile(path.join(projectPath(projectName),'security','findings.json'),'utf8')); if(!Array.isArray(legacySecurity))throw new Error('Invalid legacy security report.'); }
  catch(e:any){if(e.code!=='ENOENT')throw e;}
  const attack=await attackResults(projectName);
  const legacy=legacySecurity.map(f=>({...f,linkedJobId:null,provenance:'Legacy security finding — per-job association unavailable'}));
  for(const r of attack) {
    if(legacySecurity.some(f=>(f.id===r['template-id']||`${String(f.tool).toLowerCase()}-${f.id}`===r['template-id'])&&f.target===r.url))continue;
    legacy.push({id:r['template-id'],tool:r.sources?.map((x:any)=>x.module).join(', ')||'Legacy scanner',target:r.url,title:r.info?.name,severity:r.info?.severity,verificationStatus:'Legacy scanner evidence — review original record',evidence:r,discoveredAt:r.sources?.find((x:any)=>x.date)?.date||null,linkedJobId:null,provenance:'Legacy attack file — not attributable to a particular job'});
  }
  return cleanData({schema:'arstt-report-1',name:'Automated Reconnaissance and Security Testing Toolkit (ARSTT)',project:projectName,generatedAt:new Date().toISOString(),scans,legacyFindings:legacy,academicAI:{trained:false,predictions:[],metrics:null},limitations:['Scanner matches require review; open ports and technology fingerprints do not establish vulnerabilities.','Failed, timeout, cancelled and partial scans are not clean assessments.','Legacy findings are explicitly unlinked from individual jobs.']});
}
export async function jsonReport(projectName: string){return JSON.stringify(await reportData(projectName),null,2);}
function csvCell(value:any){let s=String(value??'').replace(/\r?\n/g,' ');if(/^[=+@\-\t]/.test(s))s="'"+s;return `"${s.replace(/"/g,'""')}"`;}
function findingRows(data:any){
  const result:any[]=[];
  for(const scan of data.scans){const report=scan.report||{}, rows=report.rows?.length?report.rows:[{}];
    for(const row of rows)result.push({tool:scan.tool,target:scan.target,testType:report.kind||'assessment',title:row.title||row.name||row.finding||(row.port?`Open ${row.protocol} port ${row.port}`:''),severity:row.severity||'',confidence:row.confidence||'',verificationStatus:row.verification||row.category||'',evidence:Object.keys(row).length?JSON.stringify(row):scan.error||'',remediation:row.evidence?.solution||'',discoveredAt:scan.startedAt||scan.createdAt,jobId:scan.id,scanStatus:scan.status,finishedAt:scan.finishedAt,references:JSON.stringify(row.references||[]),aiPrediction:''});
  }
  for(const row of data.legacyFindings)result.push({...row,testType:'Legacy — job association unavailable',jobId:'',scanStatus:'unknown',aiPrediction:''});
  return result;
}
export async function csvReport(projectName:string){const data=await reportData(projectName),rows=findingRows(data),columns=['tool','target','testType','title','severity','confidence','verificationStatus','evidence','remediation','discoveredAt','jobId','scanStatus','finishedAt','references','aiPrediction'];return [columns.join(','),...rows.map(row=>columns.map(c=>csvCell(row[c])).join(','))].join('\r\n')+'\r\n';}

function ascii(value: any) { return String(value ?? '').replace(/[^\x20-\x7E]/g, '?'); }
function escapePdf(value: string) { return value.replace(/\\/g, '\\\\').replace(/\(/g, '\\(').replace(/\)/g, '\\)'); }
function wrap(text: string, width = 95) {
  const words = ascii(text).replace(/\s+/g, ' ').trim().split(' '); const lines: string[] = []; let line = '';
  for (const word of words) {
    if (!word) continue;
    if (!line) line = word;
    else if ((line + ' ' + word).length <= width) line += ' ' + word;
    else { lines.push(line); line = word; }
    while(line.length>width){lines.push(line.slice(0,width));line=line.slice(width);}
  }
  if (line) lines.push(line); return lines.length ? lines : [''];
}

export async function pdfReport(projectName: string) {
  const data = await reportData(projectName);
  const lines:string[] = ['ARSTT Security Report',`Project: ${ascii(projectName)}`,`Generated: ${data.generatedAt}`,`Saved scans: ${data.scans.length}`,''];
  lines.push('PDF uses ASCII text. JSON/CSV retain original Unicode and complete structured evidence.');
  if(!data.scans.length)lines.push('No saved scan executions. No clean assessment is claimed.');
  for(const scan of data.scans){
    lines.push(...wrap(`Job: ${scan.id} | Tool: ${scan.tool} | Status: ${scan.status}`));
    lines.push(...wrap(`Target: ${scan.target||'Not recorded'}`));
    lines.push(...wrap(`Started: ${scan.startedAt||scan.createdAt||'Not recorded'} | Finished: ${scan.finishedAt||'Not recorded'}`));
    if(scan.error)lines.push(...wrap(`Error: ${scan.error}`));
    for(const row of scan.report?.rows||[])lines.push(...wrap(JSON.stringify(row)));
    if(!scan.report?.rows?.length)lines.push('No result rows recorded for this job. Check its execution status.');
    lines.push('');
  }
  for(const row of data.legacyFindings)lines.push(...wrap(`Unlinked legacy finding: ${JSON.stringify(row)}`));
  lines.push(...wrap('Academic AI: no trained model, no predictions, no evaluation metrics.'));
  for(const limitation of data.limitations)lines.push(...wrap(limitation));
  const perPage = 44; const pages: string[][] = [];
  for (let i = 0; i < lines.length; i += perPage) pages.push(lines.slice(i, i + perPage));
  if (!pages.length) pages.push(['ARSTT Security Report']);

  const objects = new Map<number, string>();
  const pageIds: number[] = []; let nextId = 4;
  for (const pageLines of pages) {
    const pageId = nextId++, contentId = nextId++; pageIds.push(pageId);
    let y = 760; const commands = ['BT', '/F1 10 Tf'];
    for (const line of pageLines) {
      commands.push(`1 0 0 1 45 ${y} Tm (${escapePdf(line)}) Tj`); y -= 16;
    }
    commands.push('ET'); const stream = commands.join('\n');
    objects.set(contentId, `<< /Length ${Buffer.byteLength(stream, 'binary')} >>\nstream\n${stream}\nendstream`);
    objects.set(pageId, `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 3 0 R >> >> /Contents ${contentId} 0 R >>`);
  }
  objects.set(1, '<< /Type /Catalog /Pages 2 0 R >>');
  objects.set(2, `<< /Type /Pages /Count ${pageIds.length} /Kids [${pageIds.map(id => `${id} 0 R`).join(' ')}] >>`);
  objects.set(3, '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>');
  const maxId = nextId - 1;
  let body = '%PDF-1.4\n%ARSTT\n'; const offsets = new Array(maxId + 1).fill(0);
  for (let id = 1; id <= maxId; id++) {
    offsets[id] = Buffer.byteLength(body, 'binary');
    body += `${id} 0 obj\n${objects.get(id) || '<<>>'}\nendobj\n`;
  }
  const xref = Buffer.byteLength(body, 'binary');
  body += `xref\n0 ${maxId + 1}\n0000000000 65535 f \n`;
  for (let id = 1; id <= maxId; id++) body += `${String(offsets[id]).padStart(10,'0')} 00000 n \n`;
  body += `trailer\n<< /Size ${maxId + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`;
  return Buffer.from(body, 'binary');
}

import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { BIN_DIR, ROOT, runProcess } from './core.js';

export type ToolId = 'nmap' | 'whatweb' | 'sqlmap' | 'wapiti' | 'testssl' | 'zap';
export type ToolRuntime = {
  id: ToolId;
  ready: boolean;
  command: string;
  prefix: string[];
  mode: 'native' | 'python' | 'wsl' | 'docker' | 'missing';
  detail: string;
  versionArgs: string[];
};

const exists = (p?: string) => Boolean(p && fs.existsSync(p));
const envName: Record<ToolId, string> = {
  nmap: 'HUNTERKIT_NMAP', whatweb: 'HUNTERKIT_WHATWEB', sqlmap: 'HUNTERKIT_SQLMAP', wapiti: 'HUNTERKIT_WAPITI', testssl: 'HUNTERKIT_TESTSSL', zap: 'HUNTERKIT_ZAP_BASELINE'
};

async function starts(command: string, args: string[], acceptedCodes = [0]) {
  try {
    const r = await runProcess(command, args, { timeout: 10000, acceptedCodes });
    return { ok: true, first: (r.stdout || r.stderr).trim().split(/\r?\n/)[0] || 'Started successfully.' };
  } catch (e: any) { return { ok: false, first: e?.message || String(e) }; }
}

function nativeCandidates(name: string) {
  const win = process.platform === 'win32';
  const exe = win ? `${name}.exe` : name;
  const securityVenv = process.platform === 'win32' ? path.join(ROOT, '.security-venv', 'Scripts', exe) : path.join(ROOT, '.security-venv', 'bin', name);
  const out = [path.join(BIN_DIR, exe), securityVenv, exe];
  if (win) {
    const pf = process.env.ProgramFiles || 'C:\\Program Files';
    const pfx86 = process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)';
    if (name === 'nmap') out.unshift(path.join(pf, 'Nmap', 'nmap.exe'), path.join(pfx86, 'Nmap', 'nmap.exe'));
    const app = process.env.APPDATA;
    const local = process.env.LOCALAPPDATA;
    if (app) {
      for (const py of ['Python313','Python312','Python311','Python310','Python39']) out.unshift(path.join(app, 'Python', py, 'Scripts', exe));
    }
    if (local) {
      for (const py of ['Python313','Python312','Python311','Python310','Python39']) out.unshift(path.join(local, 'Programs', 'Python', py, 'Scripts', exe));
    }
  }
  return [...new Set(out)];
}

async function firstNative(name: string, args: string[]) {
  for (const c of nativeCandidates(name)) {
    if (path.isAbsolute(c) && !exists(c)) continue;
    const t = await starts(c, args, [0,1,2]);
    if (t.ok) return { command: c, detail: t.first };
  }
  return null;
}

async function pythonLauncher() {
  const choices = process.platform === 'win32'
    ? [{ command: 'py.exe', prefix: ['-3'] }, { command: 'python.exe', prefix: [] }, { command: 'python', prefix: [] }]
    : [{ command: 'python3', prefix: [] }, { command: 'python', prefix: [] }];
  for (const c of choices) {
    const t = await starts(c.command, [...c.prefix, '--version']);
    if (t.ok) return { ...c, detail: t.first };
  }
  return null;
}

async function wslTool(name: string, versionArgs: string[]) {
  if (process.platform !== 'win32') return null;
  const check = await starts('wsl.exe', ['-e', 'sh', '-lc', `command -v ${name}`]);
  if (!check.ok) return null;
  const version = await starts('wsl.exe', ['-e', name, ...versionArgs], [0,1,2]);
  return { command: 'wsl.exe', prefix: ['-e', name], detail: version.ok ? `WSL: ${version.first}` : `WSL executable found: ${name}` };
}

async function dockerReady() {
  const t = await starts('docker', ['version', '--format', '{{.Server.Version}}']);
  return t.ok ? t.first : null;
}

function overrideRuntime(id: ToolId, raw: string): ToolRuntime {
  const isPy = /\.py$/i.test(raw);
  return { id, ready: true, command: raw, prefix: [], mode: isPy ? 'python' : 'native', detail: `Configured by ${envName[id]}=${raw}`, versionArgs: id === 'zap' ? ['-h'] : ['--version'] };
}

export async function resolveTool(id: ToolId): Promise<ToolRuntime> {
  const override = String(process.env[envName[id]] || '').trim();
  if (override) {
    if (/\.py$/i.test(override)) {
      const py = await pythonLauncher();
      if (!py) return { id, ready: false, command: override, prefix: [], mode: 'missing', detail: `Python is required to run ${override}.`, versionArgs: ['--version'] };
      const t = await starts(py.command, [...py.prefix, override, id === 'zap' ? '-h' : '--version'], [0,1,2]);
      return { id, ready: t.ok, command: py.command, prefix: [...py.prefix, override], mode: 'python', detail: t.ok ? `${py.detail}; ${t.first}` : t.first, versionArgs: id === 'zap' ? ['-h'] : ['--version'] };
    }
    const t = await starts(override, id === 'zap' ? ['-h'] : ['--version'], [0,1,2]);
    return { ...overrideRuntime(id, override), ready: t.ok, detail: t.ok ? t.first : t.first };
  }

  if (id === 'nmap') {
    const n = await firstNative('nmap', ['--version']);
    if (n) return { id, ready: true, command: n.command, prefix: [], mode: 'native', detail: n.detail, versionArgs: ['--version'] };
  }

  if (id === 'sqlmap') {
    const n = await firstNative('sqlmap', ['--version']);
    if (n) return { id, ready: true, command: n.command, prefix: [], mode: 'native', detail: n.detail, versionArgs: ['--version'] };
    const bundled = path.join(ROOT, '.tools', 'sqlmap', 'sqlmap.py');
    const py = await pythonLauncher();
    if (py && exists(bundled)) {
      const t = await starts(py.command, [...py.prefix, bundled, '--version']);
      if (t.ok) return { id, ready: true, command: py.command, prefix: [...py.prefix, bundled], mode: 'python', detail: `Bundled sqlmap via ${py.detail}: ${t.first}`, versionArgs: ['--version'] };
    }
  }

  if (id === 'wapiti') {
    const n = await firstNative('wapiti', ['--version']);
    if (n) return { id, ready: true, command: n.command, prefix: [], mode: 'native', detail: n.detail, versionArgs: ['--version'] };
  }

  if (id === 'whatweb') {
    if (process.platform !== 'win32') {
      const n = await firstNative('whatweb', ['--version']);
      if (n) return { id, ready: true, command: n.command, prefix: [], mode: 'native', detail: n.detail, versionArgs: ['--version'] };
    }
    const w = await wslTool('whatweb', ['--version']);
    if (w) return { id, ready: true, ...w, mode: 'wsl', versionArgs: ['--version'] };
  }

  if (id === 'testssl') {
    if (process.platform !== 'win32') {
      for (const name of ['testssl.sh', 'testssl']) {
        const n = await firstNative(name, ['--version']);
        if (n) return { id, ready: true, command: n.command, prefix: [], mode: 'native', detail: n.detail, versionArgs: ['--version'] };
      }
    }
    const w = await wslTool('testssl.sh', ['--version']) || await wslTool('testssl', ['--version']);
    if (w) return { id, ready: true, ...w, mode: 'wsl', versionArgs: ['--version'] };
    const docker = await dockerReady();
    if (docker) return { id, ready: true, command: 'docker', prefix: [], mode: 'docker', detail: `Docker ${docker}; official testssl.sh container will be used.`, versionArgs: ['version'] };
  }

  if (id === 'zap') {
    if (process.platform !== 'win32') {
      const n = await firstNative('zap-baseline.py', ['-h']);
      if (n) return { id, ready: true, command: n.command, prefix: [], mode: 'native', detail: n.detail, versionArgs: ['-h'] };
    }
    const docker = await dockerReady();
    if (docker) return { id, ready: true, command: 'docker', prefix: [], mode: 'docker', detail: `Docker ${docker}; ZAP stable container will be used.`, versionArgs: ['version'] };
  }

  const hints: Record<ToolId, string> = {
    nmap: process.platform === 'win32' ? 'Install Nmap (including Npcap). HunterKit checks both Program Files locations and PATH.' : 'Install nmap and ensure it is in PATH.',
    sqlmap: 'Run SETUP-SECURITY-TOOLS.cmd. HunterKit can run the bundled sqlmap.py through Python on Windows.',
    wapiti: 'Run SETUP-SECURITY-TOOLS.cmd to install Wapiti with Python/pip.',
    whatweb: process.platform === 'win32' ? 'Install/enable WSL and install WhatWeb inside the Linux distribution.' : 'Install WhatWeb and ensure it is in PATH.',
    testssl: process.platform === 'win32' ? 'Install/enable WSL with testssl.sh, or install/start Docker Desktop. HunterKit supports both.' : 'Install testssl.sh and ensure it is in PATH.',
    zap: 'Install and start Docker Desktop. HunterKit uses the official OWASP ZAP stable container automatically.'
  };
  return { id, ready: false, command: '', prefix: [], mode: 'missing', detail: hints[id], versionArgs: [] };
}

export function toolArgs(runtime: ToolRuntime, args: string[]) { return [...runtime.prefix, ...args]; }
export async function runTool(runtime: ToolRuntime, args: string[], opts: any = {}) {
  if (!runtime.ready) throw new Error(runtime.detail);
  return runProcess(runtime.command, toolArgs(runtime, args), opts);
}

export function windowsPathToWsl(input: string) {
  if (process.platform !== 'win32') return input;
  const m = input.match(/^([A-Za-z]):\\(.*)$/);
  if (!m) return input.replace(/\\/g, '/');
  return `/mnt/${m[1].toLowerCase()}/${m[2].replace(/\\/g, '/')}`;
}

export function dockerHostTarget(input: string) {
  if (process.platform !== 'win32' && process.platform !== 'darwin') return input;
  try {
    const u = new URL(input);
    if (['127.0.0.1', 'localhost', '::1'].includes(u.hostname)) u.hostname = 'host.docker.internal';
    return u.toString();
  } catch { return input; }
}

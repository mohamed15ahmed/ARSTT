import express from 'express';
import cors from 'cors';
import path from 'node:path';
import fs from 'node:fs';
import dotenv from 'dotenv';
import * as core from './core.js';
import * as security from './security.js';
import * as jobs from './job-engine.js';
import * as ai from './ai-provider.js';
import { csvReport, pdfReport, jsonReport } from './reports.js';
import { scanHistory, scanDetail, scanSummary } from './scan-history.js';
import { runAssessment, validateAssessmentTarget, readAssessment, assessmentTools } from './assessment.js';
import { validateJsTarget, scanJsLeaks, readJsReport, legacyJsLeaks } from './js-leaks.js';

dotenv.config({ path: path.join(core.ROOT, '.env') });
const app = express();
app.use(cors());
app.use(express.json({ limit: '2mb' }));
app.use('/project-files', express.static(core.PROJECT_DIR));

const first = (args: any[]) => Array.isArray(args?.[0]) ? args[0][0] : args?.[0];

async function dispatchChannel(c: string, args: any[]) {
  const a = first(args) || {};
  switch (c) {
    case 'list-projects': return core.listProjects();
    case 'create-project': return core.createProject(a.projectName, a.domain, a.authorizationAccepted === true);
    case 'get-project-details': return core.getDetails(first(args));
    case 'get-project-scan': return core.getProjectScan(first(args));
    case 'get-attack-result': return { error: false, results: await core.attackResults(first(args)) };
    case 'api-call': return core.apiCall(a.projectName, a.location, a.type);
    case 'subfinder-process': return core.subFinder(a.domain, core.projectPath(a.projectName));
    case 'recon-all': return core.runReconPipeline(core.projectPath(a.projectName));
    case 'httpx-live-domain': return core.liveSubDomains(core.projectPath(a.projectName));
    case 'httpx-screens': return core.screenwin(core.projectPath(a.projectName));
    case 'waybackurls-archive': return core.wayback(core.projectPath(a.projectName));
    case 'waybackurls-js': return core.fetchJs(core.projectPath(a.projectName));
    case 'waybackurls-parameter': return core.parameter(core.projectPath(a.projectName));
    case 'find-secrets': return legacyJsLeaks(a.projectName, 'secret-candidate');
    case 'extra-links': return legacyJsLeaks(a.projectName, 'endpoint');
    case 'general-scan': return runAssessment(a.projectName, 'nuclei', a.target, undefined, 'general');
    case 'exposed-panels': return runAssessment(a.projectName, 'nuclei', a.target, undefined, 'panels');
    case 'default-credentials': return runAssessment(a.projectName, 'nuclei', a.target, undefined, 'defaults');
    case 'exposures': return runAssessment(a.projectName, 'nuclei', a.target, undefined, 'exposures');
    case 'lfi': return runAssessment(a.projectName, 'nuclei', a.target, undefined, 'lfi');
    case 'potential-xss': return core.scanningForXSS(core.projectPath(a.projectName));
    case 'multi-scans': return runAssessment(a.projectName, 'nuclei', a.target, undefined, 'sqli');
    case 'subdomain-takeovers': return runAssessment(a.projectName, 'nuclei', a.target, undefined, 'takeovers');
    case 'vulns-cves': return runAssessment(a.projectName, 'nuclei', a.target, undefined, 'cves');
    case 'security-nmap': return runAssessment(a.projectName, 'nmap', a.target);
    case 'security-testssl': return runAssessment(a.projectName, 'testssl', a.target);
    case 'security-zap': return runAssessment(a.projectName, 'zap', a.target);
    case 'security-whatweb': return runAssessment(a.projectName, 'whatweb', a.target);
    case 'attack-sqlmap': return security.sqlmapAssessment(a.projectName);
    case 'attack-wapiti': return security.wapitiAssessment(a.projectName);
    case 'get-security-state': return security.getSecurityState(first(args));
    case 'get-unified-findings': return security.getUnifiedFindings(first(args));
    case 'security-tool-diagnostics': return security.securityToolDiagnostics();
    case 'fetch-data': return ai.explainFinding(a.userInput);
    case 'ai-status': return ai.aiStatus(Boolean(a.probe));
    case 'ai-analyze-project': return ai.analyzeProject(a.projectName);
    case 'get-project-dir': return core.PROJECT_DIR;
    default: throw new Error(`Unknown IPC channel: ${c}`);
  }
}

app.post('/api/ipc/:channel', async (req, res) => {
  try { res.json(await dispatchChannel(req.params.channel, req.body?.args || [])); }
  catch (e: any) { console.error(e); res.status(500).json({ error: e?.message || String(e) }); }
});

const JOB_CHANNELS = new Set([
  'subfinder-process','recon-all','httpx-live-domain','httpx-screens','waybackurls-archive','waybackurls-js','waybackurls-parameter',
  'find-secrets','extra-links','general-scan','exposed-panels','default-credentials','exposures','lfi','potential-xss','multi-scans','subdomain-takeovers','vulns-cves',
  'security-nmap','security-testssl','security-zap','security-whatweb','attack-sqlmap','attack-wapiti','ai-analyze-project',
]);

// JS Leaks has an isolated validated entry point; Recon channels stay unchanged.
app.post('/api/js-leaks/:project/scans', async (req, res) => {
  try {
    const target = await validateJsTarget(req.params.project, req.body?.target);
    const dir = core.projectPath(req.params.project);
    const job = await jobs.startJob(req.params.project, dir, 'js-leaks-scan', () => scanJsLeaks(req.params.project, target));
    if (job.duplicate) return res.status(409).json({ error: 'A JavaScript Leaks scan is already running for this project.', id: job.id });
    res.status(202).json(job);
  } catch { res.status(400).json({ error: 'Enter an HTTP(S) target within an authorized project scope (maximum 2048 characters).' }); }
});
app.get('/api/js-leaks/:project/latest', async (req, res) => {
  try { res.json(await readJsReport(req.params.project)); }
  catch { res.status(500).json({ error: 'Could not read the saved JavaScript Leaks report.' }); }
});
app.get('/api/js-leaks/:project/runs/:id', async (req, res) => {
  try { const report = await readJsReport(req.params.project, req.params.id); report ? res.json(report) : res.status(404).json({ error: 'Run not found yet.' }); }
  catch { res.status(400).json({ error: 'Could not read this JavaScript Leaks run.' }); }
});

// These endpoints are scoped to assessment jobs; Recon's routes and events are unchanged.
app.get('/api/scans/:project', async (req,res) => {
  try { res.json(await scanHistory(req.params.project)); } catch { res.status(500).json({error:'Could not read saved scan history.'}); }
});
app.get('/api/scans/:project/summary', async (req,res) => {
  try { res.json(await scanSummary(req.params.project)); } catch { res.status(500).json({error:'Could not calculate saved scan totals.'}); }
});
app.get('/api/scans/:project/:id', async (req,res) => {
  try { const report=await scanDetail(req.params.project,req.params.id); report ? res.json(report) : res.status(404).json({error:'Scan not found.'}); } catch { res.status(400).json({error:'Could not read this scan.'}); }
});
app.post('/api/assessments/:project/scans', async (req, res) => {
  try {
    const tool = String(req.body?.tool || '');
    if (!assessmentTools.has(tool)) return res.status(400).json({ error: 'Unsupported assessment tool.' });
    const target = await validateAssessmentTarget(req.params.project, req.body?.target);
    const job = await jobs.startJob(req.params.project, core.projectPath(req.params.project), `assessment-${tool}`, () => runAssessment(req.params.project, tool as any, target, undefined, typeof req.body?.profile === 'string' ? req.body.profile : 'general'));
    res.status(job.duplicate ? 409 : 202).json(job.duplicate ? { ...job, error: 'This tool already has a running scan in this project.' } : job);
  } catch (e: any) { res.status(400).json({ error: e.message }); }
});
app.get('/api/assessments/:project/runs/:id', async (req, res) => {
  try { const report = await readAssessment(req.params.project, req.params.id); report ? res.json(report) : res.status(404).json({ error: 'Run not found yet.' }); }
  catch (e: any) { res.status(400).json({ error: e.message }); }
});

app.post('/api/jobs', async (req, res) => {
  try {
    const channel = String(req.body?.channel || ''); const args = Array.isArray(req.body?.args) ? req.body.args : [];
    if (!JOB_CHANNELS.has(channel)) return res.status(400).json({ error: 'This action is not available as a background job.' });
    const a = first(args) || {}; const projectName = String(a.projectName || '');
    if (!projectName) return res.status(400).json({ error: 'projectName is required for jobs.' });
    const projectDir = core.projectPath(projectName); await core.getDetails(projectName);
    const job = await jobs.startJob(projectName, projectDir, channel, () => dispatchChannel(channel, args));
    res.status(202).json(job);
  } catch (e: any) { res.status(500).json({ error: e?.message || String(e) }); }
});

app.get('/api/jobs', async (req, res) => {
  try { const project = String(req.query.project || ''); res.json(await jobs.listJobs(core.projectPath(project), Number(req.query.limit || 50))); }
  catch (e: any) { res.status(500).json({ error: e?.message || String(e) }); }
});
app.get('/api/jobs/:id', async (req, res) => {
  try {
    const project = String(req.query.project || ''); const job = await jobs.getJob(core.projectPath(project), req.params.id);
    if (!job) return res.status(404).json({ error: 'Job not found.' }); res.json(job);
  } catch (e: any) { res.status(500).json({ error: e?.message || String(e) }); }
});
app.get('/api/jobs/:id/events', async (req, res) => {
  const project = String(req.query.project || ''); let projectDir: string;
  try { projectDir = core.projectPath(project); } catch { return res.status(400).end(); }
  const job = await jobs.getJob(projectDir, req.params.id); if (!job) return res.status(404).end();
  res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache, no-transform', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
  const send = (type: string, data: any) => { res.write(`event: ${type}\ndata: ${JSON.stringify(data)}\n\n`); };
  send('snapshot', { id: job.id, status: job.status, channel: job.channel, events: job.events, result: job.result, error: job.error });
  if (['completed','failed','cancelled','partial'].includes(job.status)) { send('done', { status: job.status, result: job.result, error: job.error }); return res.end(); }
  const unsubscribe = jobs.subscribe(job.id, (next, event) => {
    if (event) send('log', event);
    send('status', { status: next.status });
    if (['completed','failed','cancelled','partial'].includes(next.status)) { send('done', { status: next.status, result: next.result, error: next.error }); unsubscribe(); res.end(); }
  });
  req.on('close', unsubscribe);
});
app.delete('/api/jobs/:id', async (req, res) => {
  try {
    const project = String(req.query.project || ''); const record = await jobs.getJob(core.projectPath(project), req.params.id);
    if (!record) return res.status(404).json({ error: 'Job not found.' });
    const ok = await jobs.cancelJob(req.params.id); res.json({ ok });
  } catch (e: any) { res.status(500).json({ error: e?.message || String(e) }); }
});

app.get('/api/reports/:project.json', async (req,res) => {
  try { res.type('application/json').setHeader('Content-Disposition',`attachment; filename="${core.safeProjectName(req.params.project)}-arstt.json"`);res.send(await jsonReport(req.params.project)); }
  catch {res.status(500).json({error:'Could not export the saved report.'});}
});
app.get('/api/reports/:project.csv', async (req, res) => {
  try { res.type('text/csv').setHeader('Content-Disposition', `attachment; filename="${core.safeProjectName(req.params.project)}-arstt.csv"`); res.send(await csvReport(req.params.project)); }
  catch (e: any) { res.status(500).json({ error: e?.message || String(e) }); }
});
app.get('/api/reports/:project.pdf', async (req, res) => {
  try { res.type('application/pdf').setHeader('Content-Disposition', `attachment; filename="${core.safeProjectName(req.params.project)}-arstt.pdf"`); res.send(await pdfReport(req.params.project)); }
  catch (e: any) { res.status(500).json({ error: e?.message || String(e) }); }
});

app.get('/api/health', (_req, res) => res.json({ ok: true, name: 'HunterKit Web Backend', projectDir: core.PROJECT_DIR, binDir: core.BIN_DIR }));
app.get('/api/diagnostics', async (_req, res) => res.json({ ...(await core.toolDiagnostics()), security: await security.securityToolDiagnostics(), ai: await ai.aiStatus(false) }));
const frontend = path.join(core.ROOT, 'frontend', 'dist');
if (fs.existsSync(frontend)) { app.use(express.static(frontend)); app.get('*', (_req, res) => res.sendFile(path.join(frontend, 'index.html'))); }
const port = Number(process.env.PORT || 4000); app.listen(port, '127.0.0.1', () => console.log(`HunterKit Web API: http://127.0.0.1:${port}`));

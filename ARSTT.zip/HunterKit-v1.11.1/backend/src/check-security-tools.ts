import { securityToolDiagnostics } from './security.js';
const info = await securityToolDiagnostics();
console.log('\nHunterKit optional security tool diagnostics');
console.log(`Platform: ${info.platform}`);
console.log('UNAVAILABLE is not reported as a clean scan. Configure/install the tool before using its page.\n');
for (const [name, state] of Object.entries(info).filter(([name]) => name !== 'platform') as any) {
  console.log(`${state.ready ? '✓' : '○'} ${String(name).padEnd(10)} ${state.ready ? 'READY' : 'UNAVAILABLE'}\n  ${state.detail}`);
}

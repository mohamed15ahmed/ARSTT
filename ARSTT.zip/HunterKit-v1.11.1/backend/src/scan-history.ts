import fs from 'node:fs/promises';
import path from 'node:path';
import { getDetails, projectPath } from './core.js';
import { getJob } from './job-engine.js';
import { cleanData, readAssessment } from './assessment.js';
import { readJsReport } from './js-leaks.js';

const processStartedAt=Date.now()-process.uptime()*1000;
export type ScanEntry = { id: string; tool: string; target: string | null; status: string; createdAt: string; startedAt?: string; finishedAt?: string; count?: number; error?: string; hasJob: boolean; source: string };
async function jsonFiles(dir: string) { try { return (await fs.readdir(dir)).filter(n => /^[a-z0-9-]{6,80}\.json$/i.test(n)); } catch (e: any) { if (e.code === 'ENOENT') return []; throw e; } }
function status(value: any) {
  if(value?.skipped===true||value?.result?.skipped===true)return 'skipped';
  if (value?.phase === 'timeout' || value?.status === 'timeout') return 'timeout';
  return ['queued','running','completed','failed','timeout','cancelled','partial'].includes(value?.status) ? value.status : 'unknown';
}
export async function scanDetail(project: string, id: string) {
  const assessment = await readAssessment(project,id);
  if (assessment) return { ...cleanData(assessment), kind:'assessment' };
  const js = await readJsReport(project,id);
  if (js) return { ...cleanData(js), status:status(js), tool:'JSLeak', rows:js.findings.map(f => ({ ...f, source:f.sources.map(s => s.url).join(', ') })), kind:'javascript' };
  const job = await getJob(projectPath(project),id);
  if (!job) return null;
  // Legacy jobs did not always store a target or structured findings. Do not invent them.
  const interrupted=['queued','running'].includes(job.status)&&Date.parse(job.startedAt||job.createdAt)<processStartedAt;
  return cleanData({ id:job.id, tool:job.result?.tool || job.channel, target:job.result?.target || null, status:interrupted?'failed':job.result?.status || status(job), startedAt:job.startedAt, finishedAt:job.finishedAt, error:interrupted?'Server restarted before completion could be verified.':job.error || job.result?.error, rows:[], legacyResult:job.result, kind:job.channel.startsWith('assessment-')?'assessment':'legacy', warnings:[job.channel.startsWith('assessment-')?'This job has no readable persisted report. No clean result is claimed.':'Legacy record: target and per-job structured findings may be unavailable. Original files are retained.'], artifacts:[] });
}
export async function scanHistory(project: string): Promise<ScanEntry[]> {
  await getDetails(project);
  const dir = projectPath(project), rows = new Map<string,ScanEntry>();
  for (const file of await jsonFiles(path.join(dir,'logs','jobs'))) {
    const id = file.slice(0,-5), job = await getJob(dir,id);
    if (!job || job.id !== id) { rows.set(id,{id,tool:'Unknown',target:null,status:'failed',createdAt:'',error:'Saved job record is unreadable; original file retained.',hasJob:false,source:'job'}); continue; }
    const interrupted=['queued','running'].includes(job.status)&&Date.parse(job.startedAt||job.createdAt)<processStartedAt;
    rows.set(id,cleanData({ id, tool:job.result?.tool || job.channel, target:job.result?.target || job.result?.report?.target || null, status:interrupted?'failed':job.result?.status || (job.result?.report ? status(job.result.report) : status(job)), createdAt:job.createdAt, startedAt:job.startedAt, finishedAt:job.finishedAt, error:interrupted?'Server restarted before completion could be verified.':job.error || job.result?.error, hasJob:true, source:'job' }));
  }
  let runs: string[] = []; try { runs = await fs.readdir(path.join(dir,'security','runs')); } catch (e: any) { if (e.code !== 'ENOENT') throw e; }
  for (const id of runs.filter(id => /^[a-z0-9-]{6,80}$/i.test(id))) {
    try { const r = await readAssessment(project,id); if (!r) continue; const old = rows.get(id); rows.set(id,{ id,tool:r.tool,target:r.target,status:r.status,createdAt:old?.createdAt || r.startedAt,startedAt:r.startedAt,finishedAt:r.finishedAt,count:r.rows.length,error:r.error,hasJob:old?.hasJob || false,source:'assessment' }); }
    catch { const old=rows.get(id); rows.set(id,{id,tool:old?.tool || 'Unknown',target:old?.target || null,status:'failed',createdAt:old?.createdAt || '',error:'Saved assessment report is unreadable; original file retained.',hasJob:old?.hasJob || false,source:'assessment'}); }
  }
  for (const file of await jsonFiles(path.join(dir,'js-leaks','runs'))) {
    const id = file.slice(0,-5); try { const r = await readJsReport(project,id); if (!r) continue; const old=rows.get(id); rows.set(id,{id,tool:'JSLeak',target:r.target,status:status(r),createdAt:old?.createdAt || r.startedAt,startedAt:r.startedAt,finishedAt:r.finishedAt,count:r.findings.length,error:r.error,hasJob:old?.hasJob || false,source:'javascript'}); } catch {}
  }
  return cleanData([...rows.values()].sort((a,b) => b.createdAt.localeCompare(a.createdAt) || b.id.localeCompare(a.id)));
}
export async function scanSummary(project: string) {
  const scans = await scanHistory(project), counts: Record<string,number> = {};
  for (const r of scans) counts[r.status] = (counts[r.status] || 0)+1;
  return { total:scans.length, counts, latest:scans.slice(0,5), definitions:{ total:'Distinct saved Job/Run IDs, including failed and incomplete executions. A job and its report count once.', counts:'Status of each saved run. Timeout comes from the assessment report or the JavaScript timeout phase; no clean result is inferred.' } };
}

import { runAssessment } from './assessment.js';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import { projectPath, getDetails, updateDetails, runProcess } from './core.js';
import { resolveTool, runTool, dockerHostTarget, windowsPathToWsl } from './tool-runtime.js';
import { isScopedUrl } from './targets.js';

export type UnifiedFinding = {
  id: string;
  tool: string;
  target: string;
  testType: string;
  title: string;
  severity: 'info' | 'low' | 'medium' | 'high' | 'critical';
  confidence: 'low' | 'medium' | 'high';
  evidence: string;
  discoveredAt: string;
  verificationStatus: 'observation' | 'potential' | 'verified';
  remediation: string;
  sourceRef?: string;
  sources?: Array<{ tool: string; sourceRef?: string; evidence?: string }>;
};

const securityDir = (dir: string) => path.join(dir, 'security');
const findingsFile = (dir: string) => path.join(securityDir(dir), 'findings.json');
const previousFile = (dir: string) => path.join(securityDir(dir), 'previous-findings.json');
const comparisonFile = (dir: string) => path.join(securityDir(dir), 'comparison.json');
const now = () => new Date().toISOString();

function severity(value: any): UnifiedFinding['severity'] {
  const s = String(value || '').toLowerCase();
  if (/critical|fatal/.test(s)) return 'critical';
  if (/high|fail/.test(s)) return 'high';
  if (/medium|warn/.test(s)) return 'medium';
  if (/low/.test(s)) return 'low';
  return 'info';
}
function confidence(value: any): UnifiedFinding['confidence'] {
  const s = String(value || '').toLowerCase();
  if (s.includes('high') || s === '100') return 'high';
  if (s.includes('low')) return 'low';
  return 'medium';
}
function fingerprint(f: Pick<UnifiedFinding, 'tool'|'target'|'title'>) {
  return crypto.createHash('sha256').update(`${f.tool}|${f.target}|${f.title}`.toLowerCase()).digest('hex').slice(0, 20);
}
function mkFinding(input: Omit<UnifiedFinding, 'id'|'discoveredAt'> & Partial<Pick<UnifiedFinding,'discoveredAt'>>): UnifiedFinding {
  return { ...input, id: fingerprint(input), discoveredAt: input.discoveredAt || now() };
}
async function readJsonSafe(file: string, fallback: any) { try { return JSON.parse(await fsp.readFile(file, 'utf8')); } catch { return fallback; } }
async function replaceToolFindings(dir: string, tool: string, rows: UnifiedFinding[]) {
  await fsp.mkdir(securityDir(dir), { recursive: true });
  const current: UnifiedFinding[] = await readJsonSafe(findingsFile(dir), []);
  await fsp.writeFile(previousFile(dir), JSON.stringify(current, null, 2), 'utf8');
  const next = [...current.filter(x => x.tool !== tool), ...rows];
  const unique = [...new Map(next.map(x => [x.id, x])).values()];
  await fsp.writeFile(findingsFile(dir), JSON.stringify(unique, null, 2), 'utf8');
  const before = new Set(current.map(x => x.id)), after = new Set(unique.map(x => x.id));
  const comparison = {
    generatedAt: now(),
    added: unique.filter(x => !before.has(x.id)),
    resolved: current.filter(x => !after.has(x.id)),
    unchanged: unique.filter(x => before.has(x.id)).length,
  };
  await fsp.writeFile(comparisonFile(dir), JSON.stringify(comparison, null, 2), 'utf8');
  return unique;
}
function requireAuthorization(details: any) {
  if (details?.authorizationAccepted !== true) throw new Error('Active testing is blocked until the project authorization checkbox is accepted.');
}
function targetUrl(details: any) { return String(details.targetUrl || `http://${details.domain}/`); }

export async function securityToolDiagnostics() {
  const [nmap, testssl, zap, whatweb, sqlmap, wapiti] = await Promise.all([
    resolveTool('nmap'), resolveTool('testssl'), resolveTool('zap'), resolveTool('whatweb'), resolveTool('sqlmap'), resolveTool('wapiti')
  ]);
  const view = (x: any) => ({ ready: x.ready, detail: x.detail, mode: x.mode });
  return { nmap: view(nmap), testssl: view(testssl), zap: view(zap), whatweb: view(whatweb), sqlmap: view(sqlmap), wapiti: view(wapiti), platform: `${process.platform}-${os.arch()}` };
}

export async function nmapAssessment(projectName: string, target?: string) {
  return runAssessment(projectName, 'nmap', target);
}

function walkTestssl(node: any, out: any[] = []) {
  if (Array.isArray(node)) for (const x of node) walkTestssl(x, out);
  else if (node && typeof node === 'object') {
    if ('severity' in node && ('finding' in node || 'id' in node)) out.push(node);
    for (const value of Object.values(node)) walkTestssl(value, out);
  }
  return out;
}
export async function testsslAssessment(projectName: string, target?: string) {
  return runAssessment(projectName, 'testssl', target);
}

function extractZapAlerts(raw: any): any[] {
  const sites = raw?.site || raw?.sites || []; const rows: any[] = [];
  for (const site of Array.isArray(sites) ? sites : [sites]) for (const alert of site?.alerts || []) rows.push(alert);
  return rows;
}
export async function zapBaseline(projectName: string, target?: string) {
  return runAssessment(projectName, 'zap', target);
}

export async function whatWebAssessment(projectName: string, target?: string) {
  return runAssessment(projectName, 'whatweb', target);
}

async function parameterCandidates(dir: string, details: any): Promise<string[]> {
  const file = path.join(dir, 'waybackurls_parameter.txt');
  const text = await fsp.readFile(file, 'utf8').catch(() => '');
  return [...new Set<string>(text.split(/\r?\n/).map(x => x.trim()).filter((x: string) => x && x.includes('?') && isScopedUrl(x, details)))].slice(0, 5);
}
export async function sqlmapAssessment(projectName: string) {
  const dir = projectPath(projectName), details = await getDetails(projectName); requireAuthorization(details);
  const candidates = await parameterCandidates(dir, details);
  if (!candidates.length) return { success: true, skipped: true, message: 'SQLMap skipped: no in-scope parameterized URLs are available. Run Recon/Get Parameters first.', error: null, result: 0 };
  const runtime = await resolveTool('sqlmap'); const base = path.join(dir, 'attacks', 'sqlmap'); await fsp.mkdir(base, { recursive: true });
  const findings: UnifiedFinding[] = []; const tested: any[] = [];
  for (let i = 0; i < candidates.length; i++) {
    const url = candidates[i]; const report = path.join(base, `report-${i + 1}.json`); const outputDir = path.join(base, `run-${i + 1}`);
    const args: string[] = ['-u', url, '--batch', '--level=1', '--risk=1', '--threads=2', '--timeout=8', '--retries=0', '--smart', '--parse-errors', `--output-dir=${outputDir}`, `--report-json=${report}`];
    let proc: any;
    try { proc = await runTool(runtime, args, { timeout: 120000, acceptedCodes: [0] }); }
    catch (e: any) {
      if (/report-json|unrecognized|no such option/i.test(String(e?.message || ''))) proc = await runTool(runtime, args.filter(x => !x.startsWith('--report-json=')), { timeout: 120000, acceptedCodes: [0] });
      else throw e;
    }
    const combined = `${proc.stdout}\n${proc.stderr}`; tested.push({ url, command: proc.command });
    const positive = /parameter.*(?:is vulnerable|appears to be injectable)|sql injection vulnerability has been detected|identified the following injection point/i.test(combined);
    if (positive) findings.push(mkFinding({ tool: 'sqlmap', target: url, testType: 'SQL Injection Detection', title: 'SQL injection behavior detected by sqlmap', severity: 'high', confidence: 'high', evidence: combined.split(/\r?\n/).filter((x: string) => /inject|parameter|payload|back-end dbms/i.test(x)).slice(-25).join('\n').slice(0, 6000), verificationStatus: 'verified', remediation: 'Use parameterized queries/prepared statements, validate input types, and avoid constructing SQL statements with untrusted input.', sourceRef: `attacks/sqlmap/run-${i + 1}` }));
  }
  await replaceToolFindings(dir, 'sqlmap', findings);
  await fsp.writeFile(path.join(base, 'summary.json'), JSON.stringify({ tested, findings, completedAt: now(), limits: { maxTargets: 5, level: 1, risk: 1, noDump: true } }, null, 2), 'utf8');
  await updateDetails(dir, { sqlmap: { run: true, completed: true, result: findings.length, targets: candidates.length, date: now(), filePath: path.join(base, 'summary.json') } });
  return { success: true, message: `sqlmap completed bounded detection on ${candidates.length} URL(s): ${findings.length} verified injection finding(s). No database extraction options were used.`, error: null, result: findings.length };
}

function collectWapitiVulns(raw: any) {
  const rows: any[] = [];
  const visit = (node: any, category = '') => {
    if (Array.isArray(node)) node.forEach(x => visit(x, category));
    else if (node && typeof node === 'object') {
      if (node.path || node.url || node.info || node.parameter || node.method) rows.push({ ...node, category });
      for (const [key, value] of Object.entries(node)) if (['vulnerabilities','anomalies','additionals'].includes(key) || (value && typeof value === 'object')) visit(value, category || key);
    }
  };
  visit(raw); return rows;
}
export async function wapitiAssessment(projectName: string) {
  const dir = projectPath(projectName), details = await getDetails(projectName); requireAuthorization(details);
  const runtime = await resolveTool('wapiti'); const base = path.join(dir, 'attacks', 'wapiti'); await fsp.mkdir(base, { recursive: true });
  const out = path.join(base, 'report.json'); await fsp.rm(out, { force: true });
  const args = ['-u', targetUrl(details), '--scope', 'url', '-d', '2', '--max-links-per-page', '20', '--max-scan-time', '90', '--max-attack-time', '45', '--tasks', '2', '-m', 'xss,sqli,file,redirect,crlf', '-f', 'json', '-o', out, '--no-bugreport'];
  const proc = await runTool(runtime, args, { timeout: 150000, acceptedCodes: [0,1] });
  const raw = await readJsonSafe(out, {}); const rows = collectWapitiVulns(raw);
  const findings = rows.slice(0, 300).map((x: any) => mkFinding({ tool: 'Wapiti', target: String(x.path || x.url || targetUrl(details)), testType: `Web Vulnerability Testing${x.category ? ` / ${x.category}` : ''}`, title: String(x.name || x.info || x.module || 'Wapiti web finding').slice(0, 220), severity: severity(x.level || x.severity || 'medium'), confidence: 'medium', evidence: JSON.stringify(x).slice(0, 5000), verificationStatus: 'potential', remediation: 'Review the evidence, reproduce safely, then apply input validation, output encoding, least privilege, or server-side hardening appropriate to the affected feature.', sourceRef: 'attacks/wapiti/report.json' }));
  await replaceToolFindings(dir, 'Wapiti', findings);
  await updateDetails(dir, { wapiti: { run: true, completed: true, result: findings.length, date: now(), filePath: out, command: proc.command } });
  return { success: true, message: `Wapiti completed a bounded authorized scan: ${findings.length} candidate finding(s).`, error: null, result: findings.length };
}

export async function getSecurityState(projectName: string) {
  const dir = projectPath(projectName); const details = await getDetails(projectName);
  const [findings, comparison, nmap, whatweb] = await Promise.all([
    readJsonSafe(findingsFile(dir), []), readJsonSafe(comparisonFile(dir), { added: [], resolved: [], unchanged: 0 }), readJsonSafe(path.join(securityDir(dir), 'nmap.json'), null), readJsonSafe(path.join(securityDir(dir), 'whatweb-normalized.json'), null),
  ]);
  return {
    findings, comparison, nmap, whatweb,
    attackSurface: { subdomains: Number(details.subfinder?.result || 0), liveWebServices: Number(details.liveDomains?.result || 0), openPorts: Number(nmap?.ports?.length || 0), technologies: Number(whatweb?.technologies?.length || 0), findings: findings.length },
    scans: { nmap: details.securityNmap, tls: details.securityTls, zap: details.securityZap, whatweb: details.securityWhatWeb, sqlmap: details.sqlmap, wapiti: details.wapiti }
  };
}

export async function getUnifiedFindings(projectName: string) {
  const dir = projectPath(projectName); const securityFindings: UnifiedFinding[] = await readJsonSafe(findingsFile(dir), []);
  const { attackResults } = await import('./core.js'); const attackRows = await attackResults(projectName);
  const mapped = attackRows.map((r: any) => mkFinding({ tool: String(r.sources?.[0]?.module || 'Scanner'), target: String(r.url || ''), testType: 'Legacy HunterKit Attack', title: String(r.info?.name || r['template-id'] || 'Scanner finding'), severity: severity(r.info?.severity), confidence: 'medium', evidence: String(r.info?.description || ''), verificationStatus: /dalfox/i.test(r['template-id'] || '') ? 'verified' : 'potential', remediation: 'Review the scanner evidence and apply the remediation appropriate to the affected component.', sourceRef: String(r['template-id'] || '') }));
  const all = [...new Map([...securityFindings, ...mapped].map(x => [x.id, x])).values()];
  const severityRank: Record<string, number> = { info: 0, low: 1, medium: 2, high: 3, critical: 4 };
  const confidenceRank: Record<string, number> = { low: 0, medium: 1, high: 2 };
  const merged = new Map<string, UnifiedFinding>();
  for (const finding of all) {
    const canonicalTitle = finding.title.toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
    const canonicalTarget = finding.target.toLowerCase().replace(/\/$/, '');
    const key = `${canonicalTarget}|${canonicalTitle}`;
    const source = { tool: finding.tool, sourceRef: finding.sourceRef, evidence: finding.evidence.slice(0, 2000) };
    const existing = merged.get(key);
    if (!existing) { merged.set(key, { ...finding, sources: [source] }); continue; }
    existing.sources = [...(existing.sources || []), source];
    if ((severityRank[finding.severity] || 0) > (severityRank[existing.severity] || 0)) existing.severity = finding.severity;
    if ((confidenceRank[finding.confidence] || 0) > (confidenceRank[existing.confidence] || 0)) existing.confidence = finding.confidence;
    if (!existing.evidence.includes(finding.evidence)) existing.evidence = `${existing.evidence}

Additional source (${finding.tool}): ${finding.evidence}`.slice(0, 8000);
    if (!existing.sourceRef && finding.sourceRef) existing.sourceRef = finding.sourceRef;
  }
  return [...merged.values()].sort((a,b) => b.discoveredAt.localeCompare(a.discoveredAt));
}

import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { AsyncLocalStorage } from 'node:async_hooks';
import type { ChildProcess } from 'node:child_process';

export type JobStatus = 'queued' | 'running' | 'completed' | 'failed' | 'cancelled' | 'partial';
export type JobEvent = {
  seq: number;
  timestamp: string;
  tool: string;
  level: 'info' | 'warn' | 'error' | 'result' | 'command';
  message: string;
};
export type JobRecord = {
  id: string;
  projectName: string;
  projectDir: string;
  channel: string;
  status: JobStatus;
  createdAt: string;
  startedAt?: string;
  finishedAt?: string;
  result?: any;
  error?: string;
  events: JobEvent[];
};

type JobContext = { jobId: string; projectDir: string; tool: string };
const storage = new AsyncLocalStorage<JobContext>();
const jobs = new Map<string, JobRecord>();
const children = new Map<string, Set<ChildProcess>>();
const listeners = new Map<string, Set<(job: JobRecord, event?: JobEvent) => void>>();

function jobsDir(projectDir: string) { return path.join(projectDir, 'logs', 'jobs'); }
function safeJobId(id: string) { if (!/^[a-z0-9-]{6,80}$/i.test(String(id || ''))) throw new Error('Invalid job id'); return String(id); }
function jobFile(projectDir: string, id: string) { return path.join(jobsDir(projectDir), `${safeJobId(id)}.json`); }
function eventsFile(projectDir: string, id: string) { return path.join(jobsDir(projectDir), `${safeJobId(id)}.jsonl`); }

function redact(value: string) {
  return String(value || '')
    .replace(/(authorization:\s*bearer\s+)[^\s]+/ig, '$1[REDACTED]')
    .replace(/([?&](?:api_?key|token|access_?token|password)=)[^&\s]+/ig, '$1[REDACTED]')
    .replace(/((?:api[_-]?key|token|password)\s*[=:]\s*)[^\s,;]+/ig, '$1[REDACTED]');
}

async function persist(job: JobRecord) {
  await fsp.mkdir(jobsDir(job.projectDir), { recursive: true });
  const copy = { ...job, events: job.events.slice(-1500) };
  await fsp.writeFile(jobFile(job.projectDir, job.id), JSON.stringify(copy, null, 2), 'utf8');
}

function notify(job: JobRecord, event?: JobEvent) {
  for (const listener of listeners.get(job.id) || []) {
    try { listener(job, event); } catch {}
  }
}

export async function appendJobEvent(jobId: string, level: JobEvent['level'], message: string, tool?: string) {
  const job = jobs.get(jobId);
  if (!job) return;
  const clean = redact(String(message || '')).slice(0, 12000);
  if (!clean.trim()) return;
  const event: JobEvent = {
    seq: (job.events.at(-1)?.seq || 0) + 1,
    timestamp: new Date().toISOString(),
    tool: tool || job.channel,
    level,
    message: clean,
  };
  job.events.push(event);
  if (job.events.length > 2500) job.events.splice(0, job.events.length - 2500);
  await fsp.mkdir(jobsDir(job.projectDir), { recursive: true });
  await fsp.appendFile(eventsFile(job.projectDir, job.id), JSON.stringify(event) + '\n', 'utf8').catch(() => undefined);
  notify(job, event);
}

export function currentJob() { return storage.getStore(); }
export function registerChild(child: ChildProcess) {
  const ctx = storage.getStore();
  if (!ctx) return;
  const set = children.get(ctx.jobId) || new Set<ChildProcess>();
  set.add(child); children.set(ctx.jobId, set);
  const clear = () => set.delete(child);
  child.once('close', clear); child.once('error', clear);
}
export function processOutput(level: 'info' | 'error', chunk: unknown) {
  const ctx = storage.getStore();
  if (!ctx) return;
  const text = String(chunk || '').replace(/\r/g, '');
  for (const line of text.split('\n').filter(Boolean).slice(-80)) void appendJobEvent(ctx.jobId, level, line, ctx.tool);
}
export function processCommand(command: string) {
  const ctx = storage.getStore();
  if (ctx) void appendJobEvent(ctx.jobId, 'command', command, ctx.tool);
}

export async function startJob(projectName: string, projectDir: string, channel: string, runner: () => Promise<any>) {
  const existing = [...jobs.values()].find(job => job.projectDir === projectDir && job.channel === channel && ['queued','running'].includes(job.status));
  if (existing) return { id: existing.id, status: existing.status, createdAt: existing.createdAt, duplicate: true };
  const id = `${Date.now().toString(36)}-${crypto.randomBytes(4).toString('hex')}`;
  const job: JobRecord = { id, projectName, projectDir, channel, status: 'queued', createdAt: new Date().toISOString(), events: [] };
  jobs.set(id, job);
  await persist(job);
  queueMicrotask(() => {
    void storage.run({ jobId: id, projectDir, tool: channel }, async () => {
      job.status = 'running'; job.startedAt = new Date().toISOString();
      await appendJobEvent(id, 'info', `Job started: ${channel}`, channel);
      await persist(job);
      try {
        const result = await runner();
        job.result = result;
        if ((job.status as JobStatus) !== 'cancelled') {
          if (result?.partial) job.status = 'partial';
          else if (result?.success === false) job.status = 'failed';
          else job.status = 'completed';
        }
        if (job.status === 'completed') await appendJobEvent(id, 'result', result?.message || 'Job completed.', channel);
        else if (job.status === 'partial') await appendJobEvent(id, 'warn', result?.message || 'Job finished with partial coverage.', channel);
        else if (job.status === 'failed') await appendJobEvent(id, 'error', result?.error || result?.message || 'Job failed.', channel);
      } catch (error: any) {
        if ((job.status as JobStatus) !== 'cancelled') job.status = 'failed';
        job.error = error?.message || String(error);
        await appendJobEvent(id, 'error', job.error, channel);
      } finally {
        job.finishedAt = new Date().toISOString();
        await persist(job);
        notify(job);
        children.delete(id);
      }
    });
  });
  return { id, status: job.status, createdAt: job.createdAt };
}

export async function cancelJob(id: string) {
  const job = jobs.get(id);
  if (!job) return false;
  job.status = 'cancelled';
  for (const child of children.get(id) || []) {
    try {
      if (process.platform !== 'win32' && child.pid) process.kill(-child.pid, 'SIGKILL');
      else child.kill('SIGKILL');
    } catch {}
    if (process.platform === 'win32' && child.pid) {
      try {
        const { spawn } = await import('node:child_process');
        const killer = spawn('taskkill', ['/PID', String(child.pid), '/T', '/F'], { windowsHide: true, stdio: 'ignore' });
        killer.unref();
      } catch {}
    }
  }
  await appendJobEvent(id, 'warn', 'Cancellation requested. Active scanner processes were terminated.', job.channel);
  job.finishedAt = new Date().toISOString();
  await persist(job);
  notify(job);
  return true;
}

export async function getJob(projectDir: string, id: string): Promise<JobRecord | null> {
  const inMemory = jobs.get(id);
  if (inMemory && path.resolve(inMemory.projectDir) === path.resolve(projectDir)) return inMemory;
  try {
    const parsed = JSON.parse(await fsp.readFile(jobFile(projectDir, id), 'utf8'));
    return parsed;
  } catch { return null; }
}

export async function listJobs(projectDir: string, limit = 50): Promise<JobRecord[]> {
  const dir = jobsDir(projectDir);
  if (!fs.existsSync(dir)) return [];
  const files = (await fsp.readdir(dir)).filter(x => x.endsWith('.json')).slice(-Math.max(1, limit));
  const rows: JobRecord[] = [];
  for (const file of files) {
    try { rows.push(JSON.parse(await fsp.readFile(path.join(dir, file), 'utf8'))); } catch {}
  }
  return rows.sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt))).slice(0, limit);
}

export function subscribe(jobId: string, listener: (job: JobRecord, event?: JobEvent) => void) {
  const set = listeners.get(jobId) || new Set(); set.add(listener); listeners.set(jobId, set);
  return () => { set.delete(listener); if (!set.size) listeners.delete(jobId); };
}

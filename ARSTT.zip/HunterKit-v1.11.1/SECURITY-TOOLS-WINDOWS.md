# HunterKit - Security Tools on Windows

HunterKit distinguishes **bundled/tested core tools** from **optional system tools**. Optional tools are never shown as working merely because a button exists in the UI. Run:

```bat
npm run check:security-tools
```

The Security Testing and Attacks pages show the same readiness state.

## Nmap

Install Nmap for Windows (Npcap is normally installed with it). HunterKit uses a bounded TCP connect/version-light profile and does not enable intrusive NSE scripts by default. If Nmap is not on PATH, set `HUNTERKIT_NMAP` in `.env` to the full `nmap.exe` path.

## sqlmap

Install Python and sqlmap, then ensure the `sqlmap` command is on PATH (or set `HUNTERKIT_SQLMAP`). HunterKit's built-in profile uses `--level=1 --risk=1`, tests at most five in-scope parameterized URLs, and does **not** request database dumps, file access, OS takeover, or data modification.

## Wapiti

Install Python and `wapiti3`, then verify `wapiti --version`. HunterKit limits crawl depth, links, tasks, total scan time, attack time, and enabled modules.

## WhatWeb

WhatWeb is Ruby-based and is usually easiest to run inside WSL/Kali on Windows. If you expose a runnable wrapper on Windows, point `HUNTERKIT_WHATWEB` to it. HunterKit uses aggression level 1.

## testssl.sh

`testssl.sh` is a shell tool and is normally run through WSL/Kali/Linux. HunterKit will report it unavailable on Windows unless `HUNTERKIT_TESTSSL` points to a runnable wrapper/script environment. It is never marked successful before the executable starts and produces a JSON report.

## OWASP ZAP Baseline

Two supported paths:

1. Put a working `zap-baseline.py` on PATH (or set `HUNTERKIT_ZAP_BASELINE`).
2. Install and start Docker Desktop, then set `HUNTERKIT_ZAP_DOCKER=1` in `.env`.

Docker mode is deliberately opt-in so HunterKit does not silently pull/run containers. The integration uses **ZAP Baseline**, which spiders and waits for passive scanning; it does not substitute an active ZAP full scan.

## Authorization and active testing

New projects require an authorization acknowledgement. `sqlmap` and Wapiti refuse to run if that acknowledgement is missing. Existing HunterKit Nuclei/Dalfox profiles are retained, but the UI clearly separates them from the non-exploitative Security Testing page.

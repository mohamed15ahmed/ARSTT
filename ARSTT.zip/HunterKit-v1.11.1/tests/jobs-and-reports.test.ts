import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { spawn } from 'node:child_process';
import * as core from '../backend/src/core.js';
import { startJob, getJob, cancelJob, registerChild } from '../backend/src/job-engine.js';
import { pdfReport, csvReport } from '../backend/src/reports.js';

test('active scans require stored authorization acknowledgement', async () => {
  const name = `HK-auth-${process.pid}-${Date.now()}`;
  await core.createProject(name, 'http://127.0.0.1:9/', false);
  try {
    const result = await core.exposedPanels(core.projectPath(name));
    assert.equal(result.success, false);
    assert.match(result.error || '', /authorization/i);
  } finally { await fs.rm(core.projectPath(name), { recursive: true, force: true }); }
});

test('job layer persists status and can terminate a real child process', { timeout: 10000 }, async () => {
  const dir = await fs.mkdtemp(path.join(core.ROOT, '.job-test-'));
  try {
    const started = await startJob('unit', dir, 'child-test', async () => new Promise((resolve, reject) => {
      const child = spawn(process.execPath, ['-e', 'setTimeout(()=>{},10000)'], { detached: process.platform !== 'win32' });
      registerChild(child);
      child.once('close', code => code === 0 ? resolve({ success: true }) : reject(new Error(`child stopped: ${code}`)));
    }));
    await new Promise(resolve => setTimeout(resolve, 150));
    assert.equal(await cancelJob(started.id), true);
    await new Promise(resolve => setTimeout(resolve, 150));
    const record = await getJob(dir, started.id);
    assert.equal(record?.status, 'cancelled');
    assert.ok(record?.events.some(event => /Cancellation requested/.test(event.message)));
  } finally { await fs.rm(dir, { recursive: true, force: true }); }
});

test('report exporters produce non-empty valid containers even with zero findings', async () => {
  const name = `HK-report-${process.pid}-${Date.now()}`;
  await core.createProject(name, 'http://127.0.0.1:9/', true);
  try {
    const pdf = await pdfReport(name);
    assert.equal(pdf.subarray(0, 8).toString(), '%PDF-1.4');
    assert.match(pdf.toString('binary'), /%%EOF/);
    const csv = await csvReport(name);
    assert.match(csv, /^tool,target,testType,title,severity/);
  } finally { await fs.rm(core.projectPath(name), { recursive: true, force: true }); }
});

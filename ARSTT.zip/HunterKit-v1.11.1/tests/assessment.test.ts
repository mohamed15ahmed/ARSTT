import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import http from 'node:http';
import os from 'node:os';
import { fixtureServer } from './fixture.js';
import { createProject, projectPath } from '../backend/src/core.js';
import { runAssessment, readAssessment, validateAssessmentTarget, parseNmap, parseWhatWeb, parseTestssl, parseZap, parseNuclei, scrub } from '../backend/src/assessment.js';
import { startJob, getJob, cancelJob } from '../backend/src/job-engine.js';

async function evidence(file: string, data: any) { if (process.env.ARSTT_TEST_EVIDENCE) { await fs.mkdir(process.env.ARSTT_TEST_EVIDENCE,{recursive:true}); await fs.writeFile(path.join(process.env.ARSTT_TEST_EVIDENCE,file),JSON.stringify(data,null,2)); } }
export async function waitJob(project: string, id: string) {
  for (let i = 0; i < 1000; i++) { const j = await getJob(projectPath(project), id); if (j && !['queued','running'].includes(j.status)) return j; await new Promise(r => setTimeout(r, 100)); }
  throw new Error('Test job deadline exceeded.');
}
test('assessment target authorization, scope and injection validation', async () => {
  const p = `assessment-validation-${Date.now()}`; await createProject(p, 'http://127.0.0.1:12345/', true);
  try {
    for (const t of ['--script=x', '127.0.0.1;touch /tmp/no', 'https://outside.invalid/', 'http://u:p@127.0.0.1:12345/', 'http://127.0.0.1:9/', 'file:///etc/passwd']) await assert.rejects(validateAssessmentTarget(p, t));
    assert.equal(await validateAssessmentTarget(p, 'http://127.0.0.1:12345/a'), 'http://127.0.0.1:12345/a');
  } finally { await fs.rm(projectPath(p), { recursive: true, force: true }); }
});
test('Nmap rejects incomplete XML and unsuccessful run statistics', () => {
  assert.throws(() => parseNmap('<nmaprun>'));
  assert.throws(() => parseNmap('<nmaprun><runstats><finished exit="error"/></runstats></nmaprun>'));
});
test('real Nmap: open local port, timeout, new run isolation, job evidence', { timeout: 120000 }, async () => {
  const server = http.createServer((_q,s) => { s.setHeader('Server', 'ARSTT-Training'); s.end('Authorized local training fixture'); });
  server.requestTimeout = 1000; server.headersTimeout = 2000;
  await new Promise<void>(r => server.listen(0, '127.0.0.1', r));
  const port = (server.address() as any).port, p = `assessment-nmap-${Date.now()}`; await createProject(p, `http://127.0.0.1:${port}/`, true);
  try {
    const job = await startJob(p, projectPath(p), 'assessment-nmap', () => runAssessment(p, 'nmap'));
    const done = await waitJob(p, job.id); assert.equal(done.status, 'completed', done.result?.error);
    const a = (await readAssessment(p, job.id))!; assert.equal(a.status, 'completed');
    assert.ok(a.rows.some(row => row.port === port && row.protocol === 'tcp' && row.address === '127.0.0.1'));
    assert.ok(done.events.some(e => e.level === 'command' && e.message.includes('-sT')));
    const fail = await startJob(p, projectPath(p), 'assessment-nmap', () => runAssessment(p, 'nmap', undefined, 1));
    const stopped = await waitJob(p, fail.id); assert.equal(stopped.status, 'failed'); assert.equal(stopped.result.status, 'timeout');
    const b = (await readAssessment(p, fail.id))!; assert.equal(b.status, 'timeout'); assert.deepEqual(b.rows, []); assert.notEqual(b.id, a.id);
    assert.equal((await readAssessment(p, a.id))!.rows.length, a.rows.length);
    await evidence('nmap.json',{ passed: true, report: a, timeout: b, events: done.events });
  } finally { server.closeAllConnections(); server.close(); await fs.rm(projectPath(p), { recursive: true, force: true }); }
});
test('assessment logs mask credential patterns and query parameters', () => {
  assert.ok(!scrub('token=secret-value\nhttps://site/a?other=private').includes('secret-value'));
  assert.ok(!scrub('https://site/a?other=private').includes('=private'));
});
test('WhatWeb rejects empty and malformed results', () => {
  assert.throws(() => parseWhatWeb('[]', 'http://localhost/'));
  assert.throws(() => parseWhatWeb('{bad', 'http://localhost/'));
});
test('real WhatWeb: fingerprints match raw output, failure, timeout and fresh runs', { timeout: 45000 }, async () => {
  let fingerprints = true;
  const server = http.createServer((_q,s) => { if (fingerprints) { s.setHeader('Server','nginx/1.24.0'); s.setHeader('X-Powered-By','PHP/8.2.1'); } s.end('<title>Authorized training</title>'); });
  await new Promise<void>(r => server.listen(0,'127.0.0.1',r));
  const p = `assessment-whatweb-${Date.now()}`; await createProject(p, `http://127.0.0.1:${(server.address() as any).port}/`, true);
  try {
    const a = await runAssessment(p,'whatweb'); assert.equal(a.success,true,a.error);
    const first = (await readAssessment(p,a.id))!, raw = JSON.parse(await fs.readFile(path.join(path.dirname(a.outputFile),'whatweb.json'),'utf8'));
    assert.ok(first.rows.some(r => r.name === 'nginx' && r.version === '1.24.0')); assert.deepEqual(raw[0].plugins.PHP.version,['8.2.1']);
    fingerprints = false; const b = await runAssessment(p,'whatweb'), second = (await readAssessment(p,b.id))!;
    assert.equal(b.success,true,b.error); assert.notEqual(a.id,b.id); assert.ok(!second.rows.some(r => r.name === 'PHP' || r.name === 'nginx'));
    const timed = await runAssessment(p,'whatweb',undefined,1); assert.equal(timed.status,'timeout'); assert.deepEqual((await readAssessment(p,timed.id))!.rows,[]);
    server.closeAllConnections(); await new Promise<void>(r => server.close(() => r()));
    const fail = await runAssessment(p,'whatweb'); assert.equal(fail.success,false); assert.equal(fail.status,'failed'); assert.deepEqual((await readAssessment(p,fail.id))!.rows,[]);
    await evidence('whatweb.json',{ first, second, timed, fail });
  } finally { server.closeAllConnections(); server.close(); await fs.rm(projectPath(p),{ recursive:true,force:true }); }
});
test('TLS, ZAP and Nuclei parsers require valid completed output', () => {
  assert.throws(() => parseTestssl('[]'));
  assert.throws(() => parseTestssl('[{"id":"scanProblem","severity":"FATAL","finding":"failed"}]'));
  assert.throws(() => parseZap('{"site":[]}','http://localhost/'));
  assert.throws(() => parseNuclei('', '', 'http://localhost/'));
  assert.deepEqual(parseNuclei('', '{"requests":2,"templates":1,"errors":0}', 'http://localhost/'),[]);
});
test('real Nuclei: upstream template evidence, clean rescan, failure and timeout', { timeout: 60000 }, async () => {
  const tmp = await fs.mkdtemp(path.join(os.tmpdir(),'arstt-template-test-')), previous = process.env.HUNTERKIT_TEMPLATES;
  await fs.mkdir(path.join(tmp,'http/exposed-panels'),{recursive:true});
  await fs.copyFile('.tools/nuclei-templates/http/exposed-panels/phpmyadmin-panel.yaml',path.join(tmp,'http/exposed-panels/phpmyadmin-panel.yaml'));
  process.env.HUNTERKIT_TEMPLATES = tmp;
  const fixture = await fixtureServer(), p = `assessment-nuclei-${Date.now()}`; await createProject(p,fixture.base+'/lab/',true);
  try {
    const a = await runAssessment(p,'nuclei',undefined,undefined,'panels'), first = (await readAssessment(p,a.id))!;
    assert.equal(a.success,true,a.error); assert.ok(first.rows.some(r => r.title.includes('phpMyAdmin') && r.severity === 'info'));
    fixture.state.vulnerable = false; const b = await runAssessment(p,'nuclei',undefined,undefined,'panels'); assert.equal(b.success,true,b.error); assert.deepEqual((await readAssessment(p,b.id))!.rows,[]);
    const timeout = await runAssessment(p,'nuclei',undefined,1,'panels'); assert.equal(timeout.status,'timeout');
    await fixture.close(); const fail = await runAssessment(p,'nuclei',undefined,undefined,'panels'); assert.equal(fail.success,false); assert.deepEqual((await readAssessment(p,fail.id))!.rows,[]);
    await evidence('nuclei-acceptance.json',{ first, clean:await readAssessment(p,b.id), timeout, fail });
  } finally { await fixture.close(); if (previous === undefined) delete process.env.HUNTERKIT_TEMPLATES; else process.env.HUNTERKIT_TEMPLATES=previous; await fs.rm(tmp,{recursive:true,force:true}); await fs.rm(projectPath(p),{recursive:true,force:true}); }
});
test('real native ZAP: passive report, closed target and process deadline', { timeout: 180000 }, async () => {
  assert.ok(process.env.ARSTT_ZAP,'Set ARSTT_ZAP to the verified official native zap.sh for this acceptance test.');
  const fixture = await fixtureServer(), p = `assessment-zap-${Date.now()}`; await createProject(p,fixture.base+'/lab/',true);
  try {
    const a = await runAssessment(p,'zap'), first = (await readAssessment(p,a.id))!; assert.equal(a.success,true,a.error);
    assert.ok(first.rows.length > 0); assert.ok(first.rows.every(r => ['info','low','medium','high'].includes(r.severity)));
    const timeout = await runAssessment(p,'zap',undefined,1000); assert.equal(timeout.status,'timeout');
    await fixture.close(); const fail = await runAssessment(p,'zap'); assert.equal(fail.success,false); assert.deepEqual((await readAssessment(p,fail.id))!.rows,[]);
    await evidence('zap-acceptance.json',{ first, timeout, fail });
  } finally { await fixture.close(); await fs.rm(projectPath(p),{recursive:true,force:true}); }
});

test('real Nmap zero resolved hosts is failure despite exit success', async()=>{
 const p=`nmap-unresolved-${Date.now()}`;await createProject(p,'http://arstt-does-not-exist.invalid/',true);
 try{const result=await runAssessment(p,'nmap');assert.equal(result.status,'failed');assert.match(result.error||'',/resolved host/);assert.deepEqual((await readAssessment(p,result.id))!.rows,[]);}
 finally{await fs.rm(projectPath(p),{recursive:true,force:true});}
});
test('assessment process cancellation and global two-process limit', {timeout:15000}, async()=>{
  const server=http.createServer((_q,_s)=>{});await new Promise<void>(r=>server.listen(0,'127.0.0.1',r));
  const p=`assessment-control-${Date.now()}`;await createProject(p,`http://127.0.0.1:${(server.address() as any).port}/`,true);
  try{
    const started=await startJob(p,projectPath(p),'assessment-whatweb',()=>runAssessment(p,'whatweb'));
    for(let i=0;i<100;i++){const j=await getJob(projectPath(p),started.id);if(j?.events.some(e=>e.level==='command'&&e.message.includes('--log-json=')))break;await new Promise(r=>setTimeout(r,20));}
    await cancelJob(started.id);
    for(let i=0;i<100;i++){if((await getJob(projectPath(p),started.id))?.result)break;await new Promise(r=>setTimeout(r,20));}
    assert.equal((await readAssessment(p,started.id))!.status,'cancelled');assert.equal((await getJob(projectPath(p),started.id))!.status,'cancelled');
    const a=runAssessment(p,'whatweb',undefined,1000),b=runAssessment(p,'whatweb',undefined,1000);await new Promise(r=>setTimeout(r,100));
    const third=await runAssessment(p,'nmap');assert.equal(third.status,'failed');assert.match(third.error||'',/already active/);
    assert.equal((await a).status,'timeout');assert.equal((await b).status,'timeout');
  }finally{server.closeAllConnections();server.close();await fs.rm(projectPath(p),{recursive:true,force:true});}
});

test('output permission failure retains job target and error without a phantom output file',async()=>{
 if(process.platform==='win32')return;
 const p=`assessment-permissions-${Date.now()}`;await createProject(p,'http://127.0.0.1:9/',true);const dir=path.join(projectPath(p),'security','runs');await fs.mkdir(dir,{recursive:true});await fs.chmod(dir,0o500);
 try{const j=await startJob(p,projectPath(p),'assessment-whatweb',()=>runAssessment(p,'whatweb'));const done=await waitJob(p,j.id);assert.equal(done.status,'failed');assert.equal(done.result.target,'http://127.0.0.1:9/');assert.equal(done.result.outputFile,undefined);assert.match(done.result.error,/permission|EACCES/i);}
 finally{await fs.chmod(dir,0o700);await fs.rm(projectPath(p),{recursive:true,force:true});}
});

import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import net from 'node:net';
import { spawn } from 'node:child_process';
import { chromium } from 'playwright-core';
import { fixtureServer } from './fixture.js';
import { ROOT, projectPath } from '../backend/src/core.js';

test('HTTP API and production React interface use the real scan pipeline', { timeout: 120000 }, async t => {
  const fixture = await fixtureServer();
  const templates = await fs.mkdtemp(path.join(os.tmpdir(), 'hunterkit-api-templates-'));
  const rel = 'http/exposed-panels/phpmyadmin-panel.yaml';
  await fs.mkdir(path.dirname(path.join(templates, rel)), { recursive: true });
  await fs.copyFile(path.join(ROOT, '.tools/nuclei-templates', rel), path.join(templates, rel));
  const portServer = net.createServer();
  await new Promise<void>(resolve => portServer.listen(0, '127.0.0.1', resolve));
  const port = (portServer.address() as any).port;
  await new Promise<void>(resolve => portServer.close(() => resolve()));
  const server = spawn(process.execPath, ['--import', 'tsx', 'backend/src/server.ts'], {
    cwd: ROOT, env: { ...process.env, PORT: String(port), HUNTERKIT_TEMPLATES: templates }, stdio: ['ignore', 'pipe', 'pipe'],
  });
  let log = ''; server.stdout.on('data', data => { log += data; }); server.stderr.on('data', data => { log += data; });
  const base = `http://127.0.0.1:${port}`;
  const name = `HK-api-${process.pid}`, uiName = `HK-ui-${process.pid}`;
  const ipc = async (channel: string, ...args: any[]) => {
    const response = await fetch(`${base}/api/ipc/${channel}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ args }) });
    return { response, data: await response.json() as any };
  };
  try {
    let healthy = false;
    for (let i = 0; i < 100; i++) {
      try { healthy = (await fetch(`${base}/api/health`)).ok; } catch {}
      if (healthy) break;
      await new Promise(resolve => setTimeout(resolve, 50));
    }
    assert.equal(healthy, true, log);
    await t.test('create-project and exposed-panels return actual JSONL findings through IPC', async () => {
      const created = await ipc('create-project', { projectName: name, domain: fixture.base + '/lab/', authorizationAccepted: true });
      assert.equal(created.data.error, false, JSON.stringify(created.data));
      const scanned = await ipc('exposed-panels', { projectName: name });
      assert.equal(scanned.data.success, true, JSON.stringify(scanned.data)); assert.ok(scanned.data.result > 0);
      const history=await (await fetch(`${base}/api/scans/${encodeURIComponent(name)}`)).json();
      assert.ok(history.some((row:any)=>row.id===scanned.data.id&&row.status==='completed'));
      const report=await (await fetch(`${base}/api/scans/${encodeURIComponent(name)}/${scanned.data.id}`)).json();
      assert.ok(report.rows.some((row:any)=>row.evidence?.['template-id']==='phpmyadmin-panel'));
      assert.equal(report.target,fixture.base+'/lab/');
    });
    await t.test('failed input returns an explicit API error', async () => {
      const bad = await ipc('create-project', { projectName: '../escape', domain: fixture.base, authorizationAccepted: true });
      assert.equal(bad.response.status, 500); assert.match(bad.data.error, /Invalid project name/);
      const traversal = await ipc('api-call', { projectName: name, location: '../.env', type: 'text/plain' });
      assert.equal(traversal.response.status, 500); assert.match(traversal.data.error, /Invalid path/);
    });
    const frontendBuilt = await fs.access(path.join(ROOT, 'frontend/dist/index.html')).then(() => true, () => false);
    await t.test('browser creates a project with a full lab URL, runs Panels, and renders results', { skip: !process.env.HUNTERKIT_TEST_BROWSER || !frontendBuilt }, async () => {
      const browser = await chromium.launch({ executablePath: process.env.HUNTERKIT_TEST_BROWSER, headless: true, chromiumSandbox: false, env: { ...process.env, XDG_CONFIG_HOME: path.join(ROOT, '.runtime/config'), XDG_CACHE_HOME: path.join(ROOT, '.runtime/cache') } });
      try {
        const page = await browser.newPage();
        const errors: string[] = []; page.on('pageerror', error => errors.push(error.message));
        await page.goto(`${base}/projects`);
        await page.getByRole('button', { name: 'Create', exact: true }).click();
        await page.getByLabel('Project Name', { exact: true }).fill(uiName);
        await page.getByLabel('Target hostname or URL', { exact: true }).fill(fixture.base + '/lab/');
        await page.getByLabel('Authorization acknowledgement', { exact: true }).check();
        await page.getByRole('dialog').getByRole('button', { name: 'Create', exact: true }).click();
        await page.waitForURL(`**/${uiName}/dashboard`);
        await page.goto(`${base}/${uiName}/security?tool=nuclei`);
        await page.getByLabel('Profile',{exact:true}).selectOption('panels');
        await page.getByRole('button',{name:'Scan',exact:true}).click();
        await page.getByRole('cell',{name:'phpMyAdmin Panel - Detect',exact:true}).waitFor({timeout:30000});
        assert.match(await page.getByRole('status').innerText(),/COMPLETED/);
        await page.getByRole('link',{name:'Scan history and saved results'}).click();
        await page.getByRole('heading',{name:'Saved scans (1)'}).waitFor();
        await page.locator('tbody a').first().click();
        await page.getByRole('heading',{name:/Selected run/}).waitFor();
        await page.getByRole('cell',{name:'phpMyAdmin Panel - Detect',exact:true}).waitFor();
        await page.goto(`${base}/${uiName}/jsleaks`);
        await page.getByRole('button',{name:'Scan',exact:true}).click();
        await page.getByRole('heading',{name:'Potential secrets (1)',exact:true}).waitFor({timeout:30000});
        assert.match(await page.locator('body').innerText(),/api\/demo/);
        assert.deepEqual(errors, []);
      } finally { await browser.close(); }
    });
  } finally {
    if (server.exitCode === null && server.signalCode === null) { server.kill(); await new Promise<void>(resolve => server.once('close', () => resolve())); }
    await fixture.close();
    for (const project of [name, uiName]) await fs.rm(projectPath(project), { recursive: true, force: true });
    await fs.rm(templates, { recursive: true, force: true });
  }
});

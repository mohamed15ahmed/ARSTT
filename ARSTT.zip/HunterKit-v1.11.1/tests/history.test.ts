import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import http from 'node:http';
import { createProject, projectPath } from '../backend/src/core.js';
import { startJob, getJob } from '../backend/src/job-engine.js';
import { runAssessment } from '../backend/src/assessment.js';
import { scanHistory, scanDetail, scanSummary } from '../backend/src/scan-history.js';
import { reportData, csvReport, pdfReport } from '../backend/src/reports.js';

test('history: real distinct targets/runs, failed and timeout statuses, original records and accurate totals', {timeout:40000}, async()=>{
  const srv=http.createServer((q,s)=>{if(q.url==='/failure'){q.socket.destroy();return;}s.setHeader('Server',q.url==='/one'?'nginx/1.24.0':'Apache/2.4.63');s.end('Authorized training');});
  await new Promise<void>(r=>srv.listen(0,'127.0.0.1',r));const origin=`http://127.0.0.1:${(srv.address() as any).port}`,p=`history-${Date.now()}`;
  await createProject(p,origin+'/',true);
  try{
    const ids:string[]=[];
    async function run(target:string,tool:'whatweb'|'nmap'='whatweb',budget?:number){const j=await startJob(p,projectPath(p),`assessment-${tool}`,()=>runAssessment(p,tool,origin+target,budget));ids.push(j.id);for(let i=0;i<200;i++){const r=await getJob(projectPath(p),j.id);if(r&&!['queued','running'].includes(r.status))return;await new Promise(r=>setTimeout(r,100));}throw Error('deadline');}
    await run('/one');await run('/two');await run('/failure');await run('/','nmap',1);await run('/two');
    const history=await scanHistory(p);assert.equal(history.length,5);assert.equal(new Set(history.map(r=>r.id)).size,5);
    const first=await scanDetail(p,ids[0]),second=await scanDetail(p,ids[1]);assert.ok(first!.rows.some(r=>r.name==='nginx'));assert.ok(!second!.rows.some(r=>r.name==='nginx'));
    const failed=await scanDetail(p,ids[2]);assert.equal(failed!.status,'failed');assert.deepEqual(failed!.rows,[]);
    assert.equal((await scanDetail(p,ids[3]))!.status,'timeout');assert.equal((await scanDetail(p,ids[4]))!.status,'completed');
    const summary=await scanSummary(p);assert.equal(summary.total,5);assert.equal(summary.counts.completed,3);assert.equal(summary.counts.failed,1);assert.equal(summary.counts.timeout,1);
    assert.equal(await scanDetail(p,'missing-job-id'),null);
    const exported=await reportData(p);assert.equal(exported.scans.length,5);assert.equal(exported.academicAI.trained,false);assert.equal(exported.academicAI.metrics,null);
    assert.equal(exported.scans.filter(s=>s.status==='failed').length,1);assert.equal(exported.scans.filter(s=>s.status==='timeout').length,1);
    const csv=await csvReport(p);assert.match(csv,/jobId,scanStatus,finishedAt/);assert.match(csv,/"failed"/);assert.match(csv,/"timeout"/);
    const pdf=await pdfReport(p);assert.equal(pdf.subarray(0,8).toString(),'%PDF-1.4');assert.match(pdf.toString(),/Status: failed/);
    if(process.env.ARSTT_TEST_EVIDENCE){const out=process.env.ARSTT_TEST_EVIDENCE;await fs.writeFile(out+'/export.json',JSON.stringify(exported,null,2));await fs.writeFile(out+'/export.csv',csv);await fs.writeFile(out+'/export.pdf',pdf);}
    if(process.env.ARSTT_TEST_EVIDENCE)await fs.writeFile(process.env.ARSTT_TEST_EVIDENCE+'/history.json',JSON.stringify({history,summary},null,2));
  }finally{srv.closeAllConnections();srv.close();await fs.rm(projectPath(p),{recursive:true,force:true});}
});

test('a legacy skipped job is not presented as a completed scan',async()=>{
  const p=`history-skipped-${Date.now()}`;await createProject(p,'http://127.0.0.1:9/',true);
  try{const j=await startJob(p,projectPath(p),'potential-xss',async()=>({success:true,skipped:true,message:'No eligible parameter inputs; no active test ran.'}));for(let i=0;i<100;i++){if((await getJob(projectPath(p),j.id))?.finishedAt)break;await new Promise(r=>setTimeout(r,10));}
    assert.equal((await scanHistory(p))[0].status,'skipped');assert.equal((await scanDetail(p,j.id))!.status,'skipped');assert.equal((await scanSummary(p)).counts.completed,undefined);
  }finally{await fs.rm(projectPath(p),{recursive:true,force:true});}
});

import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { createProject, projectPath } from '../backend/src/core.js';
import { scanJsLeaks, readJsReport, validateJsTarget } from '../backend/src/js-leaks.js';
import { startJob, cancelJob, getJob } from '../backend/src/job-engine.js';

async function fixture() {
  const state = { clean: false, delay: 0, hits: [] as string[] };
  // Intentionally invalid training marker; never a real credential.
  const marker = 'AKIA' + '0'.repeat(16);
  const server = http.createServer((req, res) => {
    const url = req.url || '/'; state.hits.push(url);
    const send = () => {
      if (url === '/missing') { res.writeHead(404); res.end(); return; }
      if (url === '/redirect') { res.writeHead(302, { Location: 'http://127.0.0.1:9/offscope' }); res.end(); return; }
      if (url === '/partial') { res.setHeader('Content-Type', 'text/html'); res.end('<script src="/a.js"></script><script src="/missing"></script>'); return; }
      if (url === '/variants') { res.setHeader('Content-Type', 'text/html'); res.end('<script src="/a.js?v=one"></script><script src="/a.js?v=two"></script>'); return; }
      if (new URL(url, 'http://fixture').pathname.endsWith('.js')) { res.setHeader('Content-Type', 'application/javascript'); res.end(state.clean ? '/* no findings */' : `const marker = "${marker}";\nconst a="/api/demo";const b="/api/demo";\nfetch('/must-not-execute');\n${url === '/a.js' ? 'import "./b.js";' : ''}`); return; }
      res.setHeader('Content-Type', 'text/html'); res.end(state.clean ? '<p>Clean fixture</p>' : '<script src="/a.js"></script><script src="/a.js"></script>');
    };
    if (state.delay) setTimeout(send, state.delay); else send();
  });
  await new Promise<void>(r => server.listen(0, '127.0.0.1', r));
  const target = `http://127.0.0.1:${(server.address() as any).port}/`;
  const name = `JS-acceptance-${crypto.randomUUID()}`; await createProject(name, target, true);
  return { name, target, state, marker, async close() { server.closeAllConnections(); await new Promise<void>(r => server.close(() => r())); await fs.rm(projectPath(name), { recursive: true, force: true }); } };
}

test('JavaScript Leaks: real pinned scanner, provenance, redaction, deduplication, and fresh runs', async () => {
  const f = await fixture();
  try {
    const first = await scanJsLeaks(f.name, f.target);
    assert.equal(first.report.status, 'completed', first.error || '');
    assert.equal(first.report.counts.javascript, 2);
    const secret = first.report.findings.filter(x => x.type === 'secret-candidate');
    assert.equal(secret.length, 1); assert.equal(secret[0].sources.length, 2);
    assert.equal(secret[0].verification, 'unverified'); assert.equal(first.report.counts.verified, 0);
    assert.ok(secret[0].sources.every(x => x.kind === 'javascript' && x.line === 1));
    const endpoint = first.report.findings.filter(x => x.value === f.target + 'api/demo');
    assert.equal(endpoint.length, 1); assert.equal(endpoint[0].sources.length, 2);
    assert.equal(f.state.hits.filter(x => x === '/a.js').length, 1);
    assert.ok(!f.state.hits.includes('/api/demo')); assert.ok(!f.state.hits.includes('/must-not-execute'));
    const firstFile = path.join(projectPath(f.name), 'js-leaks', 'runs', first.report.id + '.json');
    assert.ok(!(await fs.readFile(firstFile, 'utf8')).includes(f.marker));
    f.state.clean = true;
    const clean = await scanJsLeaks(f.name, f.target);
    assert.equal(clean.report.status, 'completed'); assert.deepEqual(clean.report.findings, []);
    assert.notEqual(clean.report.id, first.report.id);
    assert.equal((await readJsReport(f.name))?.id, clean.report.id);
    assert.equal((await readJsReport(f.name, first.report.id))?.findings.length, first.report.findings.length);
    assert.deepEqual((await fs.readdir(projectPath(f.name))).sort(), ['details.json', 'js-leaks', 'logs']);
  } finally { await f.close(); }
});

test('JS Leaks rejects unsupported, credential-bearing, oversized, unauthorized and out-of-scope targets', async () => {
  const f = await fixture();
  try {
    for (const bad of ['', 'ftp://127.0.0.1/', 'javascript:alert(1)', 'http://user:pass@127.0.0.1/', 'http://outside.invalid/', f.target + 'x'.repeat(2048), f.target + '\nwrong']) await assert.rejects(validateJsTarget(f.name, bad));
    assert.equal(f.state.hits.length, 0);
    const file = path.join(projectPath(f.name), 'details.json'); const details = JSON.parse(await fs.readFile(file, 'utf8')); details.authorizationAccepted = false; await fs.writeFile(file, JSON.stringify(details));
    await assert.rejects(validateJsTarget(f.name, f.target), /authorization/);
  } finally { await f.close(); }
});

test('polling during fast scan completion does not misreport a backend restart', async () => {
  const f = await fixture(); f.state.clean = true;
  try {
    let done = false;
    const scan = scanJsLeaks(f.name, f.target).finally(() => { done = true; });
    while (!done) {
      const reports = await Promise.all(Array.from({ length: 12 }, () => readJsReport(f.name)));
      assert.ok(reports.every(r => r?.phase !== 'interrupted'));
      await new Promise(r => setTimeout(r, 1));
    }
    assert.equal((await scan).report.status, 'completed');
    assert.equal((await readJsReport(f.name))?.status, 'completed');
  } finally { await f.close(); }
});

test('query values stay redacted without merging distinct source URLs', async () => {
  const f = await fixture();
  try {
    const r = await scanJsLeaks(f.name, f.target + 'variants');
    const candidate = r.report.findings.find(x => x.type === 'secret-candidate')!;
    assert.equal(r.report.status, 'completed'); assert.equal(candidate.sources.length, 2);
    assert.notEqual(candidate.sources[0].id, candidate.sources[1].id);
    assert.ok(candidate.sources.every(s => !/v=one|v=two/.test(s.url)));
    const query = await scanJsLeaks(f.name, f.target + '?token=' + f.marker);
    assert.ok(!JSON.stringify(query.report).includes(f.marker));
  } finally { await f.close(); }
});

test('network failure, HTTP errors and out-of-scope redirects never become successful clean scans', async () => {
  const f = await fixture();
  try {
    for (const suffix of ['missing', 'redirect']) {
      const result = await scanJsLeaks(f.name, f.target + suffix);
      assert.equal(result.success, false); assert.equal(result.report.status, 'failed'); assert.deepEqual(result.report.findings, []);
    }
    const unused = http.createServer(); await new Promise<void>(r => unused.listen(0, '127.0.0.1', r)); const port = (unused.address() as any).port; await new Promise<void>(r => unused.close(() => r()));
    const name = `JS-offline-${crypto.randomUUID()}`; const url = `http://127.0.0.1:${port}/`;
    await createProject(name, url, true);
    try { const r = await scanJsLeaks(name, url); assert.equal(r.success, false); assert.equal(r.report.status, 'failed'); }
    finally { await fs.rm(projectPath(name), { recursive: true, force: true }); }
  } finally { await f.close(); }
});

test('request/overall timeouts and body limits are explicit; partial coverage stays partial', async () => {
  const f = await fixture();
  try {
    f.state.delay = 200;
    const request = await scanJsLeaks(f.name, f.target, { requestTimeoutMs: 30 });
    assert.equal(request.success, false); assert.match(request.error || '', /timed out/);
    const overall = await scanJsLeaks(f.name, f.target, { timeoutMs: 30 });
    assert.equal(overall.report.phase, 'timeout'); assert.equal(overall.report.status, 'failed');
    f.state.delay = 0;
    const limit = await scanJsLeaks(f.name, f.target, { documentBytes: 10 }); assert.equal(limit.success, false);
    const partial = await scanJsLeaks(f.name, f.target + 'partial');
    assert.equal(partial.report.status, 'partial'); assert.equal(partial.partial, true); assert.ok(partial.report.warnings.some(x => /HTTP 404/.test(x)));
    const capped = await scanJsLeaks(f.name, f.target, { documents: 1 }); assert.equal(capped.report.status, 'partial');
  } finally { await f.close(); }
});

test('real nonzero/missing/malformed/timed-out child processes are failures, never zero-result success', async () => {
  const f = await fixture();
  try {
    const malformed = `let input='';process.stdin.on('data',x=>input+=x);process.stdin.on('end',async()=>{await Promise.all(input.trim().split('\\n').map(u=>new Promise((resolve,reject)=>require('http').get(u,r=>{r.resume();r.on('end',resolve)}).on('error',reject))));console.log('unexpected output')});`;
    for (const engine of [{ command: process.execPath, prefix: ['-e', 'process.exit(1)', '--'] }, { command: '/definitely-not-a-jsleak-binary', prefix: [] }, { command: process.execPath, prefix: ['-e', malformed, '--'] }]) {
      const r = await scanJsLeaks(f.name, f.target, {}, engine);
      assert.equal(r.success, false); assert.equal(r.report.status, 'failed'); assert.deepEqual(r.report.findings, []);
    }
    const timeout = await scanJsLeaks(f.name, f.target, { timeoutMs: 100 }, { command: process.execPath, prefix: ['-e', 'setTimeout(()=>{},60000)', '--'] });
    assert.equal(timeout.report.status, 'failed'); assert.equal(timeout.report.phase, 'timeout');
  } finally { await f.close(); }
});

test('job logs and saved reports contain no full candidate; cancellation and duplicate isolation work', async () => {
  const f = await fixture();
  try {
    const dir = projectPath(f.name);
    const job = await startJob(f.name, dir, 'js-leaks-scan', () => scanJsLeaks(f.name, f.target));
    for (let i = 0; i < 100; i++) { const current = await getJob(dir, job.id); if (current?.finishedAt) break; await new Promise(r => setTimeout(r, 20)); }
    assert.equal((await getJob(dir, job.id))?.status, 'completed');
    for (const filename of await fs.readdir(path.join(dir, 'logs', 'jobs'))) assert.ok(!(await fs.readFile(path.join(dir, 'logs', 'jobs', filename), 'utf8')).includes(f.marker));
    f.state.delay = 300;
    const cancelled = await startJob(f.name, dir, 'js-leaks-scan', () => scanJsLeaks(f.name, f.target));
    await new Promise(r => setTimeout(r, 40));
    await assert.rejects(scanJsLeaks(f.name, f.target), /already running/);
    assert.equal(await cancelJob(cancelled.id), true);
    for (let i = 0; i < 100; i++) { const r = await readJsReport(f.name, cancelled.id); if (r?.status === 'cancelled') break; await new Promise(r => setTimeout(r, 20)); }
    assert.equal((await readJsReport(f.name, cancelled.id))?.status, 'cancelled');
  } finally { await f.close(); }
});

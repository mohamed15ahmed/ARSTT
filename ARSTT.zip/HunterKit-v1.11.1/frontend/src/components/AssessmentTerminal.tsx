import { useEffect, useRef, useState } from 'react';
import { Button } from './ui/button';

// Uses the existing Job API and SSE stream. Never starts a process or accepts commands.
export default function AssessmentTerminal({ project, jobId }: { project: string; jobId: string }) {
  const [job, setJob] = useState<any>(), [events, setEvents] = useState<any[]>([]), [connection, setConnection] = useState('Connecting');
  const token = useRef(0);
  useEffect(() => {
    const ticket = ++token.current, messages = new Map<number, any>(); let stopped = false;
    setJob(undefined); setEvents([]); setConnection('Connecting');
    const url = `/api/jobs/${encodeURIComponent(jobId)}?project=${encodeURIComponent(project)}`;
    const add = (rows: any[]) => { if (ticket !== token.current) return; rows.forEach(e => { if (Number.isInteger(e.seq)) messages.set(e.seq,e); }); setEvents([...messages.values()].sort((a,b) => a.seq-b.seq).slice(-500)); };
    const refresh = async () => {
      try { const response = await fetch(url,{signal:AbortSignal.timeout(10000)}); if (!response.ok) throw new Error('Job unavailable'); const next = await response.json();
        if (ticket !== token.current || next.id !== jobId) return; setJob((previous:any)=>previous?.id===next.id&&!['queued','running'].includes(previous.status)&&['queued','running'].includes(next.status)?previous:next); add(next.events || []);
        if (!['queued','running'].includes(next.status)) { stopped = true; source.close(); setConnection('Saved job'); }
      } catch { if (ticket === token.current) setConnection('Connection interrupted; reconnecting to this job'); }
    };
    const source = new EventSource(`/api/jobs/${encodeURIComponent(jobId)}/events?project=${encodeURIComponent(project)}`);
    source.addEventListener('snapshot', e => { const next = JSON.parse((e as MessageEvent).data); if (next.id !== jobId || ticket !== token.current) return; add(next.events || []); setConnection('Live'); void refresh(); });
    source.addEventListener('log', e => add([JSON.parse((e as MessageEvent).data)]));
    source.addEventListener('status', () => { void refresh(); });
    source.addEventListener('done', () => { void refresh(); });
    source.onerror = () => { if (!stopped && ticket === token.current) { setConnection('Connection interrupted; reconnecting to this job'); void refresh(); } };
    void refresh(); const interval = setInterval(() => { void refresh(); },3000);
    return () => { token.current++; stopped = true; clearInterval(interval); source.close(); };
  }, [project,jobId]);
  const status = job?.result?.skipped ? 'skipped' : job?.result?.status || job?.status || 'queued';
  return <details className="rounded border"><summary className="cursor-pointer p-3 text-sm text-primary">Live Terminal · {status.toUpperCase()}</summary><div className="p-3 pt-0 space-y-3">
    <div className="text-xs text-muted-foreground break-all">Job {jobId} · {job?.channel || 'Loading tool'} · {connection}<br />{job?.startedAt || job?.createdAt}{job?.finishedAt ? ` → ${job.finishedAt}` : ''}</div>
    <pre role="log" aria-label="Actual job output" className="bg-muted rounded p-3 max-h-80 overflow-auto whitespace-pre-wrap break-all text-xs font-mono">{events.length ? events.map(e => `${e.timestamp} [${e.level}] ${e.message}`).join('\n') : 'No output has been received from this job.'}</pre>
    {['queued','running'].includes(job?.status) && <Button variant="outline" size="sm" onClick={async () => { const response = await fetch(`/api/jobs/${encodeURIComponent(jobId)}?project=${encodeURIComponent(project)}`,{method:'DELETE'}); if (!response.ok) setConnection('Cancellation request failed; checking status'); }}>Cancel scan</Button>}
    <p className="text-xs text-muted-foreground">Displays this job’s real execution events; reconnecting does not start another scan. Last 500 saved messages are shown.</p>
  </div></details>;
}

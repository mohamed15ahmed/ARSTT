import AssessmentTerminal from './AssessmentTerminal';
import { useSearchParams } from 'react-router-dom';
import { FormEvent, useEffect, useRef, useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';

export const assessmentOptions = [{ id: 'nmap', title: 'Nmap', description: 'Bounded TCP connect and version-light inventory. An open port does not prove a vulnerability.' }, { id: 'whatweb', title: 'WhatWeb', description: 'Technology fingerprints returned by WhatWeb at aggression level 1. Unreported versions remain unknown.' }, { id: 'testssl', title: 'testssl.sh', description: 'Certificate, protocol and TLS checks. Tool severity and positive checks remain separate; each job has independent output.' }, { id: 'zap', title: 'OWASP ZAP', description: 'Bounded spider and passive web assessment. No active scan is performed.' }, { id: 'nuclei', title: 'Nuclei', description: 'Selected HTTP template matches. Findings require review and preserve tool severity and references.' }];
export default function AssessmentScan({ project }: { project: string }) {
  const [params,setParams]=useSearchParams(); const selectedTool=params.get('tool'); const tool=assessmentOptions.some(o=>o.id===selectedTool)?selectedTool!:'nmap';
  const [profile, setProfile] = useState('general'), [target, setTarget] = useState(''), [scope, setScope] = useState<any>();
  const [report, setReport] = useState<any>(null), [error, setError] = useState(''), [busy, setBusy] = useState(false), [jobId, setJobId] = useState('');
  const generation = useRef(0);
  const base = `/api/assessments/${encodeURIComponent(project)}`;
  useEffect(() => { const ticket = ++generation.current; setReport(null); setScope(null); setError(''); setBusy(false); setJobId('');
    window.electron.ipcRenderer.invoke('get-project-details', project).then(d => { if (ticket === generation.current) { setScope(d); setTarget(d.targetUrl || `http://${d.domain}/`); } }).catch(() => {if(ticket===generation.current)setError('Could not load project scope.');});
    return () => { generation.current++; };
  }, [project]);
  const poll = async (id: string, ticket: number) => {
    const deadline=Date.now()+650000;
    while (ticket === generation.current) {
      const response = await fetch(`${base}/runs/${encodeURIComponent(id)}`, { signal: AbortSignal.timeout(10000) });
      if (response.ok) { const next = await response.json(); if (ticket !== generation.current) return; setReport(next); if (next.status !== 'running') { setBusy(false); return; } }
      else if (response.status === 404) {
        const saved=await fetch(`/api/jobs/${encodeURIComponent(id)}?project=${encodeURIComponent(project)}`,{signal:AbortSignal.timeout(10000)});
        if(saved.ok){const job=await saved.json();if(!['queued','running'].includes(job.status))throw new Error(job.error||job.result?.error||'The job ended without an available report. Results could not be verified.');}
      } else throw new Error('Status unavailable. Reload to reconnect to the saved job.');
      if(Date.now()>deadline)throw new Error('Status connection deadline reached. Reload to reconnect to this saved job.');
      await new Promise(r => setTimeout(r, 750));
    }
  };
  const scan = async (e: FormEvent) => {
    e.preventDefault(); if (busy) return; setError(''); let ticket=generation.current;
    try {
      const raw = target.trim(); if (!raw || raw.length > 2048 || /[\x00-\x20\x7f\\]/.test(raw)) throw new Error('Enter a valid HTTP(S) target.');
      const url = new URL(/^https?:\/\//i.test(raw) ? raw : `http://${raw}`), root = new URL(scope.targetUrl || `http://${scope.domain}`);
      if (!['http:','https:'].includes(url.protocol) || url.username || url.password || !scope.authorizationAccepted || (url.hostname !== root.hostname && (root.hostname === 'localhost' || root.hostname.includes(':') || /^\d+\.\d+\.\d+\.\d+$/.test(root.hostname) || !url.hostname.endsWith(`.${root.hostname}`))) || (scope.explicitScheme && url.origin !== root.origin) || (root.port && url.port !== root.port)) throw new Error('Use a target within the authorized project scope, without credentials.');
      ticket = ++generation.current; setReport(null); setJobId(''); setBusy(true);
      const response = await fetch(`${base}/scans`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ tool, profile, target: url.toString() }), signal: AbortSignal.timeout(15000) });
      const job = await response.json(); if (!response.ok) throw new Error(job.error || 'Scan could not start.');
      if (ticket !== generation.current) return; setJobId(job.id); await poll(job.id, ticket);
    } catch (e: any) { if(ticket===generation.current){setError(e.message || 'Scan failed.'); setBusy(false);} }
  };
  useEffect(() => {
    if (!scope) return; const ticket = generation.current;
    (async () => { try {
      const r=await fetch(`/api/scans/${encodeURIComponent(project)}`,{signal:AbortSignal.timeout(10000)}); if(!r.ok) return;
      const saved=(await r.json()).find((j:any)=>j.source==='assessment' && j.tool===tool);
      if(!saved || ticket!==generation.current) return;
      setJobId(saved.hasJob ? saved.id : '');
      if(['running','queued'].includes(saved.status)){setBusy(true);await poll(saved.id,ticket);}
      else {const response=await fetch(`${base}/runs/${encodeURIComponent(saved.id)}`,{signal:AbortSignal.timeout(10000)});if(response.ok){const next=await response.json();if(ticket===generation.current)setReport(next);}}
    } catch { if(ticket===generation.current){setError('Could not reconnect to the saved scan.');setBusy(false);} } })();
  }, [project,scope,tool]);
  const option = assessmentOptions.find(x => x.id === tool)!;
  return <Card><CardHeader><CardTitle>Assessment</CardTitle><CardDescription>{option.description}</CardDescription></CardHeader><CardContent className="space-y-4">
    <form onSubmit={scan} className="flex flex-col xl:flex-row gap-3 xl:items-end">
      {assessmentOptions.length > 1 && <div><Label htmlFor="assessment-tool">Tool</Label><select id="assessment-tool" value={tool} onChange={e => { generation.current++; setParams({tool:e.target.value}); setReport(null); setJobId(''); setError(''); }} disabled={busy} className="flex h-10 w-full rounded-md border border-input bg-background px-3 mt-2">{assessmentOptions.map(o => <option key={o.id} value={o.id}>{o.title}</option>)}</select></div>}
      {tool === 'nuclei' && <div><Label htmlFor="assessment-profile">Profile</Label><select id="assessment-profile" className="flex h-10 w-full rounded-md border border-input bg-background px-3 mt-2" value={profile} onChange={e => setProfile(e.target.value)} disabled={busy}>{Object.entries({general:'General',panels:'Panels',exposures:'Exposures',defaults:'Default login signatures',takeovers:'Takeover signatures',cves:'Known CVEs',lfi:'LFI (query URL)',sqli:'SQLi (query URL)'}).map(([id,label]) => <option key={id} value={id}>{label}</option>)}</select></div>}
      <div className="flex-1 min-w-0"><Label htmlFor="assessment-target">Target</Label><Input id="assessment-target" className="mt-2" value={target} onChange={e => setTarget(e.target.value)} disabled={busy || !scope} maxLength={2048} required /></div>
      <Button type="submit" disabled={busy || !scope}>{busy ? 'Scanning…' : 'Scan'}</Button>
    </form>
    <div role="status" aria-live="polite" className="rounded border bg-muted p-3 text-sm space-y-1"><b>{error ? 'ERROR' : report?.status.toUpperCase() || (busy ? 'QUEUED' : 'READY')}</b>{jobId && <p className="break-all">Job {jobId}</p>}{report && <><p className="break-all">{report.tool} · {report.target}</p><p>{report.startedAt}{report.finishedAt ? ` → ${report.finishedAt}` : ''}</p></>}{(error || report?.error) && <p role="alert" className="text-destructive">{error || report.error}</p>}</div>
    {jobId && <AssessmentTerminal project={project} jobId={jobId} />}
    {report?.status === 'completed' && <AssessmentRows report={report} />}
    {report?.warnings?.map((w: string) => <p key={w} className="text-sm text-muted-foreground">{w}</p>)}
    {report && <details><summary className="cursor-pointer text-primary text-sm">Execution details</summary><pre className="whitespace-pre-wrap break-all text-xs mt-3">{report.command || 'Command unavailable'}{'\n'}{report.artifacts?.join(', ')}</pre><div className="flex flex-wrap gap-3 text-xs mt-2">{report.artifacts?.map((name:string)=><a key={name} className="text-primary underline" download href={`/project-files/${encodeURIComponent(project)}/security/runs/${encodeURIComponent(report.id)}/${encodeURIComponent(name)}`}>{name} (redacted output)</a>)}</div></details>}
  </CardContent></Card>;
}
export function AssessmentRows({ report }: { report: any }) {
  const rows = report.rows || [];
  const columns = ({nmap:['address','port','protocol','service','product','version'],whatweb:['name','version','source'],testssl:['category','severity','finding','source'],zap:['title','severity','source','verification'],nuclei:['title','severity','source','verification'],JSLeak:['type','rule','value','source','verification']} as Record<string,string[]>)[report.tool] || Object.keys(rows[0] || {}).filter(k => !['id','raw','references','evidence'].includes(k)).slice(0,5);
  return <div className="overflow-x-auto"><table className="w-full text-left text-sm"><thead className="bg-muted border-b"><tr>{columns.map(k => <th key={k} className="p-3 capitalize">{k}</th>)}<th className="p-3">Details</th></tr></thead><tbody>{rows.map((row: any, i: number) => <tr key={row.id || i} className="border-b align-top">{columns.map(k => <td key={k} className="p-3 max-w-xs break-words">{row[k] === undefined ? 'Unknown' : typeof row[k] === 'object' ? JSON.stringify(row[k]) : String(row[k])}</td>)}<td className="p-3"><details><summary className="cursor-pointer text-primary">Details</summary><pre className="whitespace-pre-wrap break-all text-xs max-w-lg mt-2">{JSON.stringify(row, null, 2)}</pre></details></td></tr>)}</tbody></table>{!rows.length && <p className="py-3 text-muted-foreground text-sm">The tool completed with no records within its selected coverage.</p>}</div>;
}

import { ActivitySquare, Bot, ChevronLeftIcon, FileSearch, LayoutDashboardIcon, PocketKnife, ShieldCheck } from 'lucide-react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Button } from './ui/button';
import { DashboardMenu } from '../types';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from './ui/accordion';
interface SideBarProps { project: string | null; }
const dashboardMenu: DashboardMenu[] = [
  { href: 'dashboard', title: 'Dashboard', icon: <LayoutDashboardIcon className="mr-2 h-4 w-4" /> },
  { href: 'recon', title: 'Recon', icon: <FileSearch className="mr-2 h-4 w-4" /> },
  { href: 'security', title: 'Security Testing', icon: <ShieldCheck className="mr-2 h-4 w-4" /> },
  { href: 'attacks', title: 'Attacks', icon: <PocketKnife className="mr-2 h-4 w-4" /> },
  { href: 'jsleaks', title: 'JavaScript Leaks', icon: <LayoutDashboardIcon className="mr-2 h-4 w-4" /> },
  { href: 'ai', title: 'AI Analysis', icon: <Bot className="mr-2 h-4 w-4" /> },
];
const resultArch: DashboardMenu[] = [
  { href: 'result-recon', title: 'Recon Results', icon: <FileSearch className="mr-2 h-4 w-4" /> },
  { href: 'attack-result', title: 'Attack Results', icon: <PocketKnife className="mr-2 h-4 w-4" /> },
];
export default function SideBar({ project }: SideBarProps) {
  const navigate = useNavigate(); const { pathname } = useLocation();
  return <div className="relative flex h-screen w-full max-w-[19rem] flex-col border-r bg-card p-4 text-foreground shadow-sm">
    <div className="flex items-center gap-3 p-3 mb-2"><Button onClick={() => navigate('/projects')} className="py-1 px-1 w-fit h-fit" variant="outline" size="icon"><ChevronLeftIcon className="h-6 w-6" /></Button><h5 className="text-lg font-semibold truncate flex flex-1 w-0 min-w-0 items-center gap-1" title={`ARSTT · ${project || ''}`}><span className="shrink-0 text-primary">ARSTT</span><span className="truncate text-muted-foreground">· {project}</span></h5></div>
    <nav className="flex min-w-[220px] flex-col gap-1 p-2 text-sm">{dashboardMenu.map(el => <Button key={el.href} disabled={el.Disabled} className={`flex justify-start ${pathname.includes(`/${el.href}`) ? 'bg-secondary text-primary' : ''}`} variant="ghost" onClick={() => navigate(`${el.href}`)}>{el.icon}{el.title}</Button>)}
      <Accordion asChild type="single" collapsible><AccordionItem value="results"><AccordionTrigger className="border-b-0"><div className="flex items-center"><ActivitySquare className="mr-2 h-4 w-4" />Results</div></AccordionTrigger><AccordionContent className="flex flex-col gap-2">{resultArch.map(el => <Button key={el.href} className={`flex justify-start ${pathname.includes(el.href) ? 'bg-secondary text-primary' : ''}`} variant="ghost" onClick={() => navigate(`${el.href}`)}>{el.icon}{el.title}</Button>)}</AccordionContent></AccordionItem></Accordion>
    </nav>
  </div>;
}

/* eslint-disable jsx-a11y/control-has-associated-label */
/* eslint-disable react/self-closing-comp */
/* eslint-disable react/button-has-type */
import { Button } from './ui/button';
import { Link } from 'react-router-dom';

// eslint-disable-next-line import/prefer-default-export
export function Banner() {
  return (
    <div className="relative isolate overflow-hidden">
      <svg
        className="absolute inset-0 z-10 h-full w-full stroke-white/10 [mask-image:radial-gradient(100%_100%_at_top_right,white,transparent)]"
        aria-hidden="true"
      >
        <defs>
          <pattern
            id="983e3e4c-de6d-4c3f-8d64-b9761d1534cc"
            width="200"
            height="200"
            x="50%"
            y="-1"
            patternUnits="userSpaceOnUse"
          >
            <path d="M.5 200V.5H200" fill="none" />
          </pattern>
        </defs>
        <svg x="50%" y="-1" className="overflow-visible fill-primary/5">
          <path
            d="M-200 0h201v201h-201Z M600 0h201v201h-201Z M-400 600h201v201h-201Z M200 800h201v201h-201Z"
            strokeWidth="0"
          />
        </svg>
        <rect
          width="100%"
          height="100%"
          strokeWidth="0"
          fill="url(#983e3e4c-de6d-4c3f-8d64-b9761d1534cc)"
        />
      </svg>
      <div className="relative z-30">
        <div className="mt-24 lg:mt-0 lg:min-h-screen relative flex items-center flex-col justify-center py-12 px-6 lg:px-8 sm:mx-auto sm:w-full md:max-w-4xl">
          <div className="text-center bg-card rounded-lg p-12 py-16 border border-border shadow-sm mt-6 md:mt-8 backdrop-blur-sm">
            <h2 className="text-center inline-block text-3xl md:text-5xl tracking-tight leading-8 md:leading-10 font-bold lg:text-6xl text-foreground">
              Automated Reconnaissance and Security Testing Toolkit (ARSTT)
            </h2>
            <p className="text-center leading-6 my-8 font-medium sm:mx-auto sm:w-full sm:max-w-lg">
              ARSTT brings reconnaissance and security testing together
              in one toolkit.
            </p>
            <div className="flex justify-center gap-10">
              <Button asChild><Link to="/projects">Dashboard</Link></Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

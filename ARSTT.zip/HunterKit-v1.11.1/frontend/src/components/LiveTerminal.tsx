import { useEffect, useMemo, useRef, useState } from 'react';
import { ChevronDown, ChevronUp, Copy, Download, Square, Trash2 } from 'lucide-react';
import { Button } from './ui/button';

type TerminalLine = { seq?: number; timestamp: string; tool: string; level: string; message: string; jobId?: string };
type Props = { projectName: string; className?: string };
const finalStatuses = new Set(['completed','failed','cancelled','partial']);

export default function LiveTerminal({ projectName, className = '' }: Props) {
  const [expanded, setExpanded] = useState(true);
  const [lines, setLines] = useState<TerminalLine[]>([]);
  const [jobId, setJobId] = useState('');
  const [status, setStatus] = useState('idle');
  const [channel, setChannel] = useState('');
  const bottom = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let live = true;
    fetch(`/api/jobs?project=${encodeURIComponent(projectName)}&limit=1`).then(r => r.ok ? r.json() : []).then((jobs: any[]) => {
      if (!live || !jobs?.[0]) return;
      const job = jobs[0]; setJobId(job.id); setStatus(job.status); setChannel(job.channel);
      setLines((job.events || []).map((event: any) => ({ ...event, jobId: job.id })));
    }).catch(() => undefined);
    const listener = (raw: Event) => {
      const detail = (raw as CustomEvent).detail || {};
      if (detail.projectName !== projectName) return;
      if (detail.type === 'start') { setJobId(detail.jobId); setStatus(detail.status || 'queued'); setChannel(detail.channel || ''); setExpanded(true); }
      if (detail.type === 'snapshot') {
        setJobId(detail.jobId); setStatus(detail.status || 'running'); setChannel(detail.channel || channel);
        if (Array.isArray(detail.events)) setLines(detail.events.map((event: any) => ({ ...event, jobId: detail.jobId })));
      }
      if (detail.type === 'log' && detail.event) setLines(prev => [...prev, { ...detail.event, jobId: detail.jobId }].slice(-2000));
      if (detail.type === 'status' || detail.type === 'done') setStatus(detail.status || status);
    };
    window.addEventListener('hunterkit-terminal', listener as EventListener);
    return () => { live = false; window.removeEventListener('hunterkit-terminal', listener as EventListener); };
  }, [projectName]);

  useEffect(() => { if (expanded) bottom.current?.scrollIntoView({ behavior: 'smooth' }); }, [lines.length, expanded]);
  const text = useMemo(() => lines.map(line => `[${new Date(line.timestamp).toLocaleTimeString()}] [${line.tool}] [${line.level.toUpperCase()}] ${line.message}`).join('\n'), [lines]);
  const counts = useMemo(() => ({ results: lines.filter(x => x.level === 'result').length, errors: lines.filter(x => x.level === 'error').length }), [lines]);
  const stop = async () => { if (!jobId || finalStatuses.has(status)) return; await fetch(`/api/jobs/${encodeURIComponent(jobId)}?project=${encodeURIComponent(projectName)}`, { method: 'DELETE' }); };
  const download = () => {
    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' }); const href = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = href; a.download = `${projectName}-${channel || 'hunterkit'}-${jobId || 'log'}.log`; a.click(); URL.revokeObjectURL(href);
  };

  return (
    <section className={`rounded-xl border bg-[#090d16] text-slate-100 overflow-hidden ${className}`}>
      <header className="flex flex-wrap items-center justify-between gap-2 px-4 py-3 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <button onClick={() => setExpanded(x => !x)} className="flex items-center gap-2 font-mono text-sm font-semibold">
            {expanded ? <ChevronDown size={16} /> : <ChevronUp size={16} />} Live Terminal
          </button>
          <span className="text-xs rounded bg-slate-800 px-2 py-1 uppercase">{status}</span>
          {channel && <span className="text-xs text-slate-400 font-mono">{channel}</span>}
        </div>
        <div className="flex flex-wrap gap-2">
          <Button size="sm" variant="outline" onClick={() => setLines([])}><Trash2 className="h-4 w-4 mr-1" />Clear</Button>
          <Button size="sm" variant="outline" onClick={() => navigator.clipboard.writeText(text)} disabled={!text}><Copy className="h-4 w-4 mr-1" />Copy</Button>
          <Button size="sm" variant="outline" onClick={download} disabled={!text}><Download className="h-4 w-4 mr-1" />Download Log</Button>
          <Button size="sm" variant="destructive" onClick={stop} disabled={!jobId || finalStatuses.has(status)}><Square className="h-4 w-4 mr-1" />Stop Scan</Button>
        </div>
      </header>
      {expanded && <>
        <div className="h-72 overflow-auto p-4 font-mono text-xs leading-5">
          {lines.length === 0 ? <p className="text-slate-500">Run a scan to see real backend output here. Saved job logs are restored after reconnect.</p> : lines.map((line, index) => (
            <div key={`${line.seq || index}-${index}`} className={line.level === 'error' ? 'text-red-300' : line.level === 'warn' ? 'text-amber-300' : line.level === 'result' ? 'text-emerald-300' : line.level === 'command' ? 'text-cyan-300' : 'text-slate-300'}>
              <span className="text-slate-500">[{new Date(line.timestamp).toLocaleTimeString()}]</span> <span className="text-slate-400">[{line.tool}]</span> {line.message}
            </div>
          ))}
          <div ref={bottom} />
        </div>
        <footer className="px-4 py-2 border-t border-slate-800 text-xs text-slate-400 flex gap-4">
          <span>{lines.length} log line(s)</span><span>{counts.results} result event(s)</span><span>{counts.errors} error(s)</span><span>Job: {jobId || '-'}</span>
        </footer>
      </>}
    </section>
  );
}

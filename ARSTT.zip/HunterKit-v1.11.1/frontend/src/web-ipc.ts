const ACTION_CHANNELS = new Set([
  'subfinder-process', 'recon-all', 'httpx-live-domain', 'httpx-screens',
  'waybackurls-archive', 'waybackurls-js', 'waybackurls-parameter',
  'find-secrets', 'extra-links', 'general-scan', 'exposed-panels',
  'default-credentials', 'exposures', 'lfi', 'potential-xss', 'multi-scans',
  'subdomain-takeovers', 'vulns-cves', 'security-nmap', 'security-testssl',
  'security-zap', 'security-whatweb', 'attack-sqlmap', 'attack-wapiti',
  'ai-analyze-project',
]);

function firstArg(args: any[]) { return Array.isArray(args?.[0]) ? args?.[0]?.[0] : args?.[0]; }
function emitTerminal(type: string, detail: any) { window.dispatchEvent(new CustomEvent('hunterkit-terminal', { detail: { type, ...detail } })); }

async function runJob(channel: string, args: any[]) {
  const a = firstArg(args) || {}; const projectName = String(a.projectName || '');
  const started = await fetch('/api/jobs', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ channel, args }) });
  const payload = await started.json();
  if (!started.ok) throw new Error(payload?.error || `Could not start job (${started.status})`);
  const jobId = payload.id as string;
  emitTerminal('start', { jobId, channel, projectName, status: payload.status });

  return new Promise<any>((resolve, reject) => {
    const source = new EventSource(`/api/jobs/${encodeURIComponent(jobId)}/events?project=${encodeURIComponent(projectName)}`);
    let finished = false;
    const close = () => { if (!finished) finished = true; source.close(); };
    source.addEventListener('snapshot', (ev: MessageEvent) => {
      const data = JSON.parse(ev.data); emitTerminal('snapshot', { jobId, channel, projectName, ...data });
    });
    source.addEventListener('log', (ev: MessageEvent) => {
      const data = JSON.parse(ev.data); emitTerminal('log', { jobId, channel, projectName, event: data });
    });
    source.addEventListener('status', (ev: MessageEvent) => {
      const data = JSON.parse(ev.data); emitTerminal('status', { jobId, channel, projectName, ...data });
    });
    source.addEventListener('done', (ev: MessageEvent) => {
      const data = JSON.parse(ev.data); close(); emitTerminal('done', { jobId, channel, projectName, ...data });
      const result = data.result || { success: data.status === 'completed', message: `Job ${data.status}`, error: data.error || null };
      resolve(result);
    });
    source.onerror = async () => {
      if (finished) return;
      source.close();
      // SSE can be interrupted by proxies; fall back to bounded polling without losing the saved job log.
      try {
        for (let i = 0; i < 900; i++) {
          await new Promise(r => window.setTimeout(r, 1000));
          const r = await fetch(`/api/jobs/${encodeURIComponent(jobId)}?project=${encodeURIComponent(projectName)}`);
          if (!r.ok) continue;
          const job = await r.json(); emitTerminal('snapshot', { jobId, channel, projectName, ...job });
          if (['completed','failed','cancelled','partial'].includes(job.status)) {
            finished = true; emitTerminal('done', { jobId, channel, projectName, status: job.status, result: job.result, error: job.error });
            resolve(job.result || { success: job.status === 'completed', message: `Job ${job.status}`, error: job.error || null }); return;
          }
        }
        reject(new Error('Job status connection was lost. The job log is still saved on the backend.'));
      } catch (e) { reject(e); }
    };
  });
}

const invoke = async (channel: string, ...args: any[]) => {
  if (channel === 'open-link') {
    const url = args?.[0]?.url;
    if (url) window.open(url.startsWith('http') ? url : `https://${url}`, '_blank', 'noopener,noreferrer');
    return true;
  }
  if (ACTION_CHANNELS.has(channel)) {
    try {
      const result = await runJob(channel, args);
      if (result?.success === false) window.alert(`${result?.message || 'Tool execution failed'}${result?.error ? `\n\n${result.error}` : ''}`);
      return result;
    } catch (error: any) {
      const message = error?.message || String(error); window.alert(`Tool request failed\n\n${message}`);
      return { success: false, message: 'Tool request failed', error: message };
    }
  }

  const controller = new AbortController();
  const requestTimeout = channel === 'fetch-data' ? 60_000 : 25_000;
  const requestTimer = window.setTimeout(() => controller.abort(), requestTimeout);
  try {
    const response = await fetch(`/api/ipc/${encodeURIComponent(channel)}`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ args }), signal: controller.signal,
    });
    const text = await response.text(); let payload: any;
    try { payload = text ? JSON.parse(text) : null; } catch { payload = text; }
    if (!response.ok) throw new Error(payload?.error || payload?.message || `Request failed (${response.status})`);
    return payload;
  } finally { window.clearTimeout(requestTimer); }
};

(window as any).electron = { ipcRenderer: { invoke, sendMessage: () => undefined, on: () => () => undefined, once: () => undefined } };

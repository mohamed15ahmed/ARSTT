import { useParams } from 'react-router-dom';
import AssessmentScan from '../../components/AssessmentScan';
export default function SecurityTesting() {
  const { projectSlug = '' } = useParams();
  return <div className="flex flex-col gap-6"><div><h1 className="font-bold text-3xl">Web Security Assessment</h1><p className="text-sm text-muted-foreground mt-2">Web and TLS assessments, technology fingerprints, and Nmap network inventory. Choose one tool; each scan keeps independent status and evidence.</p></div><AssessmentScan project={projectSlug} /><a className="text-sm text-primary underline" href={`/${encodeURIComponent(projectSlug)}/attack-result`}>Scan history and saved results</a></div>;
}

/* eslint-disable react/jsx-props-no-spreading */
import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { AlertTriangle, Loader2 } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { ProjectDetails } from '../../types';
import PotentialXss from './attacks/potentialXss';

export default function Attacks() {
  const [details, setDetails] = useState<ProjectDetails>(); const [diagnostics, setDiagnostics] = useState<any>({}); const [running, setRunning] = useState(''); const [history, setHistory] = useState<any[]>([]);
  const { projectSlug = '' } = useParams();
  const refresh = async () => {
    const [res, diag, jobs] = await Promise.all([
      window.electron.ipcRenderer.invoke('get-project-details', projectSlug),
      window.electron.ipcRenderer.invoke('security-tool-diagnostics'),
      fetch(`/api/jobs?project=${encodeURIComponent(projectSlug)}&limit=30`).then(r => r.ok ? r.json() : []),
    ]);
    setDetails(res); setDiagnostics(diag || {}); setHistory(Array.isArray(jobs) ? jobs : []);
  };
  useEffect(() => { refresh(); }, [projectSlug]);
  const run = async (channel: string) => { setRunning(channel); try { await window.electron.ipcRenderer.invoke(channel, { projectName: projectSlug }); } finally { setRunning(''); await refresh(); } };
  const activeDisabled = details?.authorizationAccepted !== true;

  return <div className="flex flex-col gap-6">
    <div><h1 className="font-bold text-3xl">Attacks / Penetration Testing</h1><p className="text-sm text-muted-foreground mt-2">Active checks are separate from Security Testing. They are bounded, evidence-based, and only run for projects whose authorization acknowledgement is stored.</p></div>
    {activeDisabled && <div className="rounded-lg border border-amber-500/40 bg-amber-500/10 p-4 text-amber-200 flex gap-3"><AlertTriangle className="shrink-0" /><div><b>Active testing blocked.</b><div className="text-sm">This legacy project does not contain the authorization acknowledgement. Create a new project and confirm you are authorized to test the target.</div></div></div>}

    {details && <>
      <h2 className="font-bold text-2xl">Focused active verification</h2>
      <div className="grid lg:grid-cols-3 gap-4">
        <Card><CardHeader><CardTitle>sqlmap - SQL Injection Detection</CardTitle><CardDescription>Runs only against up to five discovered in-scope parameterized URLs with level 1 / risk 1. No dump, DB enumeration, file access, or takeover options are used.</CardDescription></CardHeader><CardContent className="space-y-3"><div className="text-xs text-muted-foreground">{diagnostics.sqlmap?.ready ? 'READY' : `UNAVAILABLE - ${diagnostics.sqlmap?.detail || 'sqlmap not detected'}`}</div><Button onClick={() => run('attack-sqlmap')} disabled={activeDisabled || running === 'attack-sqlmap' || diagnostics.sqlmap?.ready === false}>{running === 'attack-sqlmap' && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Run bounded SQLi detection</Button></CardContent></Card>
        <Card><CardHeader><CardTitle>Dalfox - XSS Verification</CardTitle><CardDescription>Uses the existing tested Dalfox integration against discovered parameterized URLs and records evidence returned by the scanner.</CardDescription></CardHeader><CardContent><PotentialXss {...details} /></CardContent></Card>
        <Card><CardHeader><CardTitle>Wapiti - Additional Web Testing</CardTitle><CardDescription>Bounded modules for XSS, SQLi, file disclosure, redirects and CRLF with crawl/time/task limits. Candidate findings still require review.</CardDescription></CardHeader><CardContent className="space-y-3"><div className="text-xs text-muted-foreground">{diagnostics.wapiti?.ready ? 'READY' : `UNAVAILABLE - ${diagnostics.wapiti?.detail || 'wapiti not detected'}`}</div><Button onClick={() => run('attack-wapiti')} disabled={activeDisabled || running === 'attack-wapiti' || diagnostics.wapiti?.ready === false}>{running === 'attack-wapiti' && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Run bounded Wapiti profile</Button></CardContent></Card>
      </div>

      <p className="text-sm text-muted-foreground">Nuclei profiles and OWASP ZAP are available in <a className="text-primary underline" href={`/${encodeURIComponent(projectSlug)}/security`}>Web Security Assessment</a>. Existing saved attack results and all routes are retained.</p>
    </>}
    <Card>
      <CardHeader><CardTitle>Test History</CardTitle><CardDescription>Open a saved Job ID for its execution details and live terminal. Failed and incomplete runs are retained.</CardDescription></CardHeader>
      <CardContent className="space-y-2 max-h-72 overflow-auto">
        {history.filter(job => ['attack-sqlmap','attack-wapiti','potential-xss','general-scan','exposed-panels','default-credentials','subdomain-takeovers','exposures','vulns-cves','lfi','multi-scans'].includes(String(job.channel || ''))).map(job => <div key={job.id} className="rounded border p-2 text-sm flex flex-wrap justify-between gap-2"><span><b>{job.channel}</b> <a className="text-xs text-primary underline" href={`/${encodeURIComponent(projectSlug)}/attack-result?job=${encodeURIComponent(job.id)}`}>{job.id}</a></span><span className="uppercase text-xs font-semibold">{job.status}</span><span className="text-xs text-muted-foreground">{job.createdAt}</span></div>)}
        {!history.some(job => ['attack-sqlmap','attack-wapiti','potential-xss','general-scan','exposed-panels','default-credentials','subdomain-takeovers','exposures','vulns-cves','lfi','multi-scans'].includes(String(job.channel || ''))) && <p className="text-sm text-muted-foreground">No saved active-test jobs yet.</p>}
      </CardContent>
    </Card>
  </div>;
}

import { FormEvent, useEffect, useRef, useState } from 'react';
import { useParams } from 'react-router-dom';
import { Loader2, Search } from 'lucide-react';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { Label } from '../../components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card';

type Finding = { id: string; type: 'secret-candidate' | 'endpoint' | 'observation'; rule: string; value: string; verification: string; sources: Array<{ url: string; kind: string; line?: number }> };
type Report = { id: string; target: string; status: string; phase: string; startedAt: string; finishedAt?: string; error?: string; warnings: string[]; findings: Finding[]; counts: { documents: number; javascript: number; candidates: number; verified: number; endpoints: number; observations: number } };
const final = new Set(['completed', 'partial', 'failed', 'cancelled']);

export default function JsLeaks() {
  const { projectSlug = '' } = useParams();
  const [target, setTarget] = useState(''), [scope, setScope] = useState<any>(null);
  const [report, setReport] = useState<Report | null>(null), [error, setError] = useState('');
  const [busy, setBusy] = useState(false), [loading, setLoading] = useState(true);
  const generation = useRef(0);
  const base = `/api/js-leaks/${encodeURIComponent(projectSlug)}`;

  const poll = async (id: string, ticket: number) => {
    const deadline = Date.now() + 200000;
    while (generation.current === ticket) {
      const response = await fetch(`${base}/runs/${encodeURIComponent(id)}`, { signal: AbortSignal.timeout(10000) });
      if (response.ok) {
        const next: Report = await response.json(); if (generation.current !== ticket) return;
        setReport(next); if (final.has(next.status)) { setBusy(false); return; }
      } else if (response.status !== 404) throw new Error('Could not read the current scan status. Reload to reconnect to the saved run.');
      if (Date.now() > deadline) throw new Error('Scan status connection timed out. Reload to check this saved run.');
      await new Promise(r => setTimeout(r, 500));
    }
  };

  useEffect(() => {
    const ticket = ++generation.current;
    setReport(null); setError(''); setBusy(false); setLoading(true); setTarget(''); setScope(null);
    (async () => {
      try {
        const [details, saved] = await Promise.all([
          window.electron.ipcRenderer.invoke('get-project-details', projectSlug),
          fetch(`${base}/latest`, { signal: AbortSignal.timeout(10000) }).then(async r => { if (!r.ok) throw new Error('Could not load the saved JavaScript Leaks run.'); return r.json(); }),
        ]);
        if (generation.current !== ticket) return;
        setScope(details); setTarget(details.targetUrl || `http://${details.domain}/`); setReport(saved);
        if (saved?.status === 'running') { setBusy(true); setLoading(false); await poll(saved.id, ticket); }
      } catch (e: any) { if (generation.current === ticket) { setError(e.message || 'Could not load JavaScript Leaks.'); setBusy(false); } }
      finally { if (generation.current === ticket) setLoading(false); }
    })();
    return () => { generation.current++; };
  }, [projectSlug]);

  const scan = async (event: FormEvent) => {
    event.preventDefault(); if (busy || loading) return;
    setError(''); let url: URL;
    try {
      const raw = target.trim(); if (!raw || raw.length > 2048 || /[\x00-\x20\x7f]/.test(raw)) throw new Error();
      if (/^[a-z][a-z0-9+.-]*:\/\//i.test(raw) && !/^https?:\/\//i.test(raw)) throw new Error();
      url = new URL(/^https?:\/\//i.test(raw) ? raw : `http://${raw}`);
      if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password) throw new Error();
      const root = new URL(scope.targetUrl || `http://${scope.domain}/`);
      const subdomain = root.hostname !== 'localhost' && !root.hostname.includes(':') && !/^\d+\.\d+\.\d+\.\d+$/.test(root.hostname) && url.hostname.endsWith(`.${root.hostname}`);
      if ((url.hostname !== root.hostname && !subdomain) || (scope.explicitScheme && url.origin !== root.origin) || (root.port && url.port !== root.port)) throw new Error();
      if (scope.authorizationAccepted !== true) { setError('This project requires the authorization acknowledgement.'); return; }
    } catch { setError('Enter an HTTP(S) target within this project scope, without embedded credentials (maximum 2048 characters).'); return; }
    const ticket = ++generation.current; setReport(null); setBusy(true);
    try {
      const response = await fetch(`${base}/scans`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ target: url.toString() }), signal: AbortSignal.timeout(15000) });
      const started = await response.json(); if (!response.ok) throw new Error(started.error || 'The scan could not start.');
      if (generation.current !== ticket) return; await poll(started.id, ticket);
    } catch (e: any) { if (generation.current === ticket) { setError(e.message || 'Scan connection failed.'); setBusy(false); } }
  };

  const table = (rows: Finding[], empty: string) => rows.length ? <div className="overflow-x-auto"><table className="w-full text-sm text-left">
    <thead className="border-b bg-muted"><tr><th className="p-3">Type / rule</th><th className="p-3">Result</th><th className="p-3">Source</th><th className="p-3">Details</th></tr></thead>
    <tbody>{rows.map(f => <tr key={f.id} className="border-b align-top">
      <td className="p-3">{f.type === 'secret-candidate' ? 'Potential secret' : f.type === 'endpoint' ? 'Endpoint' : 'Observation'}<div className="text-xs text-muted-foreground">{f.rule}</div></td>
      <td className="p-3 break-all">{f.value}<div className="text-xs text-muted-foreground">{f.verification}</div></td>
      <td className="p-3 break-all max-w-xs">{f.sources[0]?.url}<div className="text-xs text-muted-foreground">{f.sources[0]?.kind}{f.sources[0]?.line ? ` · line ${f.sources[0].line}` : ''}{f.sources.length > 1 ? ` · ${f.sources.length} sources` : ''}</div></td>
      <td className="p-3"><details><summary className="cursor-pointer text-primary">Details</summary><div className="mt-2 max-w-xs break-all text-xs space-y-2"><p>{f.type === 'secret-candidate' ? 'Pattern match only. This credential has not been validated. Full values are not saved or logged.' : 'Observed in source text; the discovered endpoint was not called or verified.'}</p><p>Fingerprint: {f.id}</p>{f.sources.map((s, i) => <p key={i}>{s.url} · {s.kind}{s.line ? ` · line ${s.line}` : ''}</p>)}</div></details></td>
    </tr>)}</tbody>
  </table></div> : <p className="text-sm text-muted-foreground">{empty}</p>;

  return <div className="flex flex-col gap-6">
    <div><h1 className="font-bold text-3xl">JavaScript Leaks</h1><p className="text-sm text-muted-foreground mt-2">Inspect same-origin JavaScript and page text with JSLeak. Scripts are never executed, and credential patterns remain unverified candidates.</p></div>
    <Card><CardHeader><CardTitle>Target</CardTitle><CardDescription>Use an authorized page or JavaScript URL within this project scope. Each scan collects fresh sources.</CardDescription></CardHeader><CardContent>
      <form onSubmit={scan} className="flex flex-col sm:flex-row items-start sm:items-end gap-3"><div className="w-full min-w-0"><Label htmlFor="js-leaks-target">Target URL</Label><Input id="js-leaks-target" value={target} onChange={e => setTarget(e.target.value)} disabled={loading || busy} maxLength={2048} placeholder="https://example.com/app.js" className="mt-2" /></div><Button type="submit" disabled={loading || busy || !scope} className="shrink-0">{busy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Search className="mr-2 h-4 w-4" />}Scan</Button></form>
    </CardContent></Card>
    <div role="status" aria-live="polite" className="rounded-lg border bg-card p-4 text-sm space-y-2">
      <p className="font-semibold">{busy ? report ? `RUNNING · ${report.phase}` : 'STARTING' : loading ? 'LOADING' : error ? 'ERROR' : report?.status.toUpperCase() || 'READY'}</p>
      {report && <><p className="break-all text-muted-foreground">Run {report.id} · {report.target}</p><p className="text-muted-foreground">Started {report.startedAt}{report.finishedAt ? ` · Finished ${report.finishedAt}` : ''}</p><p>{report.counts.documents} documents · {report.counts.javascript} JavaScript files · {report.counts.endpoints} endpoints</p></>}
      {(error || report?.error) && <p role="alert" className="text-destructive">{error || report?.error}</p>}
      {report?.warnings?.length > 0 && <details><summary className="cursor-pointer text-amber-700">Coverage warnings ({report.warnings.length})</summary><ul className="mt-2 space-y-1 text-muted-foreground">{report.warnings.map((w, i) => <li key={i}>{w}</li>)}</ul></details>}
    </div>
    {report && final.has(report.status) && <>
      <Card><CardHeader><CardTitle>Potential secrets ({report.counts.candidates})</CardTitle><CardDescription>Unverified patterns only. No credentials are sent to providers for validation.</CardDescription></CardHeader><CardContent>{table(report.findings.filter(f => f.type === 'secret-candidate'), report.status === 'failed' || report.status === 'cancelled' ? 'This scan did not complete. No clean result is claimed.' : 'No potential secrets were returned within this scan coverage.')}</CardContent></Card>
      <Card><CardHeader><CardTitle>Verified secrets ({report.counts.verified})</CardTitle></CardHeader><CardContent><p className="text-sm text-muted-foreground">None verified. JSLeak pattern matching does not establish that a credential is valid.</p></CardContent></Card>
      <Card><CardHeader><CardTitle>Endpoints and observations</CardTitle></CardHeader><CardContent>{table(report.findings.filter(f => f.type !== 'secret-candidate'), 'No endpoints or observations returned for this run.')}</CardContent></Card>
    </>}
  </div>;
}

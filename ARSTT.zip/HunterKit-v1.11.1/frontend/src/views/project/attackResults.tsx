import { useEffect, useRef, useState } from 'react';
import { useParams, useSearchParams } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { AssessmentRows } from '../../components/AssessmentScan';
import AssessmentTerminal from '../../components/AssessmentTerminal';
export default function AttacksResults() {
  const { projectSlug = '' } = useParams(), [query,setQuery] = useSearchParams();
  const [history,setHistory] = useState<any[]>([]), [detail,setDetail] = useState<any>(), [legacy,setLegacy] = useState<any[]>([]), [error,setError] = useState('');
  const generation = useRef(0), selected = query.get('job') || '';
  const base = `/api/scans/${encodeURIComponent(projectSlug)}`;
  useEffect(() => { let alive=true; setHistory([]); setLegacy([]); setError('');
    const refresh = async () => { try { const r=await fetch(base,{signal:AbortSignal.timeout(10000)}); if(!r.ok) throw new Error('Could not load saved history.'); const rows=await r.json(); if(alive) setHistory(rows); } catch(e:any) { if(alive) setError(e.message); } };
    void refresh(); window.electron.ipcRenderer.invoke('get-attack-result',projectSlug).then(r => { if(alive) setLegacy(r.results || []); }).catch(() => { if(alive) setError('Legacy results could not be read.'); });
    const interval=setInterval(refresh,3000); return () => {alive=false;clearInterval(interval);};
  }, [projectSlug]);
  useEffect(() => { const ticket=++generation.current; setDetail(undefined); setError(''); if(!selected) return;
    const refresh=async()=>{try{const r=await fetch(`${base}/${encodeURIComponent(selected)}`,{signal:AbortSignal.timeout(10000)});if(!r.ok)throw new Error('Selected scan could not be read.');const d=await r.json();if(ticket===generation.current)setDetail(d);}catch(e:any){if(ticket===generation.current)setError(e.message);}};
    void refresh();const interval=setInterval(refresh,3000);return()=>{generation.current++;clearInterval(interval);};
  }, [projectSlug,selected]);
  return <div className="flex flex-col gap-6"><div><h1 className="font-bold text-3xl">Scan History & Results</h1><p className="text-sm text-muted-foreground mt-2">Saved executions, including failed and incomplete scans. Open a Job ID to inspect that run alone.</p></div>
    <p className="text-sm flex gap-4"><a className="text-primary underline" href={`/api/reports/${encodeURIComponent(projectSlug)}.json`}>Export JSON</a><a className="text-primary underline" href={`/api/reports/${encodeURIComponent(projectSlug)}.csv`}>Export CSV</a></p>
    {error && <p role="alert" className="text-destructive">{error}</p>}
    <Card><CardHeader><CardTitle>Saved scans ({history.length})</CardTitle></CardHeader><CardContent className="overflow-x-auto"><table className="w-full text-left text-sm"><thead className="border-b bg-muted"><tr>{['Job ID','Target','Tool','Time','Status','Records'].map(s=><th key={s} className="p-3">{s}</th>)}</tr></thead><tbody>{history.map(r=><tr key={r.id} className="border-b align-top"><td className="p-3"><a className="text-primary underline break-all" href={`?job=${encodeURIComponent(r.id)}`} onClick={e=>{e.preventDefault();setQuery({job:r.id});}}>{r.id}</a></td><td className="p-3 max-w-xs break-all">{r.target || 'Not recorded'}</td><td className="p-3">{r.tool}</td><td className="p-3">{r.startedAt || r.createdAt || 'Not recorded'}</td><td className="p-3 uppercase">{r.status}{r.error && <p className="text-destructive normal-case">{r.error}</p>}</td><td className="p-3">{r.count ?? 'Not recorded'}</td></tr>)}</tbody></table>{!history.length && <p className="text-sm text-muted-foreground py-3">No saved scan executions.</p>}</CardContent></Card>
    {selected && <Card><CardHeader><CardTitle>Selected run · {selected}</CardTitle></CardHeader><CardContent className="space-y-4">{detail ? <><p className="text-sm break-all">{detail.tool} · {detail.target || 'Target not recorded'} · {detail.status.toUpperCase()}<br />{detail.startedAt}{detail.finishedAt ? ` → ${detail.finishedAt}` : ''}</p>{detail.error && <p role="alert" className="text-destructive">{detail.error}</p>}{detail.rows?.length ? <AssessmentRows report={detail} /> : <p className="text-sm text-muted-foreground">{detail.status === 'completed' ? 'This run returned no records within its coverage.' : 'No completed result is claimed for this run.'}</p>}{detail.warnings?.map((w:string)=><p className="text-sm text-muted-foreground" key={w}>{w}</p>)}<details><summary className="cursor-pointer text-primary">Saved report details</summary><pre className="whitespace-pre-wrap break-all text-xs mt-3">{JSON.stringify(detail,null,2)}</pre></details>{history.find(r=>r.id===selected)?.hasJob && <AssessmentTerminal project={projectSlug} jobId={selected} />}</> : <p className="text-sm text-muted-foreground">Loading selected run…</p>}</CardContent></Card>}
    {legacy.length>0 && <details className="rounded border p-4"><summary className="cursor-pointer text-primary">Existing legacy attack findings ({legacy.length})</summary><p className="text-sm text-muted-foreground my-3">Original saved findings are retained. These older files may represent the latest module run rather than a particular Job ID.</p><AssessmentRows report={{tool:'legacy',rows:legacy.map(r=>({title:r.info?.name,severity:r.info?.severity,source:r.url,evidence:r}))}} /></details>}
  </div>;
}

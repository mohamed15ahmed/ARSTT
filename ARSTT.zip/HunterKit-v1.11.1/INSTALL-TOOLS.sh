#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
npm ci
npm run download:tools
npm run setup:templates
npm run check:tools
npm run check:attacks
npm run check:security-tools || true
printf '\nOptional tools may remain unavailable; see SECURITY-TOOLS-WINDOWS.md / README.md.\n'

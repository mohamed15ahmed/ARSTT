@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul || (echo [ERROR] Install Node.js 20.18+ first.& pause & exit /b 1)
echo [1/7] Installing locked npm dependencies...
call npm ci
if errorlevel 1 goto failed
echo [2/7] Installing tested bundled tool binaries and checking SHA-256...
call npm run download:tools
if errorlevel 1 goto failed
echo [3/7] Installing pinned Nuclei templates...
call npm run setup:templates
if errorlevel 1 goto failed
echo [4/7] Checking bundled tools...
call npm run check:tools
if errorlevel 1 goto failed
echo [5/7] Checking attack template profiles...
call npm run check:attacks
if errorlevel 1 goto failed
echo [6/7] Checking optional Security Testing tools...
call npm run check:security-tools
echo [7/7] Installing/configuring Windows Security Testing tools...
call SETUP-SECURITY-TOOLS.cmd
echo.
echo Setup completed. Tools that still show UNAVAILABLE require the dependency stated by the diagnostic.
echo Run START-HUNTERKIT.cmd. Chrome or Edge is needed for screenshots.
pause
exit /b 0
:failed
echo [ERROR] Setup is incomplete. Read the error above; do not treat missing tools as a clean scan.
pause
exit /b 1

# HunterKit v1.11.1 — Windows first run

1. Extract the ZIP to a normal writable folder.
2. Install Node.js 20.18+ and Python 3.
3. For ZAP/testssl Docker mode, install and start Docker Desktop.
4. For WhatWeb, enable WSL (`wsl --install`) and reboot if Windows asks.
5. Run `INSTALL-TOOLS.cmd` once. It now also launches `SETUP-SECURITY-TOOLS.cmd`.
6. Run `START-HUNTERKIT.cmd`.
7. Open `http://127.0.0.1:5173`.
8. In Security Testing, press Refresh. Tools marked READY are actually runnable according to the backend probe.

## How each optional tool runs on Windows

- Nmap: native Windows executable; HunterKit checks Program Files and PATH.
- sqlmap: `.security-venv\\Scripts\\sqlmap.exe` installed by setup.
- Wapiti: `.security-venv\\Scripts\\wapiti.exe` installed by setup.
- OWASP ZAP Baseline: official `ghcr.io/zaproxy/zaproxy:stable` Docker image.
- testssl.sh: WSL if installed there, otherwise official `ghcr.io/testssl/testssl.sh:3.2` Docker image.
- WhatWeb: WSL executable. Setup attempts to install it automatically with apt when possible.

If a card says UNAVAILABLE, do not run the scan yet. The text next to it now describes the actual missing runtime instead of a fake `.exe` name.

@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo ============================================================
echo HunterKit Security Tools Setup - Windows
echo ============================================================
echo.

set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY (
  where python >nul 2>nul && set "PY=python"
)
if not defined PY (
  echo [WARN] Python 3 not found. sqlmap and Wapiti cannot be installed yet.
  echo Install Python 3 and enable "Add Python to PATH", then run this file again.
) else (
  echo [1/5] Creating HunterKit Python environment...
  %PY% -m venv .security-venv
  if errorlevel 1 (
    echo [WARN] Could not create .security-venv. sqlmap/Wapiti setup skipped.
  ) else (
    call .security-venv\Scripts\python.exe -m pip install --upgrade pip
    echo [2/5] Installing sqlmap and Wapiti into HunterKit's private environment...
    call .security-venv\Scripts\python.exe -m pip install --upgrade sqlmap wapiti3
    if errorlevel 1 echo [WARN] Python security tools were not fully installed. Review pip output above.
  )
)

echo [3/5] Checking Nmap...
if exist "%ProgramFiles%\Nmap\nmap.exe" goto nmap_ok
if exist "%ProgramFiles(x86)%\Nmap\nmap.exe" goto nmap_ok
where nmap >nul 2>nul && goto nmap_ok
where winget >nul 2>nul
if errorlevel 1 (
  echo [WARN] Nmap is not installed and winget is unavailable.
  echo Install Nmap + Npcap from the official Nmap installer.
) else (
  echo Nmap not found. Installing through Windows Package Manager...
  winget install --id Insecure.Nmap -e --accept-package-agreements --accept-source-agreements
  if errorlevel 1 echo [WARN] Nmap installation did not complete. Install Nmap manually if needed.
)
:nmap_ok

echo [4/5] Checking Docker Desktop for ZAP and testssl.sh fallback...
where docker >nul 2>nul
if errorlevel 1 (
  echo [INFO] Docker is not installed. ZAP Baseline requires Docker Desktop on Windows.
) else (
  docker version >nul 2>nul
  if errorlevel 1 (
    echo [INFO] Docker command exists but Docker Desktop is not running.
  ) else (
    echo Docker is running. Pulling official scanner images...
    docker pull ghcr.io/zaproxy/zaproxy:stable
    docker pull ghcr.io/testssl/testssl.sh:3.2
  )
)

echo [5/5] Checking WSL integration for WhatWeb and testssl.sh...
where wsl >nul 2>nul
if errorlevel 1 (
  echo [INFO] WSL is not enabled. WhatWeb requires WSL on Windows in this build.
  echo Open PowerShell as Administrator and run: wsl --install
) else (
  wsl -e sh -lc "command -v whatweb >/dev/null" >nul 2>nul
  if errorlevel 1 (
    echo WhatWeb is missing in WSL. Trying automatic install as WSL root...
    wsl -u root -e sh -lc "if command -v apt-get >/dev/null; then apt-get update && DEBIAN_FRONTEND=noninteractive apt-get install -y whatweb; else exit 2; fi"
  )
  wsl -e sh -lc "command -v testssl.sh >/dev/null || command -v testssl >/dev/null" >nul 2>nul
  if errorlevel 1 (
    echo testssl.sh is missing in WSL. Trying automatic install as WSL root...
    wsl -u root -e sh -lc "if command -v apt-get >/dev/null; then apt-get update && DEBIAN_FRONTEND=noninteractive apt-get install -y testssl.sh; else exit 2; fi"
  )
)

echo.
echo ============================================================
echo Re-checking HunterKit tool status...
echo ============================================================
call npm run check:security-tools

echo.
echo Setup finished. READY tools can now be launched from HunterKit.
echo If a tool remains UNAVAILABLE, the diagnostic above tells you exactly what is missing.
pause

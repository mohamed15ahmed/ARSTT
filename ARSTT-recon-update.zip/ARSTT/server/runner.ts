import fs from 'node:fs/promises';
import path from 'node:path';
import {isIP} from 'node:net';
import {Store} from './store.js';
import {execute, DeadlineError, CancelError} from './process.js';
import {executable, templateDir, templateNames} from './tools.js';
import {InputError, scopedTarget, redact} from './safety.js';
import {active, type Job, type Finding, type ToolId} from './types.js';
import {request, reconnaissance, javascriptLeaks} from './web-analysis.js';
import {runRecon,reconTools,NotApplicable} from './recon.js';
import * as parse from './parsers.js';
const budgets:Record<ToolId,number>={subfinder:130000,httpx:45000,screenshots:60000,wayback:90000,'recon-js':45000,parameters:45000,recon:30000,jsleaks:150000,nmap:90000,whatweb:45000,tls:240000,nuclei:120000,zap:240000};
export class Runner {
  private running=0; private queue:string[]=[]; private controllers=new Map<string,AbortController>();
  private idleWaiters:(()=>void)[]=[]; private stopping=false;
  constructor(public store:Store, private options:{maxConcurrent?:number; deadlines?:Partial<Record<ToolId,number>>}={}) {}
  create(projectId:string,tool:ToolId,target:string):Job {
    if(this.stopping) throw new InputError('Server is stopping.',503);
    const p=this.store.project(projectId); if(!p)throw new InputError('Project not found.',404);
    const url=scopedTarget(target,p.origin);
    if(tool==='tls' && url.protocol!=='https:') throw new InputError('TLS assessment requires an https:// target.');
    const jobs=this.store.jobs();
    if(jobs.some(j=>j.projectId===projectId && j.tool===tool && j.target===url.href && active(j.status))) throw new InputError('This scan is already queued or running. Open its existing job.',409);
    if(jobs.filter(j=>active(j.status)).length>=20)throw new InputError('The scan queue is full. Wait for a job to finish.',429);
    const j=this.store.addJob(projectId,tool,url.href); this.store.log(j.id,'status','Queued');this.queue.push(j.id);setImmediate(()=>this.pump());return j;
  }
  cancel(id:string) {
    const j=this.store.job(id);if(!j)throw new InputError('Job not found.',404);if(!active(j.status))return;
    if(j.status==='queued'){this.queue=this.queue.filter(x=>x!==id);this.store.log(id,'status','Cancelled before execution.');this.store.finish(id,'cancelled',[],null,false);this.notifyIdle();}
    else this.controllers.get(id)?.abort(new CancelError());
  }
  private notifyIdle(){if(!this.running && !this.queue.length)for(const done of this.idleWaiters.splice(0))done();}
  async idle(){if(this.running || this.queue.length)await new Promise<void>(r=>this.idleWaiters.push(r));}
  async stop(){this.stopping=true;for(const j of this.store.jobs().filter(j=>active(j.status)))this.cancel(j.id);await this.idle();}
  private pump(){while(this.running<(this.options.maxConcurrent ?? 2)&&this.queue.length){const id=this.queue.shift()!;if(this.store.job(id)?.status!=='queued')continue;this.running++;void this.run(id).finally(()=>{this.running--;this.pump();this.notifyIdle();});}}
  private async run(id:string){
    const job=this.store.job(id)!, target=new URL(job.target), tool=job.tool;
    const controller=new AbortController();this.controllers.set(id,controller);
    const work=path.join(this.store.dir,'work',id), output=path.join(work,'output.json');
    let timedOut=false;
    const budget=this.options.deadlines?.[tool] ?? budgets[tool];
    const timer=setTimeout(()=>{timedOut=true;controller.abort(new DeadlineError());},budget);
    const log=(level:string,message:string)=>this.store.log(id,level,message);
    this.store.begin(id);log('status',`Running ${tool}. Deadline ${budget/1000}s.`);
    try{
      await fs.mkdir(work,{recursive:true,mode:0o700});
      let findings:Finding[]=[],raw='',attachments:string[]=[],partial:string|null=null;
      if((reconTools as readonly string[]).includes(tool)){
        const result=await runRecon(tool,{target,work,signal:controller.signal,log,history:this.store.jobs(job.projectId)});findings=result.findings;raw=result.raw;attachments=result.attachments||[];if(result.coverage==='partial')partial=(result.warnings||[]).join('; ');
      }else if(tool==='recon'||tool==='jsleaks'){
        const result=await (tool==='recon'?reconnaissance:javascriptLeaks)(target,controller.signal,s=>log('progress',s));findings=result.findings;raw=result.raw;if('coverage' in result&&result.coverage==='partial')partial=result.warnings.join('; ');
      }else{
        const exe=await executable(tool);let args:string[]=[];
        const host=target.hostname.replace(/^\[|\]$/g,''),port=target.port || (target.protocol==='https:'?'443':'80');
        if(tool==='nmap')args=['-sT','-sV','--version-light','-Pn','-T3','--max-retries','1','--max-rate','100','--max-parallelism','10','--host-timeout','60s','--stats-every','5s','-p',port,'-oX',output,host];
        else if(tool==='whatweb')args=['--color=never','--aggression=1','--follow-redirect=never','--open-timeout=8','--read-timeout=8',`--log-json=${output}`,target.href];
        else if(tool==='tls')args=['--warnings','batch','--color','0','--connect-timeout','5','--openssl-timeout','5','--ip','one','--jsonfile',output,`${target.hostname}:${port}`];
        else if(tool==='nuclei'){
          // Only an explicitly curated GET/HTTP profile. No arbitrary flags, templates or shell commands from the browser.
          for(const file of templateNames)await fs.access(path.join(templateDir(),file));
          const config=path.join(work,'config','nuclei');await fs.mkdir(config,{recursive:true});
          await fs.copyFile(path.join(templateDir(),'.nuclei-ignore'),path.join(config,'.nuclei-ignore'));
          await request(target,controller.signal);
          args=['-u',target.href,'-jsonl','-o',output,'-nc','-duc','-ni','-dr','-no-stdin','-pt','http','-exclude-tags','dos,fuzz,bruteforce','-timeout','8','-retries','0','-c','2','-bs','2','-rl','20','-stats-json','-si','1','-omit-raw','-omit-template','-redact','authorization,cookie,set-cookie,token,password,api_key,secret'];
          for(const file of templateNames)args.push('-t',path.join(templateDir(),file));
        } else {
          await request(target,controller.signal);
          const escaped=target.origin.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
          const plan={env:{contexts:[{name:'authorized',urls:[target.href],includePaths:[`^${escaped}/.*$`]}],parameters:{failOnError:true,failOnWarning:true,progressToStdout:true}},jobs:[
            {type:'passiveScan-config',parameters:{scanOnlyInScope:true}},
            {type:'spider',parameters:{context:'authorized',url:target.href,maxDuration:1,maxDepth:3,maxChildren:8}},
            {type:'passiveScan-wait',parameters:{maxDuration:2}},
            {type:'report',parameters:{template:'traditional-json',reportDir:work,reportFile:'output.json',reportTitle:'ARSTT passive security assessment'}},
            {type:'exitStatus',parameters:{okExitValue:0,errorExitValue:3,warnExitValue:3}}]};
          const planFile=path.join(work,'plan.json');await fs.writeFile(planFile,JSON.stringify(plan),{mode:0o600});
          args=['-Xmx768m','-cmd','-silent','-dir',path.join(work,'zap-home'),'-autorun',planFile,'-config','connection.timeoutInSecs=8','-config','spider.thread=2'];
        }
        if(tool==='nmap'&&isIP(host)===6)args.unshift('-6');
        log('command',JSON.stringify({executable:exe,args}));
        const proc=await execute(exe,args,{cwd:work,timeout:budget,signal:controller.signal,log,env:{XDG_CONFIG_HOME:path.join(work,'config'),XDG_CACHE_HOME:path.join(work,'cache')}});
        if(tool==='whatweb' && /Net::(?:Read|Open)Timeout/i.test(proc.stderr))throw new Error(`WhatWeb connection/read timed out. ${proc.stderr.slice(-500)}`);
        if(proc.code!==0)throw new Error(`${tool} exited with code ${proc.code}. ${proc.stderr.slice(-1500) || proc.stdout.slice(-1500)}`);
        if(tool==='zap' && (!/Job passiveScan-wait finished|Passive scanning complete/i.test(proc.stdout+proc.stderr)||/Automation plan (?:warnings|failures|errors)/i.test(proc.stdout+proc.stderr)))throw new Error('ZAP did not confirm passive scan completion.');
        const stat=await fs.stat(output);if(stat.size>16*1024*1024)throw new Error('Result file exceeds 16 MiB.');
        raw=await fs.readFile(output,'utf8');
        findings=tool==='nmap'?parse.nmap(raw):tool==='whatweb'?parse.whatweb(raw,target.href):tool==='tls'?parse.tls(raw,target.href):tool==='nuclei'?parse.nuclei(raw,proc.stdout+'\n'+proc.stderr,target.href):parse.zap(raw,target.href);
      }
      if(controller.signal.aborted)throw controller.signal.reason;
      const dedup=new Map<string,Finding>();for(const finding of findings){const safe=JSON.parse(redact(JSON.stringify(finding))) as Finding;const key=JSON.stringify([safe.title,safe.kind,safe.source,safe.evidence]);dedup.set(key,safe);}
      const resultDir=path.join(this.store.dir,'results',id);await fs.mkdir(resultDir,{recursive:true,mode:0o700});
      await fs.writeFile(path.join(resultDir,'raw.txt'),redact(raw),{mode:0o600});
      for(const attachment of attachments){if(attachment!==path.join(work,'screenshot.png'))throw new Error('Unexpected attachment path');await fs.copyFile(attachment,path.join(resultDir,'screenshot.png'));}
      log('status',partial?`Analysis incomplete: ${partial}`:`Tool finished successfully; validated ${dedup.size} observation(s). Tool matches require review.`);
      this.store.finish(id,partial?'partial':'completed',[...dedup.values()],partial,true);
    }catch(error){
      const e=error as Error;const status=e instanceof NotApplicable?'skipped':timedOut || e instanceof DeadlineError || e.name==='TimeoutError' || /Net::(?:Read|Open)Timeout|ReadTimeout|execution expired|timed out|timeout expired/i.test(e.message) ? 'timeout' : controller.signal.aborted ? 'cancelled' : 'failed';
      log(status==='skipped'?'status':'error',`${status}: ${e.message}`);this.store.finish(id,status,[],e.message,false);
    }finally{clearTimeout(timer);this.controllers.delete(id);await fs.rm(work,{recursive:true,force:true}).catch(e=>log('warning',`Cannot remove temporary work files: ${e.message}`));}
  }
}

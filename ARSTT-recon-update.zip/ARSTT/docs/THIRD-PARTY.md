# Third-party software

ARSTT invokes separate upstream tools; it does not rebrand their code as its own.

- Nmap: https://nmap.org/book/man-legal.html — review the current Nmap Public Source License before redistribution.
- WhatWeb: https://github.com/urbanadventurer/WhatWeb — GPL; installed as a Debian package with package license notices.
- testssl.sh: https://github.com/testssl/testssl.sh/tree/v3.2.1 — GPLv2. Its source and LICENSE remain in `.tools/testssl` in the built image; bundled OpenSSL has its own notices.
- Nuclei: https://github.com/projectdiscovery/nuclei/tree/v3.11.1 — MIT; installer retains its upstream license.
- Nuclei templates: https://github.com/projectdiscovery/nuclei-templates/tree/v10.5.0 — retain the upstream license and template authors/signatures in `.tools/templates`.
- OWASP ZAP: https://github.com/zaproxy/zaproxy/releases/tag/v2.17.0 — Apache 2.0 and bundled third-party notices in `.tools/zap/license`.
- React, Vite, TypeScript, lucide-react, fast-xml-parser, tsx and other npm packages retain their respective licenses in node_modules; exact versions are locked in package-lock.json.
- Node.js, Java, Debian, Ruby and Python have their upstream licenses and package notices in the image.

The source ZIP excludes installed tool binaries, npm dependencies and user data. Docker builds download the official archives referenced in `scripts/tools.lock.json` and verify SHA-256 before using them. Source archive digests were checked over HTTPS; Nuclei binary/archive digests were also checked against the existing official release pins. TLS verification is never disabled.

`lab/training-only.key` and `.crt` are an intentionally public development key/certificate pair used solely for the synthetic training server. They are not production credentials and must never be reused for a real service.

Recon port additions: Subfinder (projectdiscovery/subfinder v2.17.0), HTTPX (projectdiscovery/httpx v1.12.0), and waybackurls (tomnomnom/waybackurls v0.1.0) are separate upstream executables with pinned archive/binary SHA-256 in tools.lock.json. Their workflow was adapted from the user's HunterKit-Fixed source, without importing its startup migrations or insecure HTTPS agent. Chromium retains Debian/upstream notices. The seccomp policy is the official Microsoft Playwright Docker profile from v1.56.1; its source URL and SHA-256 are recorded in docs/revision/RECON-PORT.ar.md. Cheerio parses HTML without executing scripts.

# Automated Reconnaissance and Security Testing Toolkit (ARSTT)

> هذه نسخة مرحلة Recon المحدثة. التقرير الحالي: [RECON-RESULT.ar.md](docs/revision/RECON-RESULT.ar.md). DAST النشط وAI المدرّب وPDF والمقارنة ليست مكتملة في هذه المرحلة.

مشروع مستقل بواجهة React/TypeScript وخادم Node.js 24، مع SQLite وسجل Jobs وSSE لمتابعة التنفيذ. المصادر مكتوبة من جديد ولا تعتمد على HunterKit أو إعداداته أو مساراته.

## Windows: ابدأ من هنا

1. ثبّت Docker Desktop، وفعّل WSL2 وLinux containers. خصّص 6 GB RAM على الأقل و10 GB مساحة متاحة. المعمارية المدعومة حاليًا x86_64/amd64.
2. فك ZIP بالكامل في مجلد قابل للكتابة. افتح Docker Desktop وانتظر جاهزيته.
3. شغّل `START-WINDOWS.cmd`، أو نفّذ من PowerShell داخل مجلد المشروع:

```powershell
docker compose --profile training up --build -d
docker compose exec app npm run doctor
docker compose ps
```

البناء الأول يحتاج اتصال إنترنت بـDocker Hub، Debian، npm registry، GitHub وcodeload.github.com. لا تحتاج تثبيت Node أو Ruby أو Java أو أدوات الفحص على Windows؛ تُثبت داخل الصورة مع التحقق من بصمات الأدوات المحملة.

بعد جاهزية الحاوية افتح المتصفح على `http://localhost:4310`. أنشئ مشروعًا باسم Training وTarget `http://lab:8088/`، وأقر بأن هذا الهدف التدريبي مصرح به. جرّب Recon ثم Nmap ثم JavaScript Leaks ثم WhatWeb وNuclei وZAP من Web Assessment.

لـTLS أنشئ مشروعًا ثانيًا بالهدف `https://lab:8443/`، ثم اختر TLS Assessment. شهادة التدريب موقعة ذاتيًا عمدًا؛ ظهور مشاكل الثقة في الشهادة نتيجة حقيقية متوقعة. لا تتوقع نتيجة «آمنة» مصطنعة.

**داخل Docker، لا تستخدم localhost للوصول إلى برنامج على Windows.** استخدم `http://host.docker.internal:PORT/` للبرنامج المصرح به على جهازك، وتأكد من أنه يقبل الاتصال من Docker وأن جدار الحماية يسمح به. استخدم `lab` فقط لخدمة التدريب المرفقة. لا يلزم فتح التطبيق على الشبكة العامة.

## الأدوات والتغطية

| الوظيفة | التنفيذ الفعلي | حدود التغطية الافتراضية |
|---|---|---|
| Reconnaissance | وظائف HunterKit المنقولة مع Jobs الحالية | Subfinder وHTTPX وScreenshots وWayback وJS Resources وParameters، مع DNS/HTTP منفصل |
| Subfinder / Wayback | ملفات تنفيذ أصلية + CDX/Common Crawl | الأهداف المحلية Skipped؛ النطاقات العامة لم تختبر بعد؛ اكتشافها لا يمنح تفويض فحص نشط |
| Screenshots | Chromium/Playwright داخل Docker | sandbox مفعّل، origin محدد وصورة مستقلة لكل Job |
| Nmap | Native Nmap TCP connect + service detection | منفذ URL المحدد، أو 80/443 افتراضيًا؛ لا فحص لشبكة أو نطاق منافذ كامل |
| JavaScript Leaks | تحليل نصي محلي بدون تنفيذ JS | 12 ملفًا من نفس origin، 2 MiB لكل استجابة، inline scripts، مؤشرات وأسماء endpoints |
| WhatWeb | Native Ruby/WhatWeb | aggression 1، دون اتباع redirects |
| TLS | testssl.sh 3.2.1 | JSON مستقل لكل Job، شهادة وبروتوكولات وإعدادات متاحة؛ 240 ثانية كحد أقصى |
| Nuclei | 3.11.1 + upstream signed templates 10.5.0 | profile محدد من 3 قوالب: phpMyAdmin وmissing headers وGit configuration؛ ليس كامل مكتبة CVEs |
| OWASP ZAP | Native ZAP 2.17.0 + Java داخل نفس الحاوية | spider محدود وpassive scanning؛ لا activeScan |

نُقلت وظائف Recon من HunterKit في المراجعة الحالية؛ راجع [تقرير النقل وحدوده](docs/revision/RECON-PORT.ar.md). لا تتضمن النسخة sqlmap أو Dalfox أو Wapiti أو active DAST أو نموذج AI مدربًا حتى الآن. اختبار إصدارات أدوات الاكتشاف العام ليس إثباتًا لنجاح فحص نطاق عام.

## النتائج وحالات التنفيذ

- `queued`: سُجلت العملية وتنتظر أحد مقعدين للتنفيذ. الحد الأقصى للطابور 20.
- `running`: بدأ تنفيذ هذه العملية بالفعل.
- `completed`: انتهى التنفيذ بنجاح وتحقق المحلل من اكتمال المخرج المطلوب وحُفظت النتائج.
- `failed`: فشل بدء الأداة أو الاتصال أو التحليل أو حفظ النتيجة. لا تُعرض نتائج قديمة بدلًا منها.
- `timeout`: انتهت مهلة التنفيذ، أو أبلغت الأداة عن مهلة اتصال/قراءة معروفة.
- `partial`: التغطية غير مكتملة أو استُخدم fallback بعد تعذر الأداة؛ تعرض الأدلة المتاحة والتحذير دون ادعاء اكتمال.
- `skipped`: الوظيفة غير منطبقة على هذا الهدف؛ لم تُنفذ.
- `cancelled`: أُلغي الطلب؛ تُنهى مجموعة العملية وتُحتفظ برسالة الإلغاء.

المنافذ المفتوحة observations وليست إثبات ثغرات. نتائج Nuclei وZAP وtestssl هي تقارير أدوات تحتاج مراجعة. مؤشرات الأسرار غير مؤكدة وقيمها مخفية؛ لا تُجرب بيانات الاعتماد. لا توجد توقعات AI أو أرقام دقة مصطنعة. انظر [الخطة الأكاديمية](docs/ACADEMIC.ar.md).

النتائج والتقارير JSON/CSV مرتبطة بـJob ID. يمكن تنزيل المخرج المنقح من صفحة تفاصيل العملية. لا يوجد تصدير PDF غير مختبر. تُعطَّل صيغ CSV الخطرة وتُنقح أنماط الأسرار الشائعة، لكن لا يُعد ذلك ضمانًا لإخفاء كل نوع أسرار ممكن؛ راجع التقارير قبل مشاركتها.

## التشغيل والإيقاف والتحديث

```powershell
docker compose logs --tail=100 app
docker compose stop
docker compose --profile training up -d
```

البيانات محفوظة في volume باسم `arstt-data`. لا تستخدم `docker compose down -v` إلا إذا أردت حذف بياناتك صراحةً. لا توجد أزرار حذف بيانات في الواجهة.

عند تعديل المصادر: `docker compose up --build -d`. عند تعطل فحص، افتح **Execution log** للعملية نفسها، أو **Tool Readiness** لمراجعة المتطلبات. لا تعامل ظهور الصفحة أو جاهزية executable كدليل على نجاح فحص.

## إعادة الاختبارات

```powershell
docker compose exec app npm test
docker compose exec app npm run test:tools
docker compose exec app npm run test:recon
```

اختبارات الأدوات تستخدم خوادم تدريب محلية داخل الحاوية نفسها، وتشغّل الأدوات الحقيقية، ثم تختبر الفشل والمهلة وعزل النتائج. الاختبار الكامل يشغّل TLS مرتين، وقد يستغرق عدة دقائق. الأدلة JSON تُكتب إلى `/app/artifacts`؛ لنسخها:

```powershell
docker compose cp app:/app/artifacts ./test-artifacts
```

اختبار المتصفح يحتاج Chromium على جهاز Linux المستخدم للاختبار، ويشمل شاشة 320/390/768/1440 والتنقل والتصدير. الحاوية الإنتاجية لا تحتوي Chromium؛ ليست هذه من متطلبات تشغيل أدوات الفحص.

## تطوير محلي على Linux

Node 24+، Python 3، Nmap وWhatWeb وRuby وJava 17+ وOpenSSL وPerl وhexdump مطلوبة. تثبيت أدوات النظام على Debian/Ubuntu متاح في Dockerfile. ثم:

```bash
npm ci
npm run setup:tools
npm run doctor
npm run build
npm start
```

تُقرأ `.env` فقط عند تشغيل Node بخيار `--env-file=.env`؛ الملف `.env.example` مثال اختياري وليس مطلوبًا مع Docker. `npm run dev` يشغّل Vite على5175 والخادم على4311 معًا، مع proxy للـAPI وتحديث ملفات التطوير. لا يتطلب بناء الواجهة مسبقًا. المنفذ4310 يظل للنسخة المبنية/Docker.

هذه خدمة محلية لمستخدم واحد، وليست SaaS متعددة المستخدمين. session cookies وCSRF وقيود origin تحمي واجهة المتصفح المحلية، ولا تُغني عن مصادقة حقيقية وعزل الشبكات إذا قررت نشرها خارجيًا. لا تنشرها على الإنترنت بإعداداتها الحالية.

انظر [البنية وعقود API](docs/ARCHITECTURE.ar.md)، [اختبارات التسليم](docs/VERIFICATION.ar.md)، و[تراخيص الأطراف الثالثة](docs/THIRD-PARTY.md).

## Juice Shop المحلي

خدمة التدريب الجديدة تحت profile training. أنشئ مشروعًا مصرحًا به للهدف `http://juice-shop:3000/` من داخل ARSTT. هذه الخدمة على شبكة تدريب داخلية. لا تستخدم نسخة demo العامة للاختبارات المؤثرة. الاختبارات الحالية على Juice Shop هي Recon والأدوات الحالية ذات التغطية المعلنة؛ active DAST والاختبارات الاستغلالية ليست منجزًا حاليًا.

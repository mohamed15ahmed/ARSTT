# البنية والتتبع

مشروع واحد: UI مبنية تُقدم من خادم Node نفسه، بدون CORS أو اعتماد على منفذ تطوير ثانٍ في التسليم. Docker يشمل الأدوات؛ SQLite والنتائج في volume. لا توجد ملفات HunterKit أو adapters قديمة.

```mermaid
flowchart LR
  UI[React UI] --> API[Local HTTP API + session / CSRF]
  API --> Jobs[Queued jobs / maximum 2 running]
  Jobs --> Native[Fixed native tool commands]
  Jobs --> HTTP[Bounded DNS / HTTP / JS text analysis]
  Native --> Parse[Output validation and redaction]
  HTTP --> Parse
  Parse --> DB[(SQLite + per-job raw output)]
  Jobs --> Logs[SSE logs with sequence numbers]
  Logs --> UI
  DB --> UI
```

## الملفات

| المسار | الوظيفة |
|---|---|
| `server/app.ts` | HTTP routes، session، CSRF، SSE، التقارير، تقديم الواجهة |
| `server/store.ts` | SQLite WAL، مشاريع وJobs وLogs؛ فشل العمليات غير المكتملة بعد restart |
| `server/runner.ts` | طابور واحد وأوامر ثابتة، limits، cancellation، نتائج كل عملية |
| `server/process.ts` | spawn دون shell، إيقاف process group، deadline، output cap |
| `server/tools.ts` | اكتشاف الأدوات وتشغيل فحص الإصدار والتحقق من القوالب |
| `server/parsers.ts` | قراءة مخرجات Nmap/WhatWeb/testssl/Nuclei/ZAP |
| `server/web-analysis.ts` | Recon وJS، دون eval أو تشغيل scripts |
| `server/safety.ts` | input/scope validation، redaction، CSV safety |
| `client/` | Sidebar وHeader ونماذج الفحص والجداول والتفاصيل والسجل |
| `scripts/install-tools.py` | تنزيل رسمي والتحقق من SHA-256 قبل الاستخراج الآمن |
| `scripts/tools.lock.json` | إصدارات وروابط وبصمات الحزم الرسمية |
| `Dockerfile`, `compose.yaml`, `START-WINDOWS.cmd` | تجهيز بيئة Windows/Docker وتشغيلها |
| `lab/` | fixture مصرح به، HTTP/TLS، مؤشرات تدريب وليست أسرارًا حقيقية |
| `tests/` | اختبارات المنطق والعقود والعمليات والأدوات والمتصفح |

## API

- `GET /api/health`: صحة الخادم فقط.
- `GET /api/bootstrap`: إنشاء session محلية وCSRF nonce، ومشاريع وسجل حقيقي.
- `GET /api/tools`: حالة executables والقوالب. `?refresh=1` يعيد الفحص.
- `GET|POST /api/projects`: المشروع يُنشأ بإقرار تفويض وorigin واحد.
- `GET|POST /api/jobs`: عرض السجل أو بدء Job بمعلمات `{projectId,tool,target}`. لا أوامر shell أو flags من العميل.
- `GET /api/jobs/:id`: بيانات العملية وسجلاتها. `?after=SEQ` يمنع إعادة السجلات السابقة.
- `GET /api/jobs/:id/events`: SSE؛ يدعم Last-Event-ID وإعادة الاتصال بنفس ID.
- `DELETE /api/jobs/:id`: إلغاء التنفيذ، دون حذف سجل العملية.
- `GET /api/jobs/:id/raw`: مخرج الأداة المنقح بعد نجاح التحقق فقط.
- `GET /api/jobs/:id/export?format=json|csv`: تقرير مستقل للعملية، بما في ذلك الفشل والمهلة.

الطلبات المغيرة للحالة تحتاج cookie و`x-arstt-csrf`. واجهة التطبيق لا تضيف endpoint عامًا لتشغيل نظام أو تحميل ملفات عشوائية. الوصول المحلي يستخدم localhost/127.0.0.1 فقط.

## التخزين والحدود

`data/arstt.sqlite` يحتفظ بالمشاريع والعمليات والسجلات. `data/results/JOB_ID/raw.txt` يحفظ مخرجًا منقحًا بعد نجاح الأداة والتحقق. مجلد `data/work/JOB_ID` مؤقت ومختلف لكل عملية، ويُنظف بعد الانتهاء. لا يُستخدم ملف output عام مشترك.

مسارات executable المخصصة متغيرات إعداد موثوقة في بيئة المشغّل فقط؛ لا يمكن تمريرها من API. مخارج subprocess حتى8 MiB وملف النتائج حتى16 MiB. HTTP حتى2 MiB و10 ثوانٍ للطلب. Nmap90s، WhatWeb45s، TLS240s، Nuclei120s، ZAP240s. لا تُرفع المهلة بلا سقف. Java heap للفحص768MiB. الحاوية2CPU و3GiB و384PID. حد SQLite والسجل مرتبط بمساحة القرص؛ يلزم نسخ احتياطي ومراقبة المساحة للاستخدام الطويل.

النموذج المحلي يفترض مشغّلًا موثوقًا وتصريحًا حقيقيًا للهدف. ليست هذه حماية SSRF كاملة لخدمة عامة، ولا عزلًا متعدد المستخدمين. تحتاج أي استضافة عامة مصادقة وعزل صلاحيات وشبكات ومراجعة أمنية إضافية.

الواجهة تفصل نتيجة الأداة عن الاستنتاج؛ endpoint في JS مرجع نصي فقط. Nuclei وZAP لا يُوصفان كمكتشفين مؤكدين لكل الثغرات. نتيجة0 تعني أن التغطية المنفذة لم تنتج matches، بعد التحقق من التنفيذ، ولا تعني أمان الهدف كله.

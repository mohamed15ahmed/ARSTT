@echo off
cd /d "%~dp0"
docker info >nul 2>&1
if errorlevel 1 (
  echo Start Docker Desktop and enable the WSL2 Linux engine first.
  pause
  exit /b 1
)
docker compose --profile training up --build -d
if errorlevel 1 (
  echo Setup failed. Read the error above; do not treat this as a successful installation.
  pause
  exit /b 1
)
docker compose exec app npm run doctor
if errorlevel 1 (
  echo One or more tools are unavailable. Check the Tool Readiness page and container logs.
  pause
  exit /b 1
)
start http://localhost:4310
echo ARSTT started. Training origins INSIDE Docker: http://lab:8088 and https://lab:8443
pause

#!/usr/bin/env python3
"""Install official pinned tools. HTTPS and archive SHA-256 are mandatory.
Linux x86_64 only: Windows users run this through the supplied Docker image.
"""
import hashlib, json, os, platform, shutil, stat, tarfile, tempfile, urllib.request, zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
TOOLS=ROOT/'.tools'
LOCK=json.loads((ROOT/'scripts/tools.lock.json').read_text())
if platform.system()!='Linux' or platform.machine() not in ('x86_64','amd64'):
    raise SystemExit('Use Docker Desktop with a Linux amd64 container, or Linux x86_64. Native Windows tool installation is not supported.')
TOOLS.mkdir(exist_ok=True)
(TOOLS/'bin').mkdir(exist_ok=True)
cache=TOOLS/'cache';cache.mkdir(exist_ok=True)
def digest(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for part in iter(lambda:f.read(1024*1024),b''):h.update(part)
    return h.hexdigest()
def download(name,entry):
    dest=cache/(name+'-'+entry['sha256'][:16]+'.archive')
    if dest.exists() and digest(dest)==entry['sha256']:return dest
    temporary=dest.with_suffix('.partial')
    print('Downloading official',name,entry['version'],flush=True)
    req=urllib.request.Request(entry['url'],headers={'User-Agent':'ARSTT-setup/1.0'})
    try:
        with urllib.request.urlopen(req,timeout=120) as response,temporary.open('wb') as output:
            shutil.copyfileobj(response,output)
        if digest(temporary)!=entry['sha256']:raise RuntimeError(name+' archive checksum mismatch; refusing to install')
        temporary.replace(dest)
    finally:
        if temporary.exists():temporary.unlink()
    return dest
def inside(name):
    p=Path(name)
    return not p.is_absolute() and '..' not in p.parts
for name,entry in LOCK.items():
    archive=download(name,entry)
    with tempfile.TemporaryDirectory(prefix='arstt-install-',dir=TOOLS) as temp:
        temp=Path(temp)
        if entry['format']=='zip':
            with zipfile.ZipFile(archive) as z:
                for member in z.infolist():
                    if not inside(member.filename):raise RuntimeError('Unsafe archive member')
                    z.extract(member,temp)
        else:
            with tarfile.open(archive) as t:
                for member in t.getmembers():
                    if not inside(member.name):raise RuntimeError('Unsafe archive member')
                    if member.isdir():
                        (temp/member.name).mkdir(parents=True,exist_ok=True)
                    elif member.isfile():
                        destination=temp/member.name;destination.parent.mkdir(parents=True,exist_ok=True)
                        stream=t.extractfile(member)
                        if stream is None:raise RuntimeError('Missing archive file data')
                        with stream,destination.open('wb') as output:shutil.copyfileobj(stream,output)
                        destination.chmod(member.mode & 0o755)
        if name=='nuclei':
            binary=temp/'nuclei'
            if digest(binary)!=entry['binarySha256']:raise RuntimeError('Nuclei executable checksum mismatch')
            shutil.copyfile(binary,TOOLS/'bin/nuclei');(TOOLS/'bin/nuclei').chmod(0o755)
            for f in temp.iterdir():
                if 'LICENSE' in f.name.upper():
                    licenses=TOOLS/'licenses';licenses.mkdir(exist_ok=True);shutil.copyfile(f,licenses/('nuclei-'+f.name))
        else:
            entries=list(temp.iterdir())
            source=entries[0] if len(entries)==1 and entries[0].is_dir() else temp
            dest=TOOLS/name
            # Only managed tool files are replaced; scan data and source files are untouched.
            if dest.exists():shutil.rmtree(dest)
            shutil.copytree(source,dest)
            if name in ('testssl','zap'):
                script=dest/('testssl.sh' if name=='testssl' else 'zap.sh');script.chmod(script.stat().st_mode|stat.S_IXUSR|stat.S_IXGRP|stat.S_IXOTH)
                wrapper=TOOLS/'bin'/script.name
                wrapper.write_text('#!/bin/sh\nexec "$(dirname "$0")/../'+name+'/'+script.name+'" "$@"\n');wrapper.chmod(0o755)
        print('Verified and installed',name,entry['version'],flush=True)
print('Tools installed. Run npm run doctor to test native dependencies and templates.')

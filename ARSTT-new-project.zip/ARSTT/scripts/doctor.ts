import {toolHealth} from '../server/tools.js';
const health=await toolHealth(true);
for(const tool of health)console.log(`${tool.ready?'READY':'MISSING'} ${tool.name}: ${tool.ready?tool.version:tool.detail}`);
if(health.some(t=>!t.ready))process.exitCode=1;

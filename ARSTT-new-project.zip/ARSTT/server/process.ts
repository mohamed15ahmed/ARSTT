import {spawn} from 'node:child_process';
export class DeadlineError extends Error { constructor() { super('The tool exceeded its execution deadline.'); } }
export class CancelError extends Error { constructor() { super('The scan was cancelled.'); } }
export interface ProcessResult { code: number; stdout: string; stderr: string; }
export function execute(command: string, args: string[], options: {signal: AbortSignal; timeout: number; cwd?: string; env?:Record<string,string>; log?: (level: string, message: string) => void}): Promise<ProcessResult> {
  return new Promise((resolve, reject) => {
    if (options.signal.aborted) return reject(new CancelError());
    const child = spawn(command, args, {shell: false, cwd: options.cwd, detached: process.platform !== 'win32', stdio: ['ignore','pipe','pipe'], env: {...process.env, NO_COLOR:'1', GOMAXPROCS:'2', ...options.env}});
    let out = '', err = '', bytes = 0, failure: Error | undefined, stopped = false;
    let killTimer: ReturnType<typeof setTimeout> | undefined;
    const kill = () => { try { if (child.pid) process.platform === 'win32' ? child.kill('SIGTERM') : process.kill(-child.pid, 'SIGTERM'); } catch {} killTimer = setTimeout(() => { try { if (child.pid) process.platform === 'win32' ? child.kill('SIGKILL') : process.kill(-child.pid, 'SIGKILL'); } catch {} }, 1000); killTimer.unref(); };
    const stop = (error: Error) => { if (stopped) return; stopped = true; failure = error; kill(); };
    const timer = setTimeout(() => stop(new DeadlineError()), options.timeout);
    const abort = () => stop(new CancelError()); options.signal.addEventListener('abort', abort, {once:true});
    const clean = () => { clearTimeout(timer); if (killTimer) clearTimeout(killTimer); options.signal.removeEventListener('abort', abort); };
    let pendingOut = '', pendingErr = '', lines = 0;
    const consume = (kind: 'stdout' | 'stderr', chunk: Buffer) => {
      bytes += chunk.length; if (bytes > 8 * 1024 * 1024) { stop(new Error('Tool output exceeded 8 MiB.')); return; }
      const text = chunk.toString('utf8'); if (kind === 'stdout') { out += text; pendingOut += text; } else { err += text; pendingErr += text; }
      let pending = kind === 'stdout' ? pendingOut : pendingErr;
      const parts = pending.split(/\r?\n|\r/); pending = parts.pop()!;
      for (const line of parts) { if (++lines <= 4000) options.log?.(kind, line); }
      if (kind === 'stdout') pendingOut = pending; else pendingErr = pending;
    };
    child.stdout.on('data', b => consume('stdout', b)); child.stderr.on('data', b => consume('stderr', b));
    child.once('error', error => { clean(); reject(new Error(`Cannot start ${command}: ${error.message}`)); });
    child.once('close', (code, signal) => {
      clean(); if (pendingOut) options.log?.('stdout', pendingOut); if (pendingErr) options.log?.('stderr', pendingErr);
      if (failure) reject(failure); else if (signal) reject(new Error(`Tool stopped by ${signal}.`)); else resolve({code: code ?? -1, stdout: out, stderr: err});
    });
  });
}

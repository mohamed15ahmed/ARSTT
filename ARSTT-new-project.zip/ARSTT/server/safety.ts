import { isIP } from 'node:net';
export class InputError extends Error { constructor(message: string, public code = 400) { super(message); } }
export function targetURL(input: unknown): URL {
  if (typeof input !== 'string' || input.length > 2048 || /[\s\\\x00-\x1f\x7f]/.test(input)) throw new InputError('Enter one HTTP or HTTPS URL without spaces.');
  let url: URL; try { url = new URL(input); } catch { throw new InputError('Use a full URL, for example http://localhost:8080/.'); }
  if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password || url.hash) throw new InputError('Only HTTP(S) URLs without credentials or fragments are accepted.');
  const host = url.hostname.replace(/^\[|\]$/g, '').toLowerCase();
  if (!host || host.startsWith('-') || (!isIP(host) && !/^[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?$/.test(host))) throw new InputError('Invalid hostname.');
  if (/^(169\.254\.|0\.|224\.|239\.|255\.)/.test(host) || ['::', '169.254.169.254', '100.100.100.200', 'metadata.google.internal'].includes(host) || /^fe80:/i.test(host)) throw new InputError('Metadata, link-local and unspecified addresses are not supported.');
  if (url.search) throw new InputError('Remove query parameters; credentials and tokens must not be submitted as targets.');
  return url;
}
export function scopedTarget(input: unknown, origin: string) {
  const u = targetURL(input);
  if (u.origin !== origin) throw new InputError('Target must use the exact authorized project origin (scheme, hostname and port).');
  return u;
}
function redactText(value: string): string {
  return value
    .replace(/https?:\/\/[^\s<>"']+/gi, x => { try { const u = new URL(x); if (u.username || u.password) { u.username = 'REDACTED'; u.password = 'REDACTED'; } for (const key of [...u.searchParams.keys()]) u.searchParams.set(key, '[REDACTED]'); return u.href; } catch { return '[URL REDACTED]'; } })
    .replace(/\b(?:AKIA|ASIA)[A-Z0-9]{16}\b/g, '[AWS KEY REDACTED]')
    .replace(/\b(?:gh[pousr]_[A-Za-z0-9_]{20,}|github_pat_[A-Za-z0-9_]{20,})\b/g, '[GITHUB TOKEN REDACTED]')
    .replace(/\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b/g, '[JWT REDACTED]')
    .replace(/\b(Bearer|Basic)\s+[A-Za-z0-9._~+\/=-]+/gi, '$1 [REDACTED]')
    .replace(/((?:set-cookie|cookie)["']?\s*[:=]\s*["']?)[^"'\r\n]*/gi, '$1[REDACTED]')
    .replace(/((?:password|passwd|secret|token|api[_-]?key|authorization|set-cookie|cookie)\s*["']?\s*[:=]\s*["']?)[^\s,"'<>;]+/gi, '$1[REDACTED]')
    .replace(/-----BEGIN [^-]*PRIVATE KEY-----[\s\S]*?(?:-----END [^-]*PRIVATE KEY-----|$)/g, '[PRIVATE KEY REDACTED]');
}
export function redact(value:string):string {
  // Structured JSON is traversed before text masking so a truncated PEM block
  // cannot consume the JSON delimiters and corrupt a report.
  let parsed:unknown;try{parsed=JSON.parse(value);}catch{return redactText(value);}
  const walk=(v:unknown):unknown=>{
    if(typeof v==='string')return redactText(v);
    if(Array.isArray(v))return v.map(walk);
    if(v&&typeof v==='object')return Object.fromEntries(Object.entries(v).map(([k,x])=>[k,/^(?:password|passwd|secret|token|api[_-]?key|authorization|cookie|set-cookie)$/i.test(k)?'[REDACTED]':walk(x)]));
    return v;
  };
  return JSON.stringify(walk(parsed));
}
export function safeCSV(value: unknown) {
  let s = redact(String(value ?? '')); if (/^[\s]*[=+@\-\t\r]/.test(s)) s = "'" + s;
  return '"' + s.replaceAll('"', '""') + '"';
}

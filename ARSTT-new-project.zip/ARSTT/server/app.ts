import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import {randomBytes, timingSafeEqual} from 'node:crypto';
import {Store} from './store.js';
import {Runner} from './runner.js';
import {toolIds, active, type ToolId} from './types.js';
import {toolHealth} from './tools.js';
import {InputError, targetURL, safeCSV, redact} from './safety.js';
const equal=(a:string,b:string)=>a.length===b.length && timingSafeEqual(Buffer.from(a),Buffer.from(b));
export function createApp(options:{data:string; publicDir?:string; deadlines?:Partial<Record<ToolId,number>>}) {
  const store=new Store(path.resolve(options.data)), runner=new Runner(store,{deadlines:options.deadlines});
  const session=randomBytes(32).toString('hex'),csrf=randomBytes(32).toString('hex');
  const json=(res:http.ServerResponse,status:number,data:unknown)=>{res.writeHead(status,{'content-type':'application/json; charset=utf-8'});res.end(JSON.stringify(data));};
  const server=http.createServer(async(req,res)=>{
    res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');res.setHeader('Cache-Control','no-store');res.setHeader('Cross-Origin-Resource-Policy','same-origin');
    res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'none'");
    try{
      const url=new URL(req.url || '/',`http://${req.headers.host || 'localhost'}`), route=url.pathname;
      if(!['localhost','127.0.0.1','[::1]'].includes(url.hostname))throw new InputError('Only local access is supported. Use localhost or 127.0.0.1.',403);
      if(route==='/api/health'){json(res,200,{ok:true,app:'ARSTT',version:'1.0.0'});return;}
      if(route==='/api/bootstrap' && req.method==='GET'){
        if(req.headers['sec-fetch-site']==='cross-site')throw new InputError('Cross-site bootstrap is not allowed.',403);
        res.setHeader('Set-Cookie',`arstt_session=${session}; HttpOnly; SameSite=Strict; Path=/`);json(res,200,{csrf,projects:store.projects(),jobs:store.jobs()});return;
      }
      if(route.startsWith('/api/')){
        const cookie=(req.headers.cookie || '').split(';').map(x=>x.trim()).find(x=>x.startsWith('arstt_session='))?.slice(14) || '';
        if(!equal(cookie,session))throw new InputError('Session expired. Reload the page.',401);
        if(req.method!=='GET'){
          if(!equal(String(req.headers['x-arstt-csrf'] || ''),csrf))throw new InputError('Missing session protection. Reload the page.',403);
          if(req.headers.origin && new URL(req.headers.origin).host!==url.host)throw new InputError('Cross-origin changes are not allowed.',403);
        }
        const body=async()=>{let raw='';for await(const chunk of req){raw+=chunk.toString();if(Buffer.byteLength(raw)>8192)throw new InputError('Request body exceeds 8 KiB.',413);}try{return JSON.parse(raw);}catch{throw new InputError('Invalid JSON body.');}};
        if(route==='/api/tools' && req.method==='GET'){json(res,200,await toolHealth(url.searchParams.get('refresh')==='1'));return;}
        if(route==='/api/projects'){
          if(req.method==='GET'){json(res,200,store.projects());return;}
          if(req.method==='POST'){const b=await body();if(b.authorized!==true)throw new InputError('Confirm permission to assess this target.');if(typeof b.name!=='string'||!b.name.trim()||b.name.length>80)throw new InputError('Project name must contain 1–80 characters.');const u=targetURL(b.target);json(res,201,store.addProject(b.name.trim(),u.origin));return;}
        }
        if(route==='/api/jobs'){
          if(req.method==='GET'){json(res,200,store.jobs(url.searchParams.get('project') || undefined));return;}
          if(req.method==='POST'){const b=await body();if(!toolIds.includes(b.tool))throw new InputError('Unknown tool.');if(typeof b.projectId!=='string')throw new InputError('Choose an authorized project.');json(res,202,runner.create(b.projectId,b.tool,b.target));return;}
        }
        const match=route.match(/^\/api\/jobs\/([0-9a-f-]{36})(?:\/(events|raw|export))?$/);
        if(match){
          const id=match[1],operation=match[2],job=store.job(id);if(!job)throw new InputError('Job not found.',404);
          if(req.method==='DELETE'&&!operation){runner.cancel(id);json(res,200,store.job(id));return;}
          if(req.method==='GET'){
            if(!operation){json(res,200,{job,logs:store.logs(id,Math.max(0,Number(url.searchParams.get('after'))||0))});return;}
            if(operation==='events'){
              res.writeHead(200,{'content-type':'text/event-stream','connection':'keep-alive','X-Accel-Buffering':'no'});
              let after=Math.max(0,Number(req.headers['last-event-id'] || url.searchParams.get('after'))||0),scheduled=false;
              const send=()=>{scheduled=false;if(res.destroyed)return;const logs=store.logs(id,after);if(logs.length)after=logs.at(-1)!.seq;res.write(`id: ${after}\ndata: ${JSON.stringify({job:store.job(id),logs})}\n\n`);if(logs.length===500)setImmediate(send);};
              const update=()=>{if(!scheduled){scheduled=true;setTimeout(send,100).unref();}};
              store.events.on(id,update);const heartbeat=setInterval(()=>res.write(': heartbeat\n\n'),15000);send();
              res.on('close',()=>{clearInterval(heartbeat);store.events.off(id,update);});return;
            }
            if(operation==='raw'){
              if(!job.rawAvailable)throw new InputError('This job has no validated raw output.',404);
              const raw=await fs.readFile(path.join(store.dir,'results',id,'raw.txt'),'utf8');res.writeHead(200,{'content-type':'text/plain; charset=utf-8','Content-Disposition':`attachment; filename="ARSTT-${id}-raw.txt"`});res.end(raw);return;
            }
            const format=url.searchParams.get('format') || 'json';
            if(!['json','csv'].includes(format))throw new InputError('Supported formats: JSON and CSV.');
            const report={application:'Automated Reconnaissance and Security Testing Toolkit (ARSTT)',exportedAt:new Date().toISOString(),...job,interpretation:'Open ports and tool matches are observations requiring review. Potential secrets are not verified. No AI prediction is included.'};
            res.setHeader('Content-Disposition',`attachment; filename="ARSTT-${id}.${format}"`);
            if(format==='json'){json(res,200,report);return;}
            const headers=['jobId','tool','target','status','startedAt','endedAt','error','title','kind','severity','verification','source','evidence','references'];
            const rows=(job.findings.length?job.findings:[null]).map(f=>[job.id,job.tool,job.target,job.status,job.startedAt,job.endedAt,job.error,f?.title,f?.kind,f?.severity,f?.verification,f?.source,f?.evidence,f?.references?.join(' ')]);
            res.writeHead(200,{'content-type':'text/csv; charset=utf-8'});res.end('\ufeff'+[headers,...rows].map(r=>r.map(safeCSV).join(',')).join('\r\n'));return;
          }
        }
        throw new InputError('API route not found.',404);
      }
      if(req.method!=='GET'&&req.method!=='HEAD')throw new InputError('Method not allowed.',405);
      const publicDir=path.resolve(options.publicDir || 'dist/public');
      const requested=path.resolve(publicDir,'.'+decodeURIComponent(route));
      if(requested!==publicDir&&!requested.startsWith(publicDir+path.sep))throw new InputError('Invalid path.',400);
      let file=requested;try{if(!(await fs.stat(file)).isFile())file=path.join(publicDir,'index.html');}catch{file=path.join(publicDir,'index.html');}
      const data=await fs.readFile(file).catch(()=>{throw new InputError('Frontend has not been built. Run npm run build first.',503);});
      const mime:Record<string,string>={'.html':'text/html; charset=utf-8','.js':'application/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.png':'image/png'};
      res.writeHead(200,{'content-type':mime[path.extname(file)] || 'application/octet-stream'});res.end(req.method==='HEAD'?undefined:data);
    }catch(error){const e=error as Error;if(!res.headersSent)json(res,e instanceof InputError?e.code:500,{error:redact(e.message)});else res.end();}
  });
  server.requestTimeout=30000;server.headersTimeout=10000;
  return {server,store,runner,async close(){await runner.stop();server.closeAllConnections();await new Promise<void>(r=>server.close(()=>r()));store.close();}};
}

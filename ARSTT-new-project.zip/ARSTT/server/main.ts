import {createApp} from './app.js';
const port=Number(process.env.PORT || 4310),host=process.env.HOST || '127.0.0.1';
if(!Number.isInteger(port)||port<1||port>65535)throw new Error('PORT must be between 1 and 65535.');
const app=createApp({data:process.env.ARSTT_DATA || './data'});
app.server.listen(port,host,()=>console.log(`ARSTT running on ${host}:${port}. Local, single-operator assessment environment.`));
for(const signal of ['SIGINT','SIGTERM'])process.once(signal,()=>{void app.close().then(()=>process.exit(0));});

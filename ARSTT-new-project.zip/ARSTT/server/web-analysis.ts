import dns from 'node:dns/promises';
import type {Finding} from './types.js';
export async function request(url:URL, signal:AbortSignal): Promise<{body:string; headers:Headers; status:number}> {
  let response:Response;
  try {response = await fetch(url,{signal:AbortSignal.any([signal,AbortSignal.timeout(10000)]),redirect:'manual',headers:{'User-Agent':'ARSTT/1.0 authorized-assessment'}});}
  catch(error){const e=error as Error & {cause?:{code?:string;message?:string}};if(signal.aborted || e.name==='TimeoutError')throw e;const hint=['localhost','127.0.0.1','[::1]'].includes(url.hostname)?' In Docker, localhost means the app container. Use lab:8088 for the included lab, or host.docker.internal for an authorized service on Windows.':'';throw new Error(`Cannot reach ${url.origin}: ${e.cause?.code || e.cause?.message || e.message}.${hint}`);}
  if (response.status >= 300 && response.status < 400) { await response.body?.cancel(); throw new Error('Target redirects. Authorize and scan its final origin explicitly; automatic cross-origin requests are disabled.'); }
  if (!response.ok) { await response.body?.cancel(); throw new Error(`HTTP ${response.status} returned by ${url.origin}${url.pathname}`); }
  const chunks:Uint8Array[]=[]; let count=0;
  if (response.body) for await(const chunk of response.body as any) { count+=chunk.length; if(count>2*1024*1024) { throw new Error('HTTP response exceeds the 2 MiB limit.'); } chunks.push(chunk); }
  return {body:Buffer.concat(chunks).toString('utf8'),headers:response.headers,status:response.status};
}
export async function reconnaissance(target:URL, signal:AbortSignal, log:(s:string)=>void) {
  log(`Resolving ${target.hostname}`);
  const addresses = await dns.lookup(target.hostname.replace(/^\[|\]$/g,''),{all:true});
  log(`Requesting ${target.origin}${target.pathname}`);
  const r=await request(target,signal);
  const findings:Finding[]=addresses.map(a=>({title:a.address,kind:`IPv${a.family} address`,source:target.hostname,severity:'info',evidence:'Resolved by the operating system DNS resolver.',verification:'observation'}));
  findings.push({title:`HTTP ${r.status}`,kind:'HTTP response',source:target.href,severity:'info',evidence:JSON.stringify({server:r.headers.get('server') ?? 'Unknown',contentType:r.headers.get('content-type') ?? 'Unknown',title:r.body.match(/<title[^>]*>([^<]{0,300})/i)?.[1] ?? 'Unknown'}),verification:'observation'});
  const links=new Set<string>();
  for(const m of r.body.matchAll(/(?:href|src)\s*=\s*["']([^"']{1,2048})["']/gi)) { try { const u=new URL(m[1],target); if(u.origin===target.origin && ['http:','https:'].includes(u.protocol)){ u.search='';u.hash='';links.add(u.href); } } catch{} }
  for(const source of [...links].slice(0,200)) findings.push({title:new URL(source).pathname,kind:'Discovered resource',source,severity:'info',evidence:'Linked in the target HTML; not a vulnerability.',verification:'observation'});
  return {findings,raw:JSON.stringify({addresses,httpStatus:r.status,resources:[...links]},null,2)};
}
export async function javascriptLeaks(target:URL, signal:AbortSignal, log:(s:string)=>void) {
  const page=await request(target,signal), files=new Set<string>();
  if (/javascript/i.test(page.headers.get('content-type') || '') || /\.m?js$/i.test(target.pathname)) files.add(target.href);
  for(const m of page.body.matchAll(/<script\b[^>]*\bsrc\s*=\s*["']([^"']+)["']/gi)) { try { const u=new URL(m[1],target); if(u.origin===target.origin && !u.username && !u.password) {u.hash='';files.add(u.href);} else log('Skipped a script outside the authorized origin.'); } catch {} }
  const findings:Finding[]=[], scanned:string[]=[]; let failures=0;
  const analyze=(source:string,body:string)=>{
    const patterns:[string,RegExp][]=[['AWS access-key indicator',/\b(?:AKIA|ASIA)[A-Z0-9]{16}\b/g],['GitHub token indicator',/\b(?:gh[pousr]_[A-Za-z0-9_]{20,}|github_pat_[A-Za-z0-9_]{20,})\b/g],['JWT indicator',/\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b/g],['Assigned credential indicator',/\b(?:api[_-]?key|access[_-]?token|client[_-]?secret|password)\s*[:=]\s*["']([^"'\n]{8,200})["']/gi],['Private-key indicator',/-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/g]];
    for(const [title,re] of patterns) for(const m of body.matchAll(re)) findings.push({title,kind:'Potential secret',source,severity:'unknown',verification:'potential',evidence:`Line ${body.slice(0,m.index).split('\n').length}; value hidden. Pattern match only; no credential validation was attempted.`});
    const endpoints=new Set<string>(); for(const m of body.matchAll(/["'`](\/(?:api|v[1-9]|graphql|rest)[/A-Za-z0-9_.?=&%{}:-]*)["'`]/g)) { try {const u=new URL(m[1],target);u.search='';endpoints.add(u.href);}catch{} }
    for(const endpoint of endpoints) findings.push({title:new URL(endpoint).pathname,kind:'Endpoint reference',source,severity:'info',verification:'observation',evidence:endpoint});
  };
  const selected=[...files].slice(0,12);
  for(const source of selected){ if(signal.aborted) throw signal.reason; log(`Reading JavaScript ${new URL(source).pathname}`); try {const body=source===target.href ? page.body : (await request(new URL(source),signal)).body; analyze(source,body);scanned.push(source);} catch(e){if(signal.aborted)throw e;failures++;log(`JavaScript request failed: ${(e as Error).message}`);} }
  // Analyze inline script as text; never evaluate, import or run discovered content.
  if(!/javascript/i.test(page.headers.get('content-type') || '')) for(const m of page.body.matchAll(/<script\b(?![^>]*\bsrc\s*=)[^>]*>([\s\S]*?)<\/script>/gi)) analyze(target.href+'#inline',m[1]);
  if(failures) throw new Error(`${failures} JavaScript request(s) failed; coverage is incomplete. No clean-scan claim can be made.`);
  log(`Analyzed ${scanned.length} external file(s); ${Math.max(0,files.size-12)} skipped by the file limit. Indicators are unverified.`);
  return {findings,raw:JSON.stringify({scanned,discovered:files.size,fileLimit:12,verifiedSecrets:0,findings},null,2)};
}

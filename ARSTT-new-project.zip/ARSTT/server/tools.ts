import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {constants} from 'node:fs';
import {execute} from './process.js';
import {toolIds, type ToolId, type ToolHealth} from './types.js';
export const names: Record<ToolId,string> = {recon:'Reconnaissance', nmap:'Nmap', jsleaks:'JavaScript Leaks', whatweb:'WhatWeb', tls:'testssl.sh', nuclei:'Nuclei', zap:'OWASP ZAP'};
export const templateNames = ['http/exposed-panels/phpmyadmin-panel.yaml', 'http/misconfiguration/http-missing-security-headers.yaml', 'http/exposures/configs/git-config.yaml'];
export const templateDir = () => path.resolve(process.env.ARSTT_TEMPLATES || '.tools/templates');
export async function executable(id: ToolId): Promise<string> {
  const key = `ARSTT_${id === 'tls' ? 'TESTSSL' : id.toUpperCase()}`;
  const candidates = process.env[key] ? [process.env[key]!] : [path.resolve('.tools/bin', id === 'tls' ? 'testssl.sh' : id === 'zap' ? 'zap.sh' : id), ...(process.env.PATH || '').split(path.delimiter).flatMap(p => (id === 'tls' ? ['testssl.sh','testssl'] : id === 'zap' ? ['zap.sh'] : [id]).map(n => path.join(p,n))), ...(id === 'zap' ? [path.resolve('.tools/zap/zap.sh')] : [])];
  for (const candidate of candidates) { try { await fs.access(candidate, constants.X_OK); return candidate; } catch {} }
  throw new Error(`${names[id]} is not installed or executable. Run the documented Docker setup or npm run setup:tools. Override: ${key}.`);
}
let cache: {at:number; data:ToolHealth[]} | undefined;
export async function toolHealth(force = false): Promise<ToolHealth[]> {
  if (!force && cache && Date.now() - cache.at < 60000) return cache.data;
  const data = await Promise.all(toolIds.map(async id => {
    if (id === 'recon' || id === 'jsleaks') return {id,name:names[id],ready:true,version:`Node ${process.version}`,detail:'Built-in bounded HTTP/DNS analysis. Discovered JavaScript is never executed.'};
    let work:string|undefined;
    try {
      const exe = await executable(id);
      if (id === 'nuclei') for (const file of templateNames) await fs.access(path.join(templateDir(),file));
      work=await fs.mkdtemp(path.join(os.tmpdir(),'arstt-doctor-'));
      if(id==='tls'){
        for(const [command,args] of [['hexdump',['--version']],['openssl',['version']],['dig',['-v']]] as const){
          const check=await execute(command,[...args],{signal:new AbortController().signal,timeout:5000});
          if(check.code!==0)throw new Error(`testssl.sh dependency ${command} failed: ${check.stderr.slice(-200)}`);
        }
      }
      const args = id === 'zap' ? ['-Xmx256m','-dir',work,'-version'] : id === 'nuclei' ? ['-version'] : ['--version'];
      const p = await execute(exe,args,{signal:new AbortController().signal,timeout:25000,cwd:work,env:{XDG_CONFIG_HOME:path.join(work,'config'),XDG_CACHE_HOME:path.join(work,'cache')}});
      if (p.code !== 0 || /\[(?:ERR|FTL)\]/.test(p.stderr+p.stdout)) throw new Error(`Version check failed (${p.code}): ${(p.stderr+p.stdout).slice(-500)}`);
      const version = (p.stdout+' '+p.stderr).replace(/\x1b\[[0-9;]*m/g,'').trim().slice(0,500);
      return {id,name:names[id],ready:true,version,detail:id === 'nuclei' ? 'Pinned upstream HTTP templates; bounded review profile.' : 'Executable started successfully. A version check is not a completed scan.'};
    } catch (e) { return {id,name:names[id],ready:false,version:'Unavailable',detail:(e as Error).message}; }
    finally {if(work)await fs.rm(work,{recursive:true,force:true});}
  })); cache = {at:Date.now(),data}; return data;
}

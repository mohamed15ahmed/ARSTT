import http from 'node:http';
import https from 'node:https';
import fs from 'node:fs';
import {fileURLToPath} from 'node:url';
let exposed=true;
export function handler(req,res){
  const p=new URL(req.url,'http://training').pathname;
  res.setHeader('Server','ARSTT-Training-Lab');res.setHeader('Connection','close');
  if(p==='/__control'&&req.method==='POST'){let raw='';req.on('data',d=>raw+=d);req.on('end',()=>{try{exposed=JSON.parse(raw).exposed===true;res.end('ok');}catch{res.writeHead(400);res.end('bad request');}});return;}
  if(p==='/slow'){setTimeout(()=>res.end('Delayed training response'),20000).unref();return;}
  if(p==='/missing'){res.writeHead(404);res.end('not found');return;}
  if(p==='/health'){res.setHeader('Content-Type','application/json');res.end(JSON.stringify({ok:true,training:true}));return;}
  if(p==='/app.js'){res.setHeader('Content-Type','application/javascript');res.end(exposed?'const api_key = "ARSTT_TRAINING_INDICATOR_NOT_A_REAL_SECRET"; const endpoint="/api/v1/items";':'const endpoint="/api/v1/items";');return;}
  if(p==='/api/v1/items'){res.setHeader('Content-Type','application/json');res.end('[{"training":true}]');return;}
  if(p==='/.git/config'&&exposed){res.setHeader('Content-Type','text/plain');res.end('[core]\nrepositoryformatversion = 0\n[remote "origin"]\nurl = https://example.invalid/training/repository.git\n');return;}
  if(p==='/phpmyadmin/'&&exposed){res.setHeader('Content-Type','text/html');res.end('<html><title>phpMyAdmin</title><body><h1>Welcome to phpMyAdmin</h1><input name="pma_username"><div>phpMyAdmin</div></body></html>');return;}
  if(p!=='/'){res.writeHead(404);res.end('Not found');return;}
  res.setHeader('Content-Type','text/html; charset=utf-8');
  res.end('<!doctype html><html><head><title>ARSTT Authorized Training Lab</title><script src="/app.js"></script></head><body><h1>ARSTT training fixture</h1><p>Synthetic test content, not a real application or credential.</p><a href="/api/v1/items">Items</a><a href="/phpmyadmin/">Training panel</a></body></html>');
}
if(process.argv[1]===fileURLToPath(import.meta.url)){
  const host=process.env.LAB_HOST||'0.0.0.0',port=Number(process.env.LAB_PORT||8088),tlsPort=Number(process.env.LAB_TLS_PORT||8443);
  const server=http.createServer(handler);server.listen(port,host,()=>console.log('Authorized HTTP training lab on port '+port));
  const secure=https.createServer({key:fs.readFileSync(new URL('./training-only.key',import.meta.url)),cert:fs.readFileSync(new URL('./training-only.crt',import.meta.url))},handler);secure.listen(tlsPort,host,()=>console.log('TLS training lab on port '+tlsPort+' (public development certificate only)'));
  for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>{server.closeAllConnections();secure.closeAllConnections();server.close();secure.close();});
}

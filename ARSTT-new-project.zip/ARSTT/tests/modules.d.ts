declare module '*.mjs' {export const handler:any;}

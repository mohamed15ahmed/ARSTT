import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs/promises';
import {Store} from '../server/store.js';import {Runner} from '../server/runner.js';import {temporary,lab,wait} from './support.js';
test('queue enforces two running jobs and cancellation releases a slot without mixing results',async()=>{
 const dir=await temporary(),fixture=await lab(),store=new Store(dir),runner=new Runner(store,{deadlines:{recon:800,jsleaks:800}});
 try{
  const p=store.addProject('Lab one',fixture.http),q=store.addProject('Lab two',fixture.http);
  const a=runner.create(p.id,'recon',fixture.http+'/slow'),b=runner.create(p.id,'jsleaks',fixture.http+'/slow'),c=runner.create(q.id,'recon',fixture.http+'/');
  for(let i=0;i<100&&store.jobs().filter(j=>j.status==='running').length<2;i++)await new Promise(r=>setTimeout(r,5));
  assert.equal(store.jobs().filter(j=>j.status==='running').length,2);assert.equal(store.job(c.id)?.status,'queued');
  runner.cancel(a.id);const completed=await wait(store,c.id);assert.equal(completed.status,'completed',completed.error||'');assert.equal((await wait(store,a.id)).status,'cancelled');assert.equal((await wait(store,b.id)).status,'timeout');assert.deepEqual(store.job(a.id)?.findings,[]);assert.ok(completed.findings.length);
 }finally{await runner.stop();store.close();await fixture.close();await fs.rm(dir,{recursive:true,force:true});}
});

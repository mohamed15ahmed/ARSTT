import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs/promises';import path from 'node:path';
import {Store} from '../server/store.js';import {Runner} from '../server/runner.js';import {toolHealth,executable} from '../server/tools.js';import {toolIds} from '../server/types.js';import {temporary,lab,wait,evidence} from './support.js';import {execute,DeadlineError} from '../server/process.js';import * as parse from '../server/parsers.js';
test('every tool starts and performs a REAL authorized training scan', {timeout:650000},async()=>{
 const health=await toolHealth(true);assert.ok(health.every(t=>t.ready),JSON.stringify(health.filter(t=>!t.ready)));
 const fixture=await lab(),dir=await temporary(),store=new Store(dir),runner=new Runner(store),results=[];
 try{
  const http=store.addProject('HTTP training',fixture.http),tls=store.addProject('TLS training',fixture.https);
  for(const tool of toolIds){const p=tool==='tls'?tls:http;const j=runner.create(p.id,tool,p.origin+'/');const done=await wait(store,j.id);results.push({job:done,logs:store.logs(j.id)});await evidence('tool-acceptance.json',{health,results});assert.equal(done.status,'completed',tool+': '+done.error);assert.ok(done.rawAvailable);assert.ok(done.findings.length>0,tool+' produced no expected fixture observation');
   const raw=await fs.readFile(path.join(dir,'results',j.id,'raw.txt'),'utf8');assert.ok(!raw.includes('ARSTT_TRAINING_INDICATOR_NOT_A_REAL_SECRET'));
   if(tool==='nmap')assert.ok(done.findings.some(f=>f.title.includes(new URL(fixture.http).port)));
   if(tool==='jsleaks'){assert.ok(done.findings.some(f=>f.verification==='potential'));assert.ok(done.findings.some(f=>f.kind==='Endpoint reference'));}
   if(tool==='nuclei')assert.ok(done.findings.some(f=>f.title.toLowerCase().includes('phpmyadmin')||f.title.toLowerCase().includes('git')));
  }
  // A second real TLS run must have a separate report, not the previous file.
  const again=await wait(store,runner.create(tls.id,'tls',tls.origin+'/').id);assert.equal(again.status,'completed',again.error||'');assert.notEqual(again.id,results.find(r=>r.job.tool==='tls')!.job.id);results.push({job:again,logs:store.logs(again.id)});
  // Change the fixture and verify new JS results do not inherit old potential secrets.
  await fetch(fixture.http+'/__control',{method:'POST',body:JSON.stringify({exposed:false})});
  const clean=await wait(store,runner.create(http.id,'jsleaks',http.origin+'/').id);assert.equal(clean.status,'completed');assert.ok(!clean.findings.some(f=>f.verification==='potential'));results.push({job:clean,logs:store.logs(clean.id)});
  await evidence('tool-acceptance.json',{passed:true,health,results});
 }finally{await runner.stop();store.close();await fixture.close();await fs.rm(dir,{recursive:true,force:true});}
});
test('every tool: real timeout, failed target and no stale successful results',{timeout:90000},async()=>{
 const fixture=await lab(),dir=await temporary(),store=new Store(dir),runner=new Runner(store,{deadlines:{recon:100,jsleaks:100,nmap:100,whatweb:100,tls:100,nuclei:100,zap:1000}}),results=[];
 try{
  const p=store.addProject('HTTP slow fixture',fixture.http),s=store.addProject('TLS fixture',fixture.https);
  for(const tool of toolIds){const project=tool==='tls'?s:p;const target=project.origin+(tool==='recon'||tool==='jsleaks'?'/slow':'/');const done=await wait(store,runner.create(project.id,tool,target).id);assert.equal(done.status,'timeout',tool+': '+done.error);assert.deepEqual(done.findings,[]);results.push({job:done,logs:store.logs(done.id)});}
  const closed=store.addProject('Closed training endpoint','http://127.0.0.1:1'),closedTLS=store.addProject('Closed TLS endpoint','https://127.0.0.1:1');
  // Use normal deadlines here so connection failures are not confused with the shortened timeout budget.
  const normal=new Runner(store);for(const tool of toolIds.filter(t=>t!=='nmap')){const p=tool==='tls'?closedTLS:closed;const done=await wait(store,normal.create(p.id,tool,p.origin+'/').id);assert.equal(done.status,'failed',tool+': '+done.error);assert.deepEqual(done.findings,[]);results.push({job:done,logs:store.logs(done.id)});}
  const invalid=store.addProject('Unresolvable training address','http://arstt-training-does-not-exist.invalid');
  const unresolved=await wait(store,normal.create(invalid.id,'nmap',invalid.origin+'/').id);assert.equal(unresolved.status,'failed');assert.deepEqual(unresolved.findings,[]);results.push({job:unresolved,logs:store.logs(unresolved.id)});await normal.stop();
  const command=await executable('nmap'),args=['-sT','-sV','--version-light','-Pn','--host-timeout','10ms','-p',new URL(fixture.http).port,'-oX','-','127.0.0.1'];
  const hostTimeout=await execute(command,args,{signal:new AbortController().signal,timeout:30000});assert.equal(hostTimeout.code,0);assert.throws(()=>parse.nmap(hostTimeout.stdout),DeadlineError);
  await evidence('tool-failures.json',{passed:true,results,nmapHostTimeout:{command,args,...hostTimeout}});
 }finally{await runner.stop();store.close();await fixture.close();await fs.rm(dir,{recursive:true,force:true});}
});

import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {targetURL,scopedTarget,redact,safeCSV} from '../server/safety.js';
import {Store} from '../server/store.js';
import {execute,DeadlineError,CancelError} from '../server/process.js';
import * as parse from '../server/parsers.js';
import {temporary} from './support.js';
test('targets: exact origin authorization, schemes, credentials, shell injection and metadata',()=>{
 for(const input of ['localhost','--help','http://localhost;touch/x','http://u:p@localhost','file:///etc/passwd','http://169.254.169.254/','http://localhost/?token=x','http://localhost/#frag','http://localhost/ a'])assert.throws(()=>targetURL(input),input);
 assert.equal(scopedTarget('http://localhost:8080/path','http://localhost:8080').pathname,'/path');
 for(const u of ['http://localhost:8081/','https://localhost:8080/','http://evil.invalid/'])assert.throws(()=>scopedTarget(u,'http://localhost:8080'));
});
test('secret redaction preserves JSON structure and CSV disables formulas',()=>{
 const original=JSON.stringify({source:'http://site/path?token=confidential',evidence:'password=confidential token=abc123 ghp_abcdefghijklmnopqrstuvwxyz12345'});
 const masked=redact(original);assert.doesNotThrow(()=>JSON.parse(masked));assert.ok(!masked.includes('confidential'));assert.ok(!masked.includes('abcdefghijklmnopqrstuvwxyz'));
 assert.equal(safeCSV('=CMD()'),'"\'=CMD()"');assert.equal(safeCSV('a"b'),'"a""b"');
 assert.ok(!redact('Authorization: Bearer private-token-value').includes('private-token-value'));
 assert.ok(!redact('Cookie: one=private; two=private2').includes('private'));
 const pem=redact(JSON.stringify({evidence:'-----BEGIN RSA PRIVATE KEY-----\nprivate-material',other:'keep'}));assert.equal(JSON.parse(pem).other,'keep');assert.ok(!pem.includes('private-material'));
});
test('SQLite survives restart, separates jobs, and never converts interrupted jobs to success',async()=>{
 const dir=await temporary();let s=new Store(dir);try{
  const p=s.addProject('Lab','http://localhost:8080'),a=s.addJob(p.id,'recon',p.origin),b=s.addJob(p.id,'jsleaks',p.origin);
  s.begin(a.id);s.log(a.id,'stdout','password=private');s.finish(b.id,'timeout',[],'deadline',false);s.close();s=new Store(dir);
  assert.equal(s.job(a.id)?.status,'failed');assert.equal(s.job(b.id)?.status,'timeout');assert.notEqual(a.id,b.id);assert.ok(!s.logs(a.id)[0].message.includes('private'));assert.equal(s.logs(b.id).length,0);
 }finally{s.close();await fs.rm(dir,{recursive:true,force:true});}
});
test('real process: output, non-zero exit, timeout and abort are distinct',async()=>{
 const signal=new AbortController().signal;
 const good=await execute(process.execPath,['-e','console.log("actual process output")'],{signal,timeout:2000});assert.equal(good.code,0);assert.match(good.stdout,/actual process/);
 const bad=await execute(process.execPath,['-e','process.stderr.write("intentional failure");process.exit(7)'],{signal,timeout:2000});assert.equal(bad.code,7);
 await assert.rejects(execute(process.execPath,['-e','setTimeout(()=>{},10000)'],{signal,timeout:30}),DeadlineError);
 const abort=new AbortController(),pending=execute(process.execPath,['-e','setTimeout(()=>{},10000)'],{signal:abort.signal,timeout:5000});setTimeout(()=>abort.abort(),30);await assert.rejects(pending,CancelError);
});
test('parsers reject invalid and incomplete tool output',()=>{
 assert.throws(()=>parse.nmap('<nmaprun>'));assert.throws(()=>parse.nmap('<nmaprun><runstats><finished exit="success"/><hosts total="0"/></runstats></nmaprun>'));
 assert.throws(()=>parse.nmap('<nmaprun><host timedout="true"/><runstats><finished exit="success"/><hosts total="1"/></runstats></nmaprun>'),DeadlineError);
 assert.throws(()=>parse.whatweb('[]','http://localhost/'));assert.throws(()=>parse.tls('[]','https://localhost/'));assert.throws(()=>parse.zap('{"site":[]}','http://localhost/'));assert.throws(()=>parse.nuclei('','','http://localhost/'));
 assert.deepEqual(parse.nuclei('','{"requests":1,"templates":1,"errors":0}','http://localhost/'),[]);
 assert.deepEqual(parse.nuclei('','{"requests":"17","templates":"3","errors":"0"}','http://localhost/'),[]);
});

import http from 'node:http';
import https from 'node:https';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {createApp} from '../server/app.js';
import {Store} from '../server/store.js';
import {active, type Job} from '../server/types.js';
export async function temporary(){return fs.mkdtemp(path.join(os.tmpdir(),'arstt-test-'));}
export async function lab(){
  const handler=(await import('../lab/server.mjs')).handler;
  const h=http.createServer(handler),s=https.createServer({key:await fs.readFile('lab/training-only.key'),cert:await fs.readFile('lab/training-only.crt')},handler);
  await Promise.all([new Promise<void>(r=>h.listen(0,'127.0.0.1',r)),new Promise<void>(r=>s.listen(0,'127.0.0.1',r))]);
  return {http:`http://127.0.0.1:${(h.address() as any).port}`,https:`https://127.0.0.1:${(s.address() as any).port}`,async close(){h.closeAllConnections();s.closeAllConnections();await Promise.all([new Promise<void>(r=>h.close(()=>r())),new Promise<void>(r=>s.close(()=>r()))]);}};
}
export async function application(options:Parameters<typeof createApp>[0]){
 const app=createApp(options);await new Promise<void>(r=>app.server.listen(0,'127.0.0.1',r));
 const base=`http://127.0.0.1:${(app.server.address() as any).port}`;
 const boot=await fetch(base+'/api/bootstrap');const cookie=boot.headers.get('set-cookie')!.split(';')[0],csrf=(await boot.json() as any).csrf;
 const req=async(route:string,method='GET',body?:unknown,headers?:Record<string,string>)=>fetch(base+'/api'+route,{method,headers:{cookie,'x-arstt-csrf':csrf,'content-type':'application/json',...headers},body:body===undefined?undefined:JSON.stringify(body)});
 return {...app,base,cookie,csrf,req};
}
export async function wait(store:Store,id:string,timeout=260000):Promise<Job>{const start=Date.now();while(Date.now()-start<timeout){const j=store.job(id)!;if(!active(j.status))return j;await new Promise(r=>setTimeout(r,50));}throw new Error('Acceptance deadline exceeded for '+id);}
export async function evidence(file:string,data:unknown){await fs.mkdir('artifacts',{recursive:true});await fs.writeFile(path.join('artifacts',file),JSON.stringify(data,null,2));}
